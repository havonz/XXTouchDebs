local screen_btn = require("screen_btn")
nLog(screen_btn._VERSION)

local sub_UI = screen_btn()

local sub_show = function()
	sub_UI:show(
		{
			x = -1,
			y = 50,
			buttons = {
				{text = "子1", run = function() sys.toast("触发子1") end},
				{text = "子2", run = function() sys.toast("触发子2") end},
			}
		}
	)
end
local sub_hide = function()
	sub_UI:hide()
end


local p_UI = screen_btn()
p_UI:show(
	{
		x = 1,
		y = 50,
		buttons = {
			{text = "显示子", run = function() sub_show() end},
			{text = "隐藏子", run = function() sub_hide() end},
		}
	}
)

while true do
	sys.sleep(1)
end