local _ENV = table.deep_copy(_ENV)
local check_value = functor.argth.check_value
local opt_value = functor.argth.opt_value
local plist = require("plist")
screen.enlarge_size = function()
	local screen_width, screen_height = screen.size()
	local real_canvas = plist.read('/private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist') or {}
	local canvas_height = type(real_canvas.canvas_height) == 'number' and real_canvas.canvas_height or screen_height
	local canvas_width = type(real_canvas.canvas_width) == 'number' and real_canvas.canvas_width or screen_width
	if canvas_height < canvas_width then
		canvas_width, canvas_height = canvas_height, canvas_width
	end
	return canvas_width, canvas_height
end

device.screen_scale = function()
	local w, h = screen.size()
	local factor = 2
	if w == 1242 or w == 1080 then
		factor = 3
	elseif w == 320 or w == 768 then
		factor = 1
	end
	return factor
end

return setmetatable(
	{_VERSION = "0.2"},
	{__call = function(self, ...)
		return setmetatable({
			id = 0,
			eid = 0,
			buttons = {},
			_VERSION = "0.1"
		}, {
			__index = function(self, ...)
				local key = string.lower(
					check_value(1, 'string', ...)
				)
				return 
					(key == 'hide' and function(self, ...)
						return self.id == 0 or (webview.hide(self.id) and thread.unregister_event("btn." .. self.id, self.eid))
					end)
				or
					(key == 'show' and function(self, ...)
						local ui = check_value(1, 'table', ...)
						for id = 1, 1000 do
							local frame = webview.frame(id)
							if frame.level == 0 and 
								frame.width == 0 and
								frame.height == 0 and
								frame.x == 0 and
								frame.y == 0 then
								self.id = id
								break
							end
						end
						self.buttons = ui.buttons
						local btn_tab = {}
						for key, value in pairs(ui.buttons) do
							table.insert(btn_tab, value.text)
						end
						
						proc_queue_clear("btn." .. self.id)
						self.eid = thread.register_event( -- 注册监听字典状态有值事件
							"btn." .. self.id,
							function(val)
								for _, value in ipairs(self.buttons) do
									if value.text == val then
										value.run()
										break
									end
								end
							end
						)
						proc_put("btn.size", "")
						webview.show{
							html = [==[
		<!DOCTYPE html>
		<html>
			<head>
				<meta charset="utf-8">
				<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
				<link rel="stylesheet" href="mdui/css/mdui.min.css"/>
				
				<script type="text/javascript" src="js/jquery.min.js"></script>
				<script type="text/javascript" src="mdui/js/mdui.min.js"></script>
				<script src="https://cdn.bootcss.com/jquery.pin/1.0.1/jquery.pin.min.js"></script>
				<style>
					#container {
						position: absolute;
						background: #EAEAEA;
						left: 0pt;
						top: 0pt;
					}
				</style>
			</head>
			<body style="overflow-y: hidden; overflow-x: hidden;">
				<div id="container"></div>
			</body>
		</html>
		<script>
			$(document).ready(function(){
				$('body').css('background','none');
				var buttons = ]==] .. json.encode(btn_tab) .. [==[;
				var buttons_str = '';
				$.each(buttons, function(key, value){
					$("#container").append($('<button id="' + value + '" class="mdui-btn mdui-btn-block mdui-color-theme-accent mdui-ripple">' + value + '</button>'))
				});
				
				$.post(
					"/proc_put",
					JSON.stringify({"key": "btn.size", "value": JSON.stringify(
						{
							"width": parseInt($("#container").css("width")),
							"height": parseInt($("#container").css("height"))
						}
						)}),
					function(data){
						//mdui.snackbar({message: data.message});
					},
					'json'
				);
				
				$("button").on("click",function(e){
					console.log(e.target.id)
					$.post(
						"/proc_queue_push",
						JSON.stringify({"key": "btn.]==] .. self.id .. [==[", "value": e.target.id}),
						function(data){
							//mdui.snackbar({message: data.message});
						},
						'json'
					)
					
				})
			});
		</script>
							]==],
							x = 0,
							y = 0,
							id = self.id,
							animation_duration = ui.animation_duration,
							rotate = ui.rotate,
							level = ui.level,
							alpha = 0,
							--opaque = false,
							ignores_hit = ui.ignores_hit,
						}
						local _time = os.time()
						while os.time() - _time < 3 do
							local UIsize = proc_put("btn.size", "")
							if UIsize ~= "" then
								UIsize = json.decode(UIsize)
								local s_width, s_hight = screen.enlarge_size()
								
								UIsize.width = UIsize.width * device.screen_scale()
								UIsize.height = UIsize.height * device.screen_scale()
								if ui.x and ui.x < 0 then
									ui.x = s_width + ui.x - UIsize.width
								end
								
								if ui.y and ui.y < 0 then
									ui.y = s_hight + ui.y - UIsize.height
								end
								
								webview.show{
									alpha = 1,
									x = ui.x,
									y = ui.y,
									id = self.id,
									width = UIsize.width,
									height = UIsize.height
								}
								break
							end
						end
					end) 
				or
					(key == 'frame' and function(self, ...)
						return webview.frame(self.id)
					end)
				or
					(key == 'eval' and function(self, ...)
						local script = check_value(1, 'string', ...)
						return webview.eval(script)
					end)
				or
					(key == 'destroy' and function(self, ...)
						if self.id ~= 0 then
							webview.hide(self.id)
							thread.unregister_event("btn." .. self.id, self.eid)
						end
						self = nil
					end)
			end,
		})
	end}
)

--[[
	local screen_btn = require("screen_btn")
	nLog(screen_btn._VERSION)
	local show1 = screen_btn()
	show1:show(
		{
			x = 1,
			y = 50,
			buttons = {
				{text = "测试11", run = function() sys.toast("点击测试11") end},
				{text = "测试12", run = function() sys.toast("点击测试12") end},
				{text = "测试13", run = function() sys.toast("点击测试13") end},
				{text = "测试14", run = function() sys.toast("点击测试14") end},
				{text = "测试15", run = function() sys.toast("点击测试15") end},
				{text = "测试16", run = function() sys.toast("点击测试16") end},
				{text = "测试17", run = function() sys.toast("点击测试17") end},
				{text = "测试18", run = function() sys.toast("点击测试18") end},
			}
		}
	)
	local show2 = screen_btn()
	show2:show(
		{
			x = -1,
			y = 50,
			buttons = {
				{text = "测试21", run = function() sys.toast("点击测试21") end},
				{text = "测试22", run = function() sys.toast("点击测试22") end},
				{text = "测试23", run = function() sys.toast("点击测试23") end},
				{text = "测试24", run = function() sys.toast("点击测试24") end},
				{text = "测试25", run = function() sys.toast("点击测试25") end},
				{text = "测试26", run = function() sys.toast("点击测试26") end},
				{text = "测试27", run = function() sys.toast("点击测试27") end},
				{text = "测试28", run = function() sys.toast("点击测试28") end},
			}
		}
	)
	while true do
		sys.sleep(1)
	end
--]]
