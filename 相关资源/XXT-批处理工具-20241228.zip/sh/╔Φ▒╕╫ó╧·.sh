#!/bin/bash

PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1
killall -9 backboardd 2>/dev/null
echo 注销指令已送达
