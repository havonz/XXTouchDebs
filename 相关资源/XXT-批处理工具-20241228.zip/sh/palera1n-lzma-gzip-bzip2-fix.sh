#!/bin/bash

VARJB=
[ -d /var/jb/usr/bin ] && VARJB=/var/jb

apt-get update -y
apt-get install --allow-unauthenticated -y xz-utils ldid gzip bzip2

ldid -S $VARJB/usr/bin/xz
ldid -S $VARJB/usr/bin/bzip2
ldid -S $VARJB/usr/bin/bunzip2
ldid -S $VARJB/usr/bin/bzcat
ldid -S $VARJB/usr/bin/bzip2recover
ldid -S $VARJB/usr/bin/gzip

echo 完事儿
