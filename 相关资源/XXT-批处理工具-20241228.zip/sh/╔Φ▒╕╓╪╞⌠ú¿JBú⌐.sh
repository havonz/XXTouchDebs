#!/bin/bash

echo 重启指令已送达
echo XXT-BATCH-DISCONNECT

ldrestart 2>/dev/null
killall -9 killall 2>/dev/null
killall -9 kill 2>/dev/null
killall -9 rm 2>/dev/null
killall -9 add1s 2>/dev/null
killall -9 sleep 2>/dev/null
killall -9 unset 2>/dev/null
killall -9 ReportCrash 2>/dev/null
killall -9 lua 2>/dev/null
killall -9 webserv 2>/dev/null

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

$VARJB/bin/bash -c "sleep 2; killall -9 sleep bash sh" & 2>/dev/null
