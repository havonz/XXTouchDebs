--[[
该脚本的执行不受 XXT 服务状态的影响
只要安装了 XXT 就能执行
但服务状态不正常时，该脚本部分功能也会失效，例如 sys.toast 不一定能显示
测试 XXT-BATCH-DISCONNECT 回显指令，在 sh 脚本中应该使用 echo XXT-BATCH-DISCONNECT 来替代 print('XXT-BATCH-DISCONNECT')
--]]

for i=1,10 do
    if i > 3 then
        print('设备列表中最后一条状态')
        print('XXT-BATCH-DISCONNECT')
        sys.toast("同步执行不会回显"..i.."……")
        print('同步执行不会回显'..i..'……', ...)
    else
        sys.toast("同步执行会回显"..i.."……")
        print('同步执行会回显'..i..'……', ...)
    end
    sys.msleep(1000)
end

sys.toast("测试完成！")
print('测试完成！')
os.exit(0)