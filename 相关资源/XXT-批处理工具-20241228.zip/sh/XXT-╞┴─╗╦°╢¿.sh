#!/bin/bash

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

XXT=$VARJB/usr/bin/1ferver/ReportCrash
XXTNG=$VARJB/usr/local/xxtouch/bin/lua

if [ -x "$XXT" ];then
    $XXT eval "key.press(0x0C,48)device.lock_screen()device.reset_idle()sys.msleep(500)print('屏幕已锁定')" 2>/dev/null
    ec=$?
elif [ -x "$XXTNG" ];then
    export PATH="$VARJB/usr/local/xxtouch/bin:$PATH"
    export LUA_PATH="/var/mobile/Media/1ferver/lua/scripts/?.lua;/var/mobile/Media/1ferver/lua/scripts/?/init.lua;/var/mobile/Media/1ferver/lua/scripts/?.xxt;/var/mobile/Media/1ferver/lua/scripts/?/init.xxt;/var/mobile/Media/1ferver/lua/?.lua;/var/mobile/Media/1ferver/lua/?/init.lua;$VARJB/usr/local/xxtouch/lib/?.lua;$VARJB/usr/local/xxtouch/lib/?/init.lua;./?.lua;./?/init.lua"
    export LUA_INIT="@$VARJB/usr/local/xxtouch/lib/xxtouch/init.lua"
    export CURL_CA_BUNDLE="$VARJB/usr/local/xxtouch/lib/ssl/curl-ca-bundle.crt"
    export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
    echo "key.press(0x0C,48)device.lock_screen()device.reset_idle()sys.msleep(500)print('屏幕已锁定')" | $XXTNG
    ec=$?
else
    echo 该设备还没装 XXT 呢
    ec=0
fi

if [ "$ec" != "0" ];then
   echo 启动脚本失败，无法与 XXT 服务通讯
fi