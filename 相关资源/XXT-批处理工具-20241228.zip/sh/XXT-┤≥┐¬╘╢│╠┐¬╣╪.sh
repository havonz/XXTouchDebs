#!/bin/bash

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

XXT=$VARJB/usr/bin/1ferver/ReportCrash
XXTNG=$VARJB/usr/local/xxtouch/bin/lua

if [ -x "$XXT" ];then
    $XXT eval "os.execute('killall -9 cfprefsd')
local tab = plist.read('/var/mobile/Library/Preferences/com.xxtouch.XXTExplorer.plist') or {}
tab['XXTEAgreementVersion-1.2'] = true
plist.write('/var/mobile/Library/Preferences/com.xxtouch.XXTExplorer.plist', tab)
os.execute('killall -9 cfprefsd')
c=http.post('http://127.0.0.1:46952/open_remote_access')
if c~=200 then
os.exit(255)
end
c,_,r=http.post('http://127.0.0.1:46952/set_user_conf',3,'{}','{\"no_idle\":true,\"device_control_toggle\":true,\"launch_daemons\":true}')
if c~=200 then
os.exit(255)
end
os.exit(0)" 2>/dev/null
    if [ "$?" != "0" ];then
        echo {\"device_control_toggle\":true,\"allow_remote_access\":true,\"no_idle\":true,\"launch_daemons\":true,\"current_script\":\"\\/private\\/var\\/mobile\\/Media\\/1ferver\\/lua\\/scripts\\/1.lua\"} > /private/var/mobile/Media/1ferver/1ferver.conf
        $XXT restart
    fi
    echo XXT 远程开关已打开
elif [ -x "$XXTNG" ];then
    export PATH="$VARJB/usr/local/xxtouch/bin:$PATH"
    export LUA_PATH="/var/mobile/Media/1ferver/lua/scripts/?.lua;/var/mobile/Media/1ferver/lua/scripts/?/init.lua;/var/mobile/Media/1ferver/lua/scripts/?.xxt;/var/mobile/Media/1ferver/lua/scripts/?/init.xxt;/var/mobile/Media/1ferver/lua/?.lua;/var/mobile/Media/1ferver/lua/?/init.lua;$VARJB/usr/local/xxtouch/lib/?.lua;$VARJB/usr/local/xxtouch/lib/?/init.lua;./?.lua;./?/init.lua"
    export LUA_INIT="@$VARJB/usr/local/xxtouch/lib/xxtouch/init.lua"
    export CURL_CA_BUNDLE="$VARJB/usr/local/xxtouch/lib/ssl/curl-ca-bundle.crt"
    export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
    $XXTNG $VARJB/usr/local/xxtouch/bin/remote-access.lua on
    if [ "$?" != "0" ];then
        echo XXTNG 远程开关已打开
    fi
fi
