#!/bin/bash

# 本软件支持使用回显 XXT-BATCH-COPY-TO-PC: 跟文件名通知电脑将文件给下载回去
# 设备端仅支持绝对路径，不支持设置电脑上的下载目录，只能是 XXT-BATCH-COPYFILE/{设备IP}/ 这个目录
# 例如可以将脚本打包好，然后回显让电脑将文件下载回去
# 回显和下载是异步的，不要回显完了立刻删文件，这样会导致下载失败
# 可以将文件打包到 /tmp/ 目录中，等回过头一起清理，或者系统重启会自动清理
# 以下是示例：

tar cf /private/var/tmp/scripts.tar.gz -C /private/var/mobile/Media/1ferver/lua/ scripts
echo "XXT-BATCH-COPY-TO-PC:/private/var/tmp/scripts.tar.gz"

# sleep 5
# rm -f /private/var/tmp/scripts.tar.gz