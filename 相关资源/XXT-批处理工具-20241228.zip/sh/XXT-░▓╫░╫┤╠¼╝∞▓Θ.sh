#!/bin/bash

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

XXT=$VARJB/usr/bin/1ferver/ReportCrash
XXTNG=$VARJB/usr/local/xxtouch/bin/lua

if [ ! -x "$XXT" ];then
    if [ ! -x "$XXTNG" ];then
        echo 该设备尚未安装 XXT
        exit 1
    fi
fi

xxtv=`dpkg -s com.1func.xxtouch.bigboss 2>/dev/null | grep -i version`
if [ "$xxtv" == "" ];then
    xxtv=`dpkg -s app.xxtouch.ios 2>/dev/null | grep -i version`
fi
if [ "$xxtv" == "" ];then
    xxtv=`dpkg -s ch.xxtou.xxtouch 2>/dev/null | grep -i version`
fi

if [ "$xxtv" == "" ];then
    echo Version: ?
else
    echo $xxtv
fi
