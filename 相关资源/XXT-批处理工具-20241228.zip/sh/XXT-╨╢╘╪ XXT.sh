#!/bin/bash

PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1

echo 正在从 Cydia 卸载 XXT ...
dpkg -P com.1func.xxtouch.bigboss 2> /dev/null
dpkg -P com.1func.xxtouch.ios 2> /dev/null
dpkg -P com.1func.xxtouch 2> /dev/null
dpkg -P com.xxtouch.ios 2> /dev/null
dpkg -P app.xxtouch.ios 2> /dev/null
dpkg -P ch.xxtou.xxtouch 2> /dev/null
echo 卸载完成