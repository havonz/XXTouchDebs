#!/bin/bash

echo DPKG 解锁指令已送达
echo XXT-BATCH-DISCONNECT

rm -f /var/lib/dpkg/lock
rm -f /var/lib/dpkg/lock-frontend
rm -f /var/jb/var/lib/dpkg/lock
rm -f /var/jb/var/lib/dpkg/lock-frontend