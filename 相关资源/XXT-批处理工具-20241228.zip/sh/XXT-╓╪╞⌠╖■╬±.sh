#!/bin/bash

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

killall -9 killall 2>/dev/null
killall -9 kill 2>/dev/null
killall -9 rm 2>/dev/null
killall -9 add1s 2>/dev/null
killall -9 sleep 2>/dev/null
killall -9 unset 2>/dev/null
killall -9 lua 2>/dev/null
killall -9 ReportCrash 2>/dev/null
killall -9 webserv 2>/dev/null

PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1

if [ -f "$VARJB/Library/LaunchDaemons/ch.xxtou.webserv.plist" ];then
    launchctl unload "$VARJB/Library/LaunchDaemons/ch.xxtou.webserv.plist"
    launchctl load "$VARJB/Library/LaunchDaemons/ch.xxtou.webserv.plist"
    launchctl kickstart -k system/ch.xxtou.webserv
    echo XXTNG 重启指令已送达
elif [ -f "$VARJB/Library/LaunchDaemons/com.1func.xxtouch.plist" ];then
    launchctl unload "$VARJB/Library/LaunchDaemons/com.1func.xxtouch.plist"
    launchctl load "$VARJB/Library/LaunchDaemons/com.1func.xxtouch.plist"
    launchctl kickstart -k system/com.1func.xxtouch 2>/dev/null
    echo XXT 重启指令已送达
elif [ -f "$VARJB/Library/LaunchDaemons/app.xxtouch.ios.plist" ];then
    launchctl unload "$VARJB/Library/LaunchDaemons/app.xxtouch.ios.plist"
    launchctl load "$VARJB/Library/LaunchDaemons/app.xxtouch.ios.plist"
    launchctl kickstart -k system/app.xxtouch.ios 2>/dev/null
    echo XXT 重启指令已送达
elif [ -f "$VARJB/usr/bin/1ferver/ReportCrash" ];then
    $VARJB/usr/bin/1ferver/ReportCrash restart 2>/dev/null
    echo XXT 重启指令已送达
fi

sleep 1 2>/dev/null
killall -9 sleep bash sh 2>/dev/null