#!/bin/bash

VARJB=
[ -d /private/var/jb/usr/bin ] && VARJB=/private/var/jb

PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1

if [ -f "$VARJB/usr/local/xxtouch/bin/uninstall-xxtouch.sh" ];then
    chmod 4755 $VARJB/usr/local/xxtouch/bin/uninstall-xxtouch.sh
    $VARJB/usr/local/xxtouch/bin/uninstall-xxtouch.sh
else
    echo 从 Cydia 卸载 XXT...
    dpkg -P com.1func.xxtouch.bigboss > /dev/null 2>&1
    dpkg -P com.1func.xxtouch.ios > /dev/null 2>&1
    dpkg -P com.1func.xxtouch > /dev/null 2>&1
    dpkg -P com.xxtouch.ios > /dev/null 2>&1
    dpkg -P app.xxtouch.ios > /dev/null 2>&1
    dpkg -P ch.xxtou.xxtouch > /dev/null 2>&1

    killall -9 XXTExplorer > /dev/null 2>&1
    rm -rf $VARJB/Applications/XXTExplorer.app > /dev/null 2>&1
    rm -rf $VARJB/usr/local/xxtouch > /dev/null 2>&1
    rm -rf $VARJB/usr/bin/1ferver > /dev/null 2>&1
    rm -rf $VARJB/usr/bin/tmp > /dev/null 2>&1
    rm -rf /var/mobile/Media/1ferver > /dev/null 2>&1
    rm -rf /var/mobile/Library/Caches/ch.xxtou.* > /dev/null 2>&1
    rm -rf /var/mobile/Library/Preferences/ch.xxtou.* > /dev/null 2>&1
    rm -rf /var/mobile/Library/WebClips/1ferver.webclip > /dev/null 2>&1
    rm -rf /var/mobile/Library/Caches/com.*.XXTExplorer* > /dev/null 2>&1
    rm -rf /var/root/Library/Preferences/com.*.XXTExplorer.* > /dev/null 2>&1
    rm -rf /var/root/Library/Cookies/ReportCrash.binarycookies > /dev/null 2>&1
    rm -rf /var/mobile/Library/Caches/com.xxtouch.* > /dev/null 2>&1
    rm -rf /var/mobile/Library/Preferences/com.xxtouch.* > /dev/null 2>&1
    rm -rf /var/tmp/com.*.XXTExplorer* > /dev/null 2>&1
    rm -rf /var/tmp/ch.xxtou.* > /dev/null 2>&1
    rm -rf /var/tmp/xxt* > /dev/null 2>&1
    rm -rf /var/tmp/iOSZerver* > /dev/null 2>&1
    rm -rf /var/tmp/1ferver* > /dev/null 2>&1
    rm -rf /var/tmp/NSIRD_* > /dev/null 2>&1
    rm -rf /var/lib/dpkg/info/com.xxtouch* > /dev/null 2>&1
    rm -rf /var/lib/dpkg/info/com.1func.xxtouch* > /dev/null 2>&1
    rm -rf /var/lib/dpkg/info/app.xxtouch* > /dev/null 2>&1
    echo 重建图标缓存...
    uicache --all > /dev/null 2>&1
    echo 软重启设备...
    ldrestart > /dev/null 2>&1
    killall -9 ReportCrash > /dev/null 2>&1
    echo 清除完毕
fi