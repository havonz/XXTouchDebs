#!/bin/bash

# 本软件支持使用回显 XXT-BATCH-COPY-FROM-PC: 跟文件名通知电脑将传送文件回设备
# 传送回来的文件放入 /private/var/tmp/ 目录，电脑上的路径只能是 XXT-BATCH-COPYFILE/{设备IP}/ 这个目录的相对路径
# 回显和传送是异步的，不要回显完了立刻使用文件
# 以下是示例：

rm -f /private/var/tmp/scripts.tar.gz
echo "XXT-BATCH-COPY-FROM-PC:scripts.tar.gz"
echo "等待脚本传送..."

for ((i=1;i<=10;i++));do
	sleep 1
	if [ -f "/private/var/tmp/scripts.tar.gz" ]; then
		echo "解压脚本..."
		sleep 3
		tar -xf /private/var/tmp/scripts.tar.gz -C /private/var/mobile/Media/1ferver/lua/
		rm -f /private/var/tmp/scripts.tar.gz
		echo "脚本恢复完成"
		exit 0
	fi
done

echo "错误：等待 PC 传送脚本超时！"
