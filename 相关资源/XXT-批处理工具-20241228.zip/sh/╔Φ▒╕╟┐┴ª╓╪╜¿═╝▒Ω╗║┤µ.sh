#!/bin/bash

echo 正在重建图标缓存...
PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1
su mobile -c "uicache --all" >/dev/null 2>&1
echo 完成
