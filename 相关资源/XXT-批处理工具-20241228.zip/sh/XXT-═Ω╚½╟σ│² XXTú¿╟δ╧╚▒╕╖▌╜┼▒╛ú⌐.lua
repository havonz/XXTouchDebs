function file_reads(fn)
	local f = io.open(fn, 'r')
	if (f) then
		local s = f:read('*a')
		f:close()
		return s
	else
		return ''
	end
end

function file_writes(fn, s)
	local f = io.open(fn, 'w')
	if (f) then
		local s = f:write(s)
		f:close()
		return true
	else
		return false
	end
end

pcall(function()
print('从 Cydia 安装列表剔除 XXT...')
local s = file_reads('/var/lib/dpkg/status')
local t = s:split('\n\n')
local need_remove = {}
for i=#t, 1, -1 do
	local s = (t[i]:split('\n'))[1]
	if s:find('xxtou') then
		need_remove[#need_remove + 1] = i
	end
end
for _,i in ipairs(need_remove) do
	table.remove(t, i)
end
if #need_remove > 0 then
	local dpkg_status_ctx = table.concat(t, '\n\n')
	file_writes('/var/lib/dpkg/status', dpkg_status_ctx)
	file_writes('/var/lib/dpkg/status-old', dpkg_status_ctx)
end
end)

os.execute[[
echo 清除文件...
PIDS=$(ps axo stat,pid | grep "^T" | sed 's/\([^0-9]*\)//' | sed 's/\n/ /g')
kill -9 $PIDS >/dev/null 2>&1
killall -9 XXTExplorer > /dev/null 2>&1
rm -rf /Applications/XXTExplorer.app > /dev/null 2>&1
rm -rf /usr/local/xxtouch > /dev/null 2>&1
rm -rf /usr/bin/1ferver > /dev/null 2>&1
rm -rf /var/jb/Applications/XXTExplorer.app > /dev/null 2>&1
rm -rf /var/jb/usr/local/xxtouch > /dev/null 2>&1
rm -rf /var/jb/usr/bin/1ferver > /dev/null 2>&1
rm -rf /var/mobile/Media/1ferver > /dev/null 2>&1
rm -rf /var/mobile/Library/Caches/ch.xxtou.* > /dev/null 2>&1
rm -rf /var/mobile/Library/Preferences/ch.xxtou.* > /dev/null 2>&1
rm -rf /var/mobile/Library/WebClips/1ferver.webclip > /dev/null 2>&1
rm -rf /var/mobile/Library/Caches/com.*.XXTExplorer* > /dev/null 2>&1
rm -rf /var/root/Library/Preferences/com.*.XXTExplorer.* > /dev/null 2>&1
rm -rf /var/root/Library/Cookies/ReportCrash.binarycookies > /dev/null 2>&1
rm -rf /var/mobile/Library/Caches/com.xxtouch.* > /dev/null 2>&1
rm -rf /var/mobile/Library/Preferences/com.xxtouch.* > /dev/null 2>&1
rm -rf /var/lib/dpkg/info/com.xxtouch* > /dev/null 2>&1
rm -rf /var/lib/dpkg/info/com.1func.xxtouch* > /dev/null 2>&1
rm -rf /var/lib/dpkg/info/app.xxtouch* > /dev/null 2>&1
rm -rf /var/tmp/com.*.XXTExplorer* > /dev/null 2>&1
rm -rf /var/tmp/ch.xxtou.* > /dev/null 2>&1
rm -rf /var/tmp/xxt* > /dev/null 2>&1
rm -rf /var/tmp/1ferver* > /dev/null 2>&1
rm -rf /var/tmp/NSIRD_* > /dev/null 2>&1
echo 重建图标缓存...
uicache --all > /dev/null 2>&1
echo 软重启设备...
ldrestart > /dev/null 2>&1
killall -9 ReportCrash > /dev/null 2>&1
echo 清除完毕
]]