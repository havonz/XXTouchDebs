#!/bin/bash
# 文件使用 UTF-8 编码
# 注意不要使用 Windows 换行符
# 不要使用 Windows 自带的记事本编辑保存本文件
# 建议使用专业的文本编辑器编辑本文件

echo IP地址：$1

DPKGARCH=$(dpkg --print-architecture)

if [ "$DPKGARCH" == "iphoneos-arm" ]; then
    rm -f *iphoneos-arm64.deb *iphoneos-arm64-*.deb
    rm -f *iphoneos-arm64e.deb *iphoneos-arm64e-*.deb
    if [ -d sileo-debs ]; then
        rm -f sileo-debs/*iphoneos-arm64.deb sileo-debs/*iphoneos-arm64-*.deb
        rm -f sileo-debs/*iphoneos-arm64e.deb sileo-debs/*iphoneos-arm64e-*.deb
    fi
elif [ "$DPKGARCH" == "iphoneos-arm64" ]; then
    rm -f *iphoneos-arm.deb *iphoneos-arm-*.deb
    rm -f *iphoneos-arm64e.deb *iphoneos-arm64e-*.deb
    if [ -d sileo-debs ]; then
        rm -f sileo-debs/*iphoneos-arm.deb sileo-debs/*iphoneos-arm-*.deb
        rm -f sileo-debs/*iphoneos-arm64e.deb sileo-debs/*iphoneos-arm64e-*.deb
    fi
    dpkg -i sileo-debs/*.deb *.deb
elif [ "$DPKGARCH" == "iphoneos-arm64e" ]; then
    rm -f *iphoneos-arm.deb *iphoneos-arm-*.deb
    rm -f *iphoneos-arm64.deb *iphoneos-arm64-*.deb
    if [ -d sileo-debs ]; then
        rm -f sileo-debs/*iphoneos-arm.deb sileo-debs/*iphoneos-arm-*.deb
        rm -f sileo-debs/*iphoneos-arm64.deb sileo-debs/*iphoneos-arm64-*.deb
    fi
fi

rmdir sileo-debs >/dev/null 2>&1
rmdir cydia-debs >/dev/null 2>&1
rmdir ios11-below-cydia-debs >/dev/null 2>&1

echo 安装 deb 包...
cfv=$(cfversion)
if [[ ${#cfv} -eq 7 && $cfv < 1443.00 ]]; then # < iOS 11
    if [ -d ios11-below-cydia-debs ]; then
        dpkg -i ios11-below-cydia-debs/*.deb
    fi
else
    if [ "$DPKGARCH" == "iphoneos-arm" ] && [ -d "/Applications/Cydia.app" ]; then
        if [ -d cydia-debs ]; then
            dpkg -i cydia-debs/*.deb
        fi
    else
        if [ -d sileo-debs ]; then
            dpkg -i sileo-debs/*.deb
        fi
    fi
fi
dpkg -i *.deb

echo 配置脚本...
VARJB=
[ -d /var/jb/usr/bin ] && VARJB=/private/var/jb
XXTLIBDIR=$VARJB/usr/bin/1ferver/lib
XXTNGLIBDIR=$VARJB/usr/local/xxtouch/lib
if [ -d "$XXTLIBDIR" ];then
    mv -f *.so $XXTLIBDIR/ >/dev/null 2>&1
elif [ -d "$XXTNGLIBDIR" ];then
    mv -f *.so $XXTNGLIBDIR/ >/dev/null 2>&1
fi

XXTSCRIPTDIR=/var/mobile/Media/1ferver/lua/scripts
if [ -d "$XXTSCRIPTDIR" ];then
    mv -f *.lua $XXTSCRIPTDIR/ >/dev/null 2>&1
fi
