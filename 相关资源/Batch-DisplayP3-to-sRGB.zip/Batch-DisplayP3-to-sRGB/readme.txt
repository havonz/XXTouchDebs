将 iOS 设备相册中导出的 png 文件放入 input 目录
双击 DisplayP3-input-to-sRGB-output.bat
转换好的图片会输出到 output 目录中

Put the exported png file from the album on your iOS device into the input directory 
Double-click DisplayP3-input-to-sRGB-output.bat 
The converted image is output to the output directory