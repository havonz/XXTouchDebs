
require("scripts.colorpicker.keymap_tools")
local VK = require("scripts.virtual_keycodes")

-- 直接按键
local SK_PRESS_ = {
    [ VK["{A}"		] ] = posToRegA, -- 直接按 A
    [ VK["{S}"		] ] = posToRegS,
    [ VK["{X}"		] ] = posToRegX,
    [ VK["{C}"		] ] = posToRegC,
    [ VK["{D}"		] ] = copyRectAS,
    [ VK["{Z}"		] ] = clearAllColorRegisters,
    [ VK["{F}"		] ] = makeScripts,
    [ VK["{W}"		] ] = reloadPasteboard,
    [ VK["{J}"		] ] = viewRotateLeft,
    [ VK["{K}"		] ] = viewRotateRight,
    [ VK["{UP}"		] ] = moveMouseUp,
    [ VK["{DOWN}"	] ] = moveMouseDown,
    [ VK["{LEFT}"	] ] = moveMouseLeft,
    [ VK["{RIGHT}"	] ] = moveMouseRight,
    [ VK["{NEWLINE}"] ] = pickToNextColorRegister,
    [ VK["{RETURN}"	] ] = pickToNextColorRegister,
    [ VK["{E}"		] ] = x_AS_XC,
    [ VK["{R}"		] ] = repickColor,
}

for i=0,9 do
    SK_PRESS_[ VK["{"..(i).."}"] ] = function()
        pickToColorRegister(i)
    end
end


-- Shift + 按键
local SK_SHIFT_ = {
    [ VK["{A}"		] ] = moveMouseToPosOfRegA, -- 按住 Shift 键再按 A
    [ VK["{S}"		] ] = moveMouseToPosOfRegS,
    [ VK["{X}"		] ] = moveMouseToPosOfRegX,
    [ VK["{C}"		] ] = moveMouseToPosOfRegC,
    [ VK["{D}"		] ] = copyRectXC,
    [ VK["{UP}"		] ] = moveMouseUp,
    [ VK["{DOWN}"	] ] = moveMouseDown,
    [ VK["{LEFT}"	] ] = moveMouseLeft,
    [ VK["{RIGHT}"	] ] = moveMouseRight,
    [ VK["{E}"		] ] = eraseRectAS,
}

for i=0,9 do
    SK_SHIFT_[ VK["{"..(i).."}"] ] = function()
        clearColorRegisterByIndex(i)
    end
end

-- Ctrl + 按键
local SK_CTRL_ = {
    [ VK["{UP}"		] ] = moveMouseUp10, -- 按住 Ctrl 键再按 ↑
    [ VK["{DOWN}"	] ] = moveMouseDown10,
    [ VK["{LEFT}"	] ] = moveMouseLeft10,
    [ VK["{RIGHT}"	] ] = moveMouseRight10,
    [ VK["{W}"      ] ] = closeCurrentImageTab,
    [ VK["{C}"		] ] = function()
        local a, s = getPosASXC()
        if isASRectShow() and a.x~=s.x and a.y~=s.y then
            local noerr, data = pcall(getRectPNGData, a.x, a.y, s.x, s.y)
            if noerr then
                writePasteboard(data)
            else
                alertErr(data)
            end
        else
            local w, h = getImageSize()
            local noerr, data = pcall(getRectPNGData, 0, 0, w-1, h-1)
            if noerr then
                writePasteboard(data)
            else
                alertErr(data)
            end
        end
    end,
    [ VK["{V}"		] ] = function()
        local data = readPasteboard()
        local noerr, msg = pcall(loadImageData, data)
    end,
}

-- Alt + 按键
local SK_ALT_ = {
    [ VK["{D}"		] ] = function()
        alert("Alt + D")
    end,
}


-- Ctrl + Shift + 按键
local SK_CTRL_SHIFT_ = {

}


-- Ctrl + Alt + 按键
local SK_CTRL_ALT_ = {

}


-- Alt + Shift + 按键
local SK_ALT_SHIFT_ = {

}


-- Ctrl + Alt + Shift + 按键
local SK_CTRL_ALT_SHIFT_ = {

}


------------------------------------------------------------------------------
return {
    SK_PRESS_,
    SHIFT = SK_SHIFT_,
    CTRL = SK_CTRL_,
    ALT = SK_ALT_,
    CTRL_SHIFT = SK_CTRL_SHIFT_,
    CTRL_ALT = SK_CTRL_ALT_,
    ALT_SHIFT = SK_ALT_SHIFT_,
    CTRL_ALT_SHIFT = SK_CTRL_ALT_SHIFT_,
}