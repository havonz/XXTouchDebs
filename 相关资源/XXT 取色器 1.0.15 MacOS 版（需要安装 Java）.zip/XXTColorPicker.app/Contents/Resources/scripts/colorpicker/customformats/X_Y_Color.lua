require("scripts.colorpicker.customformats")

return {
	name = "X, Y, Color",
	description = "X, Y, Color",
	formats = {
		settingsRule = {
			title = "自定义格式 [X, Y, Color] 的参数设置",
			args = {
				{"is_colors 相似度",
					85, -- 默认值为数字，且第三个参数用一个表描述范围则用一个 Slider（滑动条） 描述
					{
						 1,   -- Slider 的最小值
						 100, -- Slider 的最大值
					},
				},
				{"空格补齐", true}, -- 默认值是布尔类型则控件用 CheckBox（勾选框） 描述
				{"换行格式", true},
				{"色偏模式", false},
				{"默认色偏", 101010}, -- 默认值是字符串或者数字且没有第三个参数则用 TextFeild（文本框） 描述
				{"XXTDo 动作",
				 	"点取色列表最后一个点",
					{"点取色列表第一个点", "点取色列表最后一个点", "点击 A 点", "点击 S 点", "点击 X 点", "点击 C 点", "自定义动作代码"},
				},
				{"XXTDo 动作自定义代码", "local ui = type(self.group) == 'table' and self.group[1] or self;touch.tap(ui[#ui][1], ui[#ui][2])"},
				{"选项示例1",
					"选项1", -- 默认值是字符串且第三个参数用一个表描述则是一个 ComboBox（下拉选项框）
					{ -- 选项列表
						 "选项1",
						 "选项2",
						 "选项3",
					},
					false, -- ComboBox 是否可以编辑输入文本
				},
				{"选项示例2",
					"选项1", -- 默认值是字符串且第三个参数用一个表描述则是一个 ComboBox（下拉选项框）
					{ -- 选项列表
						 "选项1",
						 "选项2",
						 "选项3",
					},
					true, -- ComboBox 是否可以编辑输入文本
				},
				{"测试示例1", true},
				{"测试示例2", "测试示例2"},
				{"测试示例3", 3, {1, 10}},
			},
		},
		singlePosFormatRule = (function(p, a, s, x, c, set)
			local fmt = string.format("%4d, %4d, 0x%06x ", p.x, p.y, p.c)
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			return fmt
		end),
		multiPosFormatRule = (function(p, a, s, x, c, set)
			local fmt = string.format(" %4d, %4d, 0x%06x \n", p.x, p.y, p.c)
			if not toboolean(set["换行格式"]) then
				fmt = fmt:gsub("\n", ""):gsub("\t", "")
			end
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			return fmt
		end),
		mouseTrackInfoBottomRule = (function(p, a, s, x, c, set)
			return string.format("XY: (%4d, %4d)      Color: 0x%06x      RGB: (%3d, %3d, %3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end),
		mouseTrackInfoZoomRule = (function(p, a, s, x, c, set)
			return string.format("(%4d,%4d):0x%06x:(%3d,%3d,%3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end),
		makeScriptRules = {
			{
				maker = function(poslist, set)
					local fmt = "\t{ %4d, %4d, 0x%06x},\n"
					if #poslist < 1 then
						return "框架表 {}：需要至少取 1 个点颜色"
					end
					local ret = "{\n"
					for _,currentPos in ipairs(poslist) do
						ret = ret..string.format(fmt, currentPos.x, currentPos.y, currentPos.c)
					end
					ret = ret.."}"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("\n", ""):gsub("\t", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("通用点色框架表，用于各种脚本框架，需要开发者自行解析使用", "说明")
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					local fmt = "{ %4d, %4d, 0x%06x},\n"
					if #poslist < 1 then
						return "框架无包裹：需要至少取 1 个点颜色"
					end
					local ret = ""
					for _,currentPos in ipairs(poslist) do
						ret = ret..string.format(fmt, currentPos.x, currentPos.y, currentPos.c)
					end
					ret = ret..""
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("\n", ""):gsub("\t", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("通用点色框架列表，用于各种脚本框架，需要开发者自行解析使用", "说明")
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					local fmt = "\t\t\t{ %4d, %4d, 0x%06x},\n"
					if #poslist < 1 then
						return "XXTDo 框架界面组：需要至少取 1 个点颜色"
					end
					local ret = string.format("{name = '__UI_%s__', group = {\n\t\t", os.date('%Y%m%d%H%M%S'))
					local cen = "{\n"
					for _,currentPos in ipairs(poslist) do
						cen = cen..string.format(fmt, currentPos.x, currentPos.y, currentPos.c)
					end
					cen = cen.."\t\t},"
					if not toboolean(set["空格补齐"]) then
						cen = cen:gsub(" ", "")
					end
					if not toboolean(set["换行格式"]) then
						cen = cen:gsub("\n", ""):gsub("\t", "")
					end
					-- {"点取色列表第一个点", "点取色列表最后一个点", "点击 A 点", "点击 S 点", "点击 X 点", "点击 C 点", "自定义动作代码"},
					ret = ret..cen.."\n\t},\n\trun = function(self, index, parent)"
					local act = "\n\t\t"
					if set["XXTDo 动作"] == "点取色列表第一个点" then
						act = act..string.format("touch.tap(%d, %d)", poslist[1].x, poslist[1].y)
					elseif set["XXTDo 动作"] == "点取色列表最后一个点" then
						act = act..string.format("touch.tap(%d, %d)", poslist[#poslist].x, poslist[#poslist].y)
					elseif set["XXTDo 动作"] == "点击 A 点" then
						act = act..string.format("touch.tap(%d, %d)", poslist.a.x, poslist.a.y)
					elseif set["XXTDo 动作"] == "点击 S 点" then
						act = act..string.format("touch.tap(%d, %d)", poslist.s.x, poslist.s.y)
					elseif set["XXTDo 动作"] == "点击 X 点" then
						act = act..string.format("touch.tap(%d, %d)", poslist.x.x, poslist.x.y)
					elseif set["XXTDo 动作"] == "点击 C 点" then
						act = act..string.format("touch.tap(%d, %d)", poslist.c.x, poslist.c.y)
					end
					if set["XXTDo 动作"] == "自定义动作代码" then
						act = act..string.format("%s", set["XXTDo 动作自定义代码"] or "")
						act = act.."\n\t"
					else
						act = act.."\n\t"
						if not toboolean(set["空格补齐"]) then
							cen = cen:gsub(" ", "")
						end
						if not toboolean(set["换行格式"]) then
							act = act:gsub("\n", ""):gsub("\t", "")
						end
					end
					ret = ret..act
					if not toboolean(set["换行格式"]) then
						ret = ret.." " -- 不是换行格式在 end 前加个空格
					end
					ret = ret.."end,\n},\n"
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("抓取一个用于 XXTDo 框架使用的界面触发器\n配合 XXTDo 框架使用", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							local code = [[success, XXTDo = pcall(require, 'XXTDo')
							if not success then
								local XXTDoPath = '/var/mobile/Media/1ferver/lua/XXTDo.lua'
								nLog('测试改代码需要 XXTDo 框架\n请导入 XXTDo.lua 到设备路径 '..XXTDoPath)
								local ip, port = nLog()
								local success, c, h, r = pcall(http.get, string.format('http://%s:%d/XXTDo.lua', ip, port))
								if success and c == 200 then
									file.writes(XXTDoPath, r)
									nLog('已自动导入 XXTDo.lua 到 '..XXTDoPath)
									success, XXTDo = pcall(require, 'XXTDo')
									if not success then
										nLog('自动导入 XXTDo.lua 失败\n请手动导入 XXTDo.lua 到设备路径 '..XXTDoPath)
										os.exit()
									end
								else
									nLog('自动导入 XXTDo.lua 失败\n请手动导入 XXTDo.lua 到设备路径 '..XXTDoPath)
									os.exit()
								end
							end
							nLog("测试开始，XXTDo 超时时间 5 秒，超时未匹配则跳出")
							XXTDo.runloop{name = "XXTColorPicker-于设备测试",
							log = nLog, timeout_s = 5, timeout_run = function() XXTDo.breakloop() end, error = function(errmsg) nLog("脚本运行期错误详情：", json.decode(errmsg)) os.exit() end,]]
							code = code..s..[[}]]
							if load(code) then
								Java.newThread(function()
									uploadScriptAndRun(code)
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "is_colors：需要至少取 1 个点颜色"
					end
					local ret = "if (screen.is_colors({\n"
					for i,currentPos in ipairs(poslist) do
						ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
					end
					ret = ret.."}, "..set["is_colors 相似度"]..")) then"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("\n", ""):gsub("\t", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("这个格式专用于 XXTouch 定义的函数 screen.is_colors 多点匹配色", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							local code = isColorCodeDefine..s..[[
									nLog("匹配")
								else
									nLog("不匹配")
								end
							]]
							if load(code) then
								Java.newThread(function()
									uploadScriptAndRun(code)
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "find_color-1：需要至少取 1 个点颜色，保留绝对坐标信息"
					end
					local ret = "x, y = screen.find_color({\n"
					for i,currentPos in ipairs(poslist) do
						if toboolean(set["色偏模式"]) then
							ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", currentPos.x, currentPos.y, currentPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
						else
							ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
						end
					end
					if toboolean(set["色偏模式"]) then
						ret = ret.."}"
					else
						ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
					end
					if (0 ~= poslist.a.x) and
							(0 ~= poslist.a.y) and
							(0 ~= poslist.s.x) and
							(0 ~= poslist.s.y) then
						ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
					end
					ret = ret..")"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("[\n\t]", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = function(s, idx, poslist, set)
					if load(s) then
						return {
							{
								name = "查看说明",
								action = function(s, idx)
									alert("这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色\n抓取的所有坐标都是绝对坐标，但不影响找色，所有坐标都以第一点为相对位置", "说明")
								end,
							},
							{
								name = "于设备测试",
								action = function(s, idx)
									if load(s) then
										Java.newThread(function()
											uploadScriptAndRun(s..[[
										nLog("多点找色结果："..tostring(x)..", "..tostring(y))
									]])
										end):start()
									else
										alert("请按要求生成自定义代码。", "无法测试")
									end
								end,
							},
						}
					end
				end,
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "find_color-2：需要至少取 1 个点颜色，仅抓取相对坐标"
					end
					local ret = "x, y = screen.find_color({\n"
					local firstPos
					for i,currentPos in ipairs(poslist) do
						if (1 == i) then
							firstPos = currentPos
							if toboolean(set["色偏模式"]) then
								ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", 0, 0, firstPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
							else
								ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", 0, 0, firstPos.c)
							end
						else
							ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x - firstPos.x, currentPos.y - firstPos.y, currentPos.c)
						end
					end
					if toboolean(set["色偏模式"]) then
						ret = ret.."}"
					else
						ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
					end
					if (0 ~= poslist.a.x) and
							(0 ~= poslist.a.y) and
							(0 ~= poslist.s.x) and
							(0 ~= poslist.s.y) then
						ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
					end
					ret = ret..")"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("[\n\t]", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = function(s, idx, poslist, set)
					if load(s) then
						return {
							{
								name = "查看说明",
								action = function(s, idx)
									alert("这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色\n仅抓取相对坐标，不保留绝对坐标信息", "说明")
								end,
							},
							{
								name = "于设备测试",
								action = function(s, idx)
									if load(s) then
										Java.newThread(function()
											uploadScriptAndRun(s..[[
										nLog("多点找色结果："..tostring(x)..", "..tostring(y))
									]])
										end):start()
									else
										alert("请按要求生成自定义代码。", "无法测试")
									end
								end,
							},
						}
					end
				end,
			},
			{
				maker = function(poslist, set)
					local tl = poslist.a
					local br = poslist.s
					if br.x <= tl.x and br.y <= tl.y then
						return "ocr_text：使用 [Shift + 鼠标左键] 框选需要识别的区域"
					end
					return string.format("txt, info = screen.ocr_text(%d, %d, %d, %d, {lang = 'eng'})", tl.x, tl.y, br.x, br.y)
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx, poslist, set)
							alert("这个格式专用于 XXTouch 定义的函数 screen.ocr_text 屏幕文字识别函数\n使用 [Shift + 鼠标左键] 框选需要识别的文字区域", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							if load(s) then
								Java.newThread(function()
									uploadScriptAndRun(s..[[
									nLog("screen.ocr_text 文字识别测试结果：", txt, info)
									]])
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					local a = poslist.a
					local s = poslist.s
					local x = poslist.x
					local c = poslist.c
					local ex, ey = getImageSize()
					if a.x~=s.x and a.y~=s.y and a.x > 0 and a.y > 0 and s.x < ex and s.y < ey then
						--					local function s2h(s,cp)return(string.gsub(s,"(.)",function(c)return string.format("\\x%02x%s",string.byte(c),cp or"")end))end
						--					return 'local x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..s2h(getRectPNGData(a.x, a.y, s.x, s.y))..'"\n, 95, __这里替换成区域__)'
						local noerr, xdata = pcall(getRectPNGDataHex, a.x, a.y, s.x, s.y)
						if noerr then
							if (not (x.x==x.y and c.x==c.y)) and -- 区域不为 0, 0, 0, 0
									x.x~=c.x and x.y~=c.y and x.x > 0 and x.y > 0 and --[[c.x < ex and c.y < ey and--]]
									x.x<=a.x and x.y<=a.y and c.x>=s.x and c.y>=s.y -- XC选区范围大于AS选区
							then
								return 'x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..xdata..'"\n, 95, '..string.format("%d, %d, %d, %d)", x.x, x.y, c.x, c.y)
							else
								return 'x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..xdata..'"\n, 95, __RECT__)'
							end
						else
							alertError(xdata)
							return "数据生成失败"
						end
					else
						return "find_image：用 [Shift + 鼠标左键] 框选需要查找的图像区域"
					end
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx, poslist, set)
							alert("这个格式专用于 XXTouch 定义的函数 screen.find_image 区域或全屏找图\n使用 [Shift + 鼠标左键] 框选需要查找的图像块\n使用 [Ctrl + 鼠标左键] 框选图像搜索区域", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							if load(s) then
								Java.newThread(function()
									uploadScriptAndRun(s..[[
									nLog("screen.find_image 找图测试结果："..tostring(x)..", "..tostring(y))
									]])
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
		},
	},
}