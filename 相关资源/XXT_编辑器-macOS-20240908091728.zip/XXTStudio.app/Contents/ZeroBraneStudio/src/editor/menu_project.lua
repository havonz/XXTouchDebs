-- Copyright 2011-17 Paul Kulchenko, ZeroBrane LLC
-- authors: Lomtik Software (J. Winwood & John Labenski)
-- Luxinia Dev (Eike Decker & Christoph Kubisch)
---------------------------------------------------------

local ide = ide
local frame = ide.frame
local menuBar = frame.menuBar

ide.xxt = ide.xxt or {}
local xxt = ide.xxt

------------------------
-- Interpreters and Menu

local targetDirMenu = ide:MakeMenu {
  {ID_PROJECTDIRCHOOSE, TR("Choose...")..KSC(ID_PROJECTDIRCHOOSE), TR("Choose a project directory")},
  {ID_PROJECTDIRFROMFILE, TR("Set From Current File")..KSC(ID_PROJECTDIRFROMFILE), TR("Set project directory from current file")},
}
local targetMenu = ide:MakeMenu {}
local debugMenu = ide:MakeMenu {
	{ID_DEVICE_SPAWN,		TR("Run on device") .. KSC(ID_DEVICE_SPAWN),		TR("Run on device")},
	{ID_STARTDEBUG,			TR("Start &Debugging") .. KSC(ID_STARTDEBUG), 	TR("Start or continue debugging") },
	{ID_DEVICE_RECYCLE,		TR("Stop running") .. KSC(ID_DEVICE_RECYCLE),			TR("Stop running")},
	{},
  {ID_DEVICE_CHECKSYNTAX,				TR("Check syntax") .. KSC(ID_DEVICE_CHECKSYNTAX),				TR("Check syntax") },
  {ID_DEVICE_TRYXUI,				TR("Try XUI") .. KSC(ID_DEVICE_TRYXUI),				TR("Try XUI") },
  {ID_DEVICE_ENCRYPET, TR("Pack and encrypt") .. KSC(ID_DEVICE_ENCRYPET), "Pack and encrypt"},
  -- {ID_DEVICE_ENCRYPETUPLOAD, TR("Upload Pack and encrypt") .. KSC(ID_DEVICE_ENCRYPETUPLOAD), "Upload Pack and encrypt"},
	{},
  {ID_PROJECT_ATTRIBUTES, TR("Project property") .. KSC(ID_PROJECT_ATTRIBUTES), "Project property"},
	{},
  { ID_RUN, TR("&Run")..KSC(ID_RUN), TR("Execute the current project/file") },
  { },
  { ID_STOPDEBUG, TR("S&top Process")..KSC(ID_STOPDEBUG), TR("Stop the currently running process") },
  { ID_DETACHDEBUG, TR("Detach &Process")..KSC(ID_DETACHDEBUG), TR("Stop debugging and continue running the process") },
  { ID_STEP, TR("Step &Into")..KSC(ID_STEP), TR("Step into") },
  { ID_STEPOVER, TR("Step &Over")..KSC(ID_STEPOVER), TR("Step over") },
  { ID_STEPOUT, TR("Step O&ut")..KSC(ID_STEPOUT), TR("Step out of the current function") },
  { ID_RUNTO, TR("Run To Cursor")..KSC(ID_RUNTO), TR("Run to cursor") },
  { ID_TRACE, TR("Tr&ace")..KSC(ID_TRACE), TR("Trace execution showing each executed line") },
  { ID_BREAK, TR("&Break")..KSC(ID_BREAK), TR("Break execution at the next executed line of code") },
  { },
  { ID_BREAKPOINT, TR("Breakpoint")..KSC(ID_BREAKPOINT), "", {
    { ID_BREAKPOINTTOGGLE, TR("Toggle Breakpoint")..KSC(ID_BREAKPOINTTOGGLE) },
    { ID_BREAKPOINTNEXT, TR("Go To Next Breakpoint")..KSC(ID_BREAKPOINTNEXT) },
    { ID_BREAKPOINTPREV, TR("Go To Previous Breakpoint")..KSC(ID_BREAKPOINTPREV) },
  } },
  { },
  { ID_CLEAROUTPUTENABLE, TR("C&lear Output Window")..KSC(ID_CLEAROUTPUTENABLE), TR("Clear the output window before compiling or debugging"), wx.wxITEM_CHECK },
  { ID_COMMANDLINEPARAMETERS, TR("Command Line Parameters...")..KSC(ID_COMMANDLINEPARAMETERS), TR("Provide command line parameters") },
  { ID_PROJECTDIR, TR("Project Directory"), TR("Set the project directory to be used"), targetDirMenu },
  { ID_INTERPRETER, TR("Lua &Interpreter"), TR("Set the interpreter to be used"), targetMenu },
  --
  -- { ID_RUN, TR("&Run")..KSC(ID_RUN), TR("Execute the current project/file") },
  -- { ID_RUNNOW, TR("Run As Scratchpad")..KSC(ID_RUNNOW), TR("Execute the current project/file and keep updating the code to see immediate results"), wx.wxITEM_CHECK },
  -- { ID_COMPILE, TR("&Compile")..KSC(ID_COMPILE), TR("Compile the current file") },
  -- { ID_STARTDEBUG, TR("Start &Debugging")..KSC(ID_STARTDEBUG), TR("Start or continue debugging") },
  -- { ID_ATTACHDEBUG, TR("&Start Debugger Server")..KSC(ID_ATTACHDEBUG), TR("Allow external process to start debugging"), wx.wxITEM_CHECK },
  -- { },
  -- { ID_STOPDEBUG, TR("S&top Process")..KSC(ID_STOPDEBUG), TR("Stop the currently running process") },
  -- { ID_DETACHDEBUG, TR("Detach &Process")..KSC(ID_DETACHDEBUG), TR("Stop debugging and continue running the process") },
  -- { ID_STEP, TR("Step &Into")..KSC(ID_STEP), TR("Step into") },
  -- { ID_STEPOVER, TR("Step &Over")..KSC(ID_STEPOVER), TR("Step over") },
  -- { ID_STEPOUT, TR("Step O&ut")..KSC(ID_STEPOUT), TR("Step out of the current function") },
  -- { ID_RUNTO, TR("Run To Cursor")..KSC(ID_RUNTO), TR("Run to cursor") },
  -- { ID_TRACE, TR("Tr&ace")..KSC(ID_TRACE), TR("Trace execution showing each executed line") },
  -- { ID_BREAK, TR("&Break")..KSC(ID_BREAK), TR("Break execution at the next executed line of code") },
  -- { },
  -- { ID_BREAKPOINT, TR("Breakpoint")..KSC(ID_BREAKPOINT), "", {
  --   { ID_BREAKPOINTTOGGLE, TR("Toggle Breakpoint")..KSC(ID_BREAKPOINTTOGGLE) },
  --   { ID_BREAKPOINTNEXT, TR("Go To Next Breakpoint")..KSC(ID_BREAKPOINTNEXT) },
  --   { ID_BREAKPOINTPREV, TR("Go To Previous Breakpoint")..KSC(ID_BREAKPOINTPREV) },
  -- } },
  -- { },
  -- { ID_CLEAROUTPUTENABLE, TR("C&lear Output Window")..KSC(ID_CLEAROUTPUTENABLE), TR("Clear the output window before compiling or debugging"), wx.wxITEM_CHECK },
  -- { ID_COMMANDLINEPARAMETERS, TR("Command Line Parameters...")..KSC(ID_COMMANDLINEPARAMETERS), TR("Provide command line parameters") },
  -- { ID_PROJECTDIR, TR("Project Directory"), TR("Set the project directory to be used"), targetDirMenu },
  -- { ID_INTERPRETER, TR("Lua &Interpreter"), TR("Set the interpreter to be used"), targetMenu },
}
menuBar:Append(debugMenu, TR("&Project"))
menuBar:Check(ID_CLEAROUTPUTENABLE, true)

-- older (<3.x) versions of wxwidgets may not have `GetLabelText`, so provide alternative
do
  local ok, glt = pcall(function() return debugMenu.GetLabelText end)
  if not ok or not glt then
    debugMenu.GetLabelText = function(self, ...) return wx.wxMenuItem.GetLabelText(self.GetLabel(self, ...)) end
  end
end
local debugMenuRunLabel = { [false]=debugMenu:GetLabelText(ID_STARTDEBUG), [true]=TR("Co&ntinue") }
local debugMenuStopLabel = { [false]=debugMenu:GetLabelText(ID_STOPDEBUG), [true]=TR("S&top Debugging") }

local interpreters
local function selectInterpreter(id)
  for id in pairs(interpreters) do
    menuBar:Check(id, false)
    menuBar:Enable(id, true)
  end
  menuBar:Check(id, true)
  menuBar:Enable(id, false)

  local changed = ide.interpreter ~= interpreters[id]
  if changed then
    if ide.interpreter then PackageEventHandle("onInterpreterClose", ide.interpreter) end
    if interpreters[id] then PackageEventHandle("onInterpreterLoad", interpreters[id]) end
  end

  ide.interpreter = interpreters[id]

  ide:GetDebugger():Shutdown()

  if ide.interpreter then
    ide.interpreter:UpdateStatus()
  else
    ide:SetStatus("", 4)
  end
  if changed then ReloadAPIs() end
end

function ProjectSetInterpreter(name)
  local id = IDget("debug.interpreter."..name)
  if id and interpreters[id] then
    selectInterpreter(id)
    return true
  else
    ide:Print(("Can't load interpreter '%s'; using the default interpreter instead."):format(name))
    local id = (
      -- interpreter is set and is (still) on the list of known interpreters
      IDget("debug.interpreter."..(ide.config.interpreter or ide.config.default.interpreter)) or
      -- otherwise use default interpreter
      ID("debug.interpreter."..ide.config.default.interpreter)
    )
    selectInterpreter(id)
  end
end

local function evSelectInterpreter(event)
  selectInterpreter(event:GetId())
end

function ProjectUpdateInterpreters()
  assert(ide.interpreters, "no interpreters defined")

  -- delete all existing items (if any)
  local items = targetMenu:GetMenuItemCount()
  for i = items, 1, -1 do
    targetMenu:Delete(targetMenu:FindItemByPosition(i-1))
  end

  local names = {}
  for file in pairs(ide.interpreters) do table.insert(names, file) end
  table.sort(names)

  interpreters = {}
  for _, file in ipairs(names) do
    local inter = ide.interpreters[file]
    local id = ID("debug.interpreter."..file)
    inter.fname = file
    interpreters[id] = inter
    targetMenu:Append(
      wx.wxMenuItem(targetMenu, id, inter.name, inter.description, wx.wxITEM_CHECK))
    frame:Connect(id, wx.wxEVT_COMMAND_MENU_SELECTED, evSelectInterpreter)
  end

  local id = (
    -- interpreter is set and is (still) on the list of known interpreters
    IDget("debug.interpreter."
      ..(ide.interpreter and ide.interpreters[ide.interpreter.fname] and ide.interpreter.fname
         or ide.config.interpreter or ide.config.default.interpreter)) or
    -- otherwise use default interpreter
    ID("debug.interpreter."..ide.config.default.interpreter)
  )
  selectInterpreter(id)
end

-----------------------------
-- Project directory handling

local function projChoose(event)
  local editor = ide:GetEditor()
  local projectdir = ide:GetProject()
  local filePicker = wx.wxDirDialog(frame, TR("Choose a project directory"),
    projectdir ~= "" and projectdir or wx.wxGetCwd(), wx.wxDIRP_DIR_MUST_EXIST)
  if filePicker:ShowModal(true) == wx.wxID_OK then
    if xxt.xpp.is() then
      
    else
      if projectdir and wx.wxFileExists(projectdir .. "/lua/scripts/main.lua") then
        LoadFile(projectdir .. "/lua/scripts/main.lua", nil, true)
      end
    end
    return ide:SetProject(filePicker:GetPath())
  end
  return false
end

frame:Connect(ID_PROJECTDIRCHOOSE, wx.wxEVT_COMMAND_MENU_SELECTED, projChoose)

local function projFromFile(event)
  local editor = ide:GetEditor()
  if not editor then return end
  local filepath = ide:GetDocument(editor):GetFilePath()
  if not filepath then return end
  local fn = wx.wxFileName(filepath)
  fn:Normalize(wx.wxPATH_NORM_ABSOLUTE + wx.wxPATH_NORM_DOTS)

  if ide.interpreter then
    ide:SetProject(ide.interpreter:fprojdir(fn))
  end
end
frame:Connect(ID_PROJECTDIRFROMFILE, wx.wxEVT_COMMAND_MENU_SELECTED, projFromFile)
frame:Connect(ID_PROJECTDIRFROMFILE, wx.wxEVT_UPDATE_UI,
  function (event)
    local editor = ide:GetEditor()
    event:Enable(editor ~= nil and ide:GetDocument(editor):GetFilePath() ~= nil)
  end)

----------------------
-- Interpreter Running

local function getNameToRun(skipcheck)
  local editor = ide:GetEditor()
  if not editor then return end

  -- test compile it before we run it, if successful then ask to save
  -- only compile if lua api
  if editor.spec.apitype and
    editor.spec.apitype == "lua" and
    (not skipcheck) and
    (not ide.interpreter.skipcompile) and
    (not CompileProgram(editor, { reportstats = false })) then
    return
  end

  local doc = ide:GetDocument(editor)
  local name = ide:GetProjectStartFile() or doc:GetFilePath()
  if not SaveIfModified(editor) then return end
  if ide.config.editor.saveallonrun then SaveAll(true) end

  return wx.wxFileName(name or doc:GetFilePath())
end

local function runInterpreter(wfilename, withdebugger)
  ClearOutput()
  ide:GetOutput():Activate()

  ClearAllCurrentLineMarkers()
  if not wfilename or not ide.interpreter.frun then return end
  local pid = ide.interpreter:frun(wfilename, withdebugger)
  if pid then OutputEnableInput() end
  ide:SetLaunchedProcess(pid)
  return pid
end

function ProjectRun(skipcheck)
  local fname = getNameToRun(skipcheck)
  if not fname then return end
  return runInterpreter(fname)
end

local debuggers = {
  debug = "require('mobdebug').loop('%s',%d)",
  scratchpad = "require('mobdebug').scratchpad('%s',%d)"
}

function ProjectDebug(skipcheck, debtype)
  local debugger = ide:GetDebugger()
  if (debugger:IsConnected()) then
    if (debugger.scratchpad and debugger.scratchpad.paused) then
      debugger.scratchpad.paused = nil
      debugger.scratchpad.updated = true
      ide:GetConsole():SetRemote(nil) -- disable remote while Scratchpad running
    elseif (not debugger:IsRunning()) then
      debugger:Run()
    end
  else
    if not xxt.save_script() then return end
    if not debugger:IsListening() then debugger:Listen() end
    local projectdir = ide:GetProject()
    local script_path = getNameToRun():GetFullPath()

    if ide.osname == "Windows" then
      projectdir = string.lower(projectdir or '')
      script_path = string.lower(script_path or '')
    end

    if not projectdir or projectdir == '' or not script_path:find(projectdir,1,true) then
      ide.xxt.IDE_log(TR('Non project cannot debug'))
      return
    end

    if xxt.xpp.is() then
      xxt.Device_Error(TR('Cannot debug XPP project'))
    else
      if not ide.xxt.xxt.synchronizing() then return end
			if not wx.wxFileExists(ide:GetProject() .. "/lua/scripts/main.lua") then
				xxt.Device_Error(TR('"%s" does not exist, Please ensure that the project directory structure is available.'):format("/lua/scripts/main.lua"))
				return false
			end
      local ip_list = ide.xxt.ip_list()
      if not ip_list or #(ip_list) == 0 or ip_list[1] == "" then ide.xxt.IDE_log(TR("The current device IP address cannot be obtained"));return end
      local _, smsg = ide.xxt.spawn(
        ide.xxt.link_device.ip,
        ide.xxt.nLogGenerator(),
        json.encode(
          {
              ['log_ip'] = xxt.IDE_IP,
              ['log_port'] = xxt.log_listen_port,
              ['debug_port'] = debugger:GetPortNumber(),
              ['server_ip'] = json.encode(ide.xxt.ip_list()),
              ['debug'] = true,
              ['script'] = "main.lua"
          }
        )
      )
      if not _ then
        return
      else
        ide.xxt.IDE_log(smsg)
      end
    end
  end
  return true
end

-----------------------
-- Actions

local BREAKPOINT_MARKER = StylesGetMarker("breakpoint")

frame:Connect(ID_BREAKPOINTTOGGLE, wx.wxEVT_COMMAND_MENU_SELECTED,
  function() ide:GetEditor():BreakpointToggle() end)
frame:Connect(ID_BREAKPOINTTOGGLE, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    local editor = ide:GetEditorWithFocus(ide:GetEditor())
    event:Enable(ide.interpreter and ide.interpreter.hasdebugger and (not debugger.scratchpad)
      and (editor ~= nil) and (not editor:IsLineEmpty()))
  end)

frame:Connect(ID_BREAKPOINTNEXT, wx.wxEVT_COMMAND_MENU_SELECTED,
  function()
    local BPNSC = KSC(ID_BREAKPOINTNEXT):gsub("\t","")
    if not ide:GetEditor():MarkerGotoNext(BREAKPOINT_MARKER) and BPNSC == "F9" then
      ide:Print(("You used '%s' shortcut that has been changed from toggling a breakpoint to navigating to the next breakpoint in the document.")
        :format(BPNSC))
      ide:Print(("To toggle a breakpoint, use '%s' or click in the editor margin.")
        :format(TSC(ID.BREAKPOINTTOGGLE)))
    end
  end)
frame:Connect(ID_BREAKPOINTPREV, wx.wxEVT_COMMAND_MENU_SELECTED,
  function() ide:GetEditor():MarkerGotoPrev(BREAKPOINT_MARKER) end)

frame:Connect(ID_BREAKPOINTNEXT, wx.wxEVT_UPDATE_UI,
  function (event) event:Enable(ide:GetEditor() ~= nil) end)
frame:Connect(ID_BREAKPOINTPREV, wx.wxEVT_UPDATE_UI,
  function (event) event:Enable(ide:GetEditor() ~= nil) end)

frame:Connect(ID_COMPILE, wx.wxEVT_COMMAND_MENU_SELECTED,
  function ()
    ide:GetOutput():Activate()
    CompileProgram(ide:GetEditor(), {
        keepoutput = ide:GetLaunchedProcess() ~= nil or ide:GetDebugger():IsConnected()
    })
  end)
frame:Connect(ID_COMPILE, wx.wxEVT_UPDATE_UI,
  function (event) event:Enable(ide:GetEditor() ~= nil) end)

frame:Connect(ID_RUN, wx.wxEVT_COMMAND_MENU_SELECTED, function () ProjectRun() end)
frame:Connect(ID_RUN, wx.wxEVT_UPDATE_UI,
  function (event)
    event:Enable(ide:GetDebugger():IsConnected() == nil and
                 ide:GetLaunchedProcess() == nil and
                 (ide.interpreter.frun ~= nil) and -- nil == no running from this interpreter
                 ide:GetEditor() ~= nil)
  end)

frame:Connect(ID_RUNNOW, wx.wxEVT_COMMAND_MENU_SELECTED,
  function (event)
    local debugger = ide:GetDebugger()
    if debugger.scratchpad then
      debugger:ScratchpadOff()
    else
      debugger:ScratchpadOn(ide:GetEditor())
    end
  end)
frame:Connect(ID_RUNNOW, wx.wxEVT_UPDATE_UI,
  function (event)
    local editor = ide:GetEditor()
    local debugger = ide:GetDebugger()
    -- allow scratchpad if there is no server or (there is a server and it is
    -- allowed to turn it into a scratchpad) and we are not debugging anything
    event:Enable((ide.interpreter) and (ide.interpreter.hasdebugger) and
                 (ide.interpreter.frun ~= nil) and -- nil == no running from this interpreter
                 (ide.interpreter.scratchextloop ~= nil) and -- nil == no scratchpad support
                 (editor ~= nil) and ((debugger:IsConnected() == nil or debugger.scratchable)
                 and ide:GetLaunchedProcess() == nil or debugger.scratchpad ~= nil))
    local isscratchpad = debugger.scratchpad ~= nil
    menuBar:Check(ID_RUNNOW, isscratchpad)
    local tool = ide:GetToolBar():FindTool(ID_RUNNOW)
    if tool and tool:IsSticky() ~= isscratchpad then
      tool:SetSticky(isscratchpad)
      ide:GetToolBar():Refresh()
    end
  end)

frame:Connect(ID_ATTACHDEBUG, wx.wxEVT_COMMAND_MENU_SELECTED,
  function (event)
    ide:GetDebugger():Listen(event:IsChecked()) -- start/stop listening
    if event:IsChecked() and ide.interpreter.fattachdebug then ide.interpreter:fattachdebug() end
  end)
frame:Connect(ID_ATTACHDEBUG, wx.wxEVT_UPDATE_UI,
  function (event)
    event:Enable(ide.interpreter and ide.interpreter.fattachdebug and true or false)
    ide.frame.menuBar:Check(event:GetId(), ide:GetDebugger():IsListening() and true or false)
  end)

frame:Connect(ID_STARTDEBUG, wx.wxEVT_COMMAND_MENU_SELECTED, function () ProjectDebug() end)
frame:Connect(ID_STARTDEBUG, wx.wxEVT_UPDATE_UI,
  function (event)
    local editor = ide:GetEditor()
    local debugger = ide:GetDebugger()
    local b_enable = (ide.interpreter) and (ide.interpreter.hasdebugger) and
    (ide.interpreter.frun ~= nil) and -- nil == no running from this interpreter
((debugger:IsConnected() == nil and ide:GetLaunchedProcess() == nil and editor ~= nil) or
(debugger:IsConnected() ~= nil and not debugger:IsRunning())) and
(not debugger.scratchpad or debugger.scratchpad.paused) and (ide.xxt.link_device.ip and true)
    event:Enable(b_enable)
    local isconnected = debugger:IsConnected() ~= nil
    local label, other = debugMenuRunLabel[isconnected], debugMenuRunLabel[not isconnected]
    debugMenu:SetLabel(ID_STARTDEBUG, ide.xxt.TR(label, b_enable) .. KSC(ID_STARTDEBUG))
  end)

frame:Connect(ID_STOPDEBUG, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():Stop() end)
frame:Connect(ID_STOPDEBUG, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable(debugger:IsConnected() ~= nil or ide:GetLaunchedProcess() ~= nil)
    local isdebugging = debugger:IsConnected() ~= nil
    local label, other = debugMenuStopLabel[isdebugging], debugMenuStopLabel[not isdebugging]
    if debugMenu:GetLabelText(ID_STOPDEBUG) == wx.wxMenuItem.GetLabelText(other) then
      debugMenu:SetLabel(ID_STOPDEBUG, label..KSC(ID_STOPDEBUG))
    end
  end)

frame:Connect(ID_DETACHDEBUG, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():detach() end)
frame:Connect(ID_DETACHDEBUG, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable(debugger:IsConnected() ~= nil and (not debugger.scratchpad))
  end)

frame:Connect(ID_RUNTO, wx.wxEVT_COMMAND_MENU_SELECTED,
  function ()
    local editor = ide:GetEditor()
    ide:GetDebugger():RunTo(editor, editor:GetCurrentLine()+1)
  end)
frame:Connect(ID_RUNTO, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable((debugger:IsConnected() ~= nil) and (not debugger:IsRunning())
      and (ide:GetEditor() ~= nil) and (not debugger.scratchpad))
  end)

frame:Connect(ID_STEP, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():Step() end)
frame:Connect(ID_STEP, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable((debugger:IsConnected() ~= nil) and (not debugger:IsRunning())
      and (ide:GetEditor() ~= nil) and (not debugger.scratchpad))
  end)

frame:Connect(ID_STEPOVER, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():Over() end)
frame:Connect(ID_STEPOVER, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable((debugger:IsConnected() ~= nil) and (not debugger:IsRunning())
      and (ide:GetEditor() ~= nil) and (not debugger.scratchpad))
  end)

frame:Connect(ID_STEPOUT, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():Out() end)
frame:Connect(ID_STEPOUT, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable((debugger:IsConnected() ~= nil) and (not debugger:IsRunning())
      and (ide:GetEditor() ~= nil) and (not debugger.scratchpad))
  end)

frame:Connect(ID_TRACE, wx.wxEVT_COMMAND_MENU_SELECTED,
  function () ide:GetDebugger():trace() end)
frame:Connect(ID_TRACE, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable((debugger:IsConnected() ~= nil) and (not debugger:IsRunning())
      and (ide:GetEditor() ~= nil) and (not debugger.scratchpad))
  end)

frame:Connect(ID_BREAK, wx.wxEVT_COMMAND_MENU_SELECTED,
  function ()
    local debugger = ide:GetDebugger()
    if debugger.server then
      debugger:Break()
      if debugger.scratchpad then
        debugger.scratchpad.paused = true
        ide:GetConsole():SetRemote(debugger:GetConsole())
      end
    end
  end)
frame:Connect(ID_BREAK, wx.wxEVT_UPDATE_UI,
  function (event)
    local debugger = ide:GetDebugger()
    event:Enable(debugger:IsConnected() ~= nil
      and (debugger:IsRunning()
           or (debugger.scratchpad and not debugger.scratchpad.paused)))
  end)

frame:Connect(ID_COMMANDLINEPARAMETERS, wx.wxEVT_COMMAND_MENU_SELECTED,
  function ()
    local params = ide:GetTextFromUser(TR("Enter command line parameters"),
      TR("Command line parameters"), ide.config.arg.any or "")
    -- params is `nil` when the dialog is canceled
    if params then ide:SetCommandLineParameters(params) end
  end)
frame:Connect(ID_COMMANDLINEPARAMETERS, wx.wxEVT_UPDATE_UI,
  function (event)
    local interpreter = ide:GetInterpreter()
    event:Enable(interpreter and interpreter.takeparameters and true or false)
  end)

frame:Connect(ID_DEVICE_ENCRYPETUPLOAD, wx.wxEVT_COMMAND_MENU_SELECTED, function ()
    ide.xxt.auth.onekey()
  end)
frame:Connect(ID_DEVICE_ENCRYPETUPLOAD, wx.wxEVT_UPDATE_UI, function (event)
    local b_enable = ide.xxt.link_device.ip and true or false
    local have = ide.xxt.auth.have and true or false
    event:Enable(b_enable and have)
    --event:Enable()
  end)
  
frame:Connect(ID_PROJECT_ATTRIBUTES, wx.wxEVT_COMMAND_MENU_SELECTED, function ()
  
    local YES_ID = ID('YES')
    local NO_ID = ID('NO')
  
    local dialog = wx.wxDialog(					-- 窗体
      ide.frame, wx.wxID_ANY, TR('Project property'), wx.wxDefaultPosition, wx.wxDefaultSize)
    local panel = wx.wxPanel(					-- 主面板
      dialog, wx.wxID_ANY)
    local sizer = wx.wxBoxSizer(				-- 主排布
      wx.wxVERTICAL)
    local notebook = wx.wxNotebook(				-- tab控件
      panel, wx.wxID_ANY, wx.wxDefaultPosition, frame:FromDIP(wx.wxSize(500, 300)))
    sizer:Add(notebook, 0, wx.wxGROW + wx.wxALIGN_CENTER + wx.wxALL, 5)
  
    -- property
    local panel0 = wx.wxPanel(notebook, wx.wxID_ANY)
    local sizer0 = wx.wxBoxSizer(wx.wxVERTICAL)
  
    local textctrl_projectname_staticbox = wx.wxStaticBox( panel0, wx.wxID_ANY, TR("Project bid"))
    local textctrl_projectname = wx.wxTextCtrl(panel0, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_PROCESS_ENTER)
    local textctrl_projectname_staticboxsizer = wx.wxStaticBoxSizer(textctrl_projectname_staticbox, wx.wxVERTICAL)
    textctrl_projectname_staticboxsizer:Add(textctrl_projectname, 1, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
  
    local textctrl_projectbid_staticbox = wx.wxStaticBox( panel0, wx.wxID_ANY, TR("Project name"))
    local textctrl_projectbid = wx.wxTextCtrl(panel0, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_PROCESS_ENTER)
    local textctrl_projectbid_staticboxsizer = wx.wxStaticBoxSizer(textctrl_projectbid_staticbox, wx.wxVERTICAL)
    textctrl_projectbid_staticboxsizer:Add(textctrl_projectbid, 1, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
  
    sizer0:Add(textctrl_projectname_staticboxsizer, 0, wx.wxALL + wx.wxGROW, 5)
    sizer0:Add(textctrl_projectbid_staticboxsizer, 0, wx.wxALL + wx.wxGROW, 5)
    panel0:SetSizer(sizer0)
    sizer0:SetSizeHints(panel0)
    notebook:AddPage(panel0, TR("Project property"))
  
  
    -- 公共库部分
    local panel1 = wx.wxPanel(notebook, wx.wxID_ANY)
    local sizer1 = wx.wxBoxSizer(wx.wxVERTICAL)
    local checklistbox_libraries = wx.wxCheckListBox(panel1, wx.wxID_ANY, wx.wxDefaultPosition, wx.wxDefaultSize, {}, wx.wxLB_MULTIPLE)
    local checklistbox_libraries_staticbox = wx.wxStaticBox( panel1, wx.wxID_ANY, TR("Check the libraries used"))
    local checklistbox_libraries_staticboxsizer = wx.wxStaticBoxSizer( checklistbox_libraries_staticbox, wx.wxVERTICAL );
    checklistbox_libraries_staticboxsizer:Add(checklistbox_libraries, 1, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
  
    sizer1:Add(checklistbox_libraries_staticboxsizer, 1, wx.wxALL + wx.wxGROW, 5)
    panel1:SetSizer(sizer1)
    sizer1:SetSizeHints(panel1)
    notebook:AddPage(panel1, TR("libraries"))

    local is_xpp = xxt.xpp.is()

    local textCtrlInformation, textCtrlEntitlements
    if not is_xpp then
      -- 加密脚本权限
      -- 创建一个垂直箱式布局管理器
      local panelInfoEntitle = wx.wxPanel(notebook, wx.wxID_ANY)
      local sizerInfoEntitle = wx.wxBoxSizer(wx.wxVERTICAL)

      -- 创建一个带有“被加密的脚本元信息”标题的静态框和文本框
      local metaBox = wx.wxStaticBox(panelInfoEntitle, wx.wxID_ANY, TR('Information (will be attached to the encrypted script)'))
      local metaBoxSizer = wx.wxStaticBoxSizer(metaBox, wx.wxVERTICAL)

      textCtrlInformation = wxstc.wxStyledTextCtrl(
        panelInfoEntitle,
        wx.wxID_ANY,
        wx.wxDefaultPosition,
        wx.wxDefaultSize,
        wxstc.wxSTC_MARGIN_NUMBER
      )
      metaBoxSizer:Add(textCtrlInformation, 1, wx.wxALL + wx.wxEXPAND, 5)

      -- 创建一个带有“被加密的脚本权限”标题的静态框和文本框
      local permissionBox = wx.wxStaticBox(panelInfoEntitle, wx.wxID_ANY, TR('Entitlements (will be attached to the encrypted script)'))
      local permissionBoxSizer = wx.wxStaticBoxSizer(permissionBox, wx.wxVERTICAL)

      textCtrlEntitlements = wxstc.wxStyledTextCtrl(
        panelInfoEntitle,
        wx.wxID_ANY,
        wx.wxDefaultPosition,
        wx.wxDefaultSize,
        wxstc.wxSTC_MARGIN_NUMBER
      )
      permissionBoxSizer:Add(textCtrlEntitlements, 1, wx.wxALL + wx.wxEXPAND, 5)

      sizerInfoEntitle:Add(metaBoxSizer, 1, wx.wxALL + wx.wxEXPAND, 5)
      sizerInfoEntitle:Add(permissionBoxSizer, 1, wx.wxALL + wx.wxEXPAND, 5)

      local specCpp = require("spec.cpp")
      
      for _, t in ipairs({textCtrlInformation, textCtrlEntitlements}) do
        t:SetFont(wx.wxFont(12, wx.wxFONTFAMILY_MODERN, wx.wxFONTSTYLE_NORMAL,
          wx.wxFONTWEIGHT_NORMAL, false, ide.config.fontname or "",
          ide.config.fontencoding or wx.wxFONTENCODING_DEFAULT)
        )
        t:StyleSetFont(wxstc.wxSTC_STYLE_DEFAULT, t:GetFont())
        t:SetBufferedDraw(not ide.config.hidpi and true or false)
        t:StyleClearAll()
        t:SetMarginWidth(1, 12)
        t:SetMarginType(1, wxstc.wxSTC_MARGIN_SYMBOL)
        t:SetLexer(specCpp.lexer)
        t:SetKeyWords(0, 'true false null')
        t:MarkerDefine(StylesGetMarker("message"))
        t:MarkerDefine(StylesGetMarker("prompt"))
        StylesApplyToEditor(ide.config.stylesoutshell, t, ide.font.oNormal, ide.font.oItalic, specCpp.lexerstyleconvert)
      end
    
      panelInfoEntitle:SetSizer(sizerInfoEntitle)
      sizerInfoEntitle:SetSizeHints(panelInfoEntitle)
      notebook:AddPage(panelInfoEntitle, TR('Info & Entitlements'))
    end


    if false then -- 暂时不需要网络授权
      -- 网络授权部分
      local panel2 = wx.wxPanel(notebook, wx.wxID_ANY)
      local sizer2 = wx.wxBoxSizer(wx.wxVERTICAL)
    
      local textctrl_auth_server_staticbox = wx.wxStaticBox( panel2, wx.wxID_ANY, TR("Server address"))
      local textctrl_auth_server = wx.wxTextCtrl(panel2, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_PROCESS_ENTER)
      local textctrl_auth_server_staticboxsizer = wx.wxStaticBoxSizer(textctrl_auth_server_staticbox, wx.wxVERTICAL)
      textctrl_auth_server_staticboxsizer:Add(textctrl_auth_server, 0, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
    
      --local textctrl_auth_port_staticbox = wx.wxStaticBox( panel2, wx.wxID_ANY, TR("Server port"))
      --local textctrl_auth_port = wx.wxTextCtrl(panel2, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_PROCESS_ENTER)
      --local textctrl_auth_port_staticboxsizer = wx.wxStaticBoxSizer(textctrl_auth_port_staticbox, wx.wxVERTICAL)
      --textctrl_auth_port_staticboxsizer:Add(textctrl_auth_port, 0, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
    
      local textctrl_auth_connectkey_staticbox = wx.wxStaticBox( panel2, wx.wxID_ANY, TR("Connect key"))
      local textctrl_auth_connectkey = wx.wxTextCtrl(panel2, wx.wxID_ANY, "", wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxTE_PROCESS_ENTER)
      local textctrl_auth_connectkey_staticboxsizer = wx.wxStaticBoxSizer(textctrl_auth_connectkey_staticbox, wx.wxVERTICAL)
      textctrl_auth_connectkey_staticboxsizer:Add(textctrl_auth_connectkey, 0, wx.wxALL + wx.wxGROW + wx.wxCENTER, 5)
    
      sizer2:Add(textctrl_auth_server_staticboxsizer, 0, wx.wxALL + wx.wxGROW, 5)
      --sizer2:Add(textctrl_auth_port_staticboxsizer, 0, wx.wxALL + wx.wxGROW, 5)
      sizer2:Add(textctrl_auth_connectkey_staticboxsizer, 0, wx.wxALL + wx.wxGROW, 5)
    
      panel2:SetSizer(sizer2)
      sizer2:SetSizeHints(panel2)
      notebook:AddPage(panel2, TR("Network authorization"))
    end
    
    local p_info = xxt.project.info()

    -- 按钮部分
    local sizer_button = wx.wxBoxSizer(wx.wxHORIZONTAL)
    local buttnctrl_yes = wx.wxButton(panel, YES_ID, TR("Confirm"), wx.wxDefaultPosition, wx.wxDefaultSize)
    local buttnctrl_no = wx.wxButton(panel, NO_ID, TR("Cancel"), wx.wxDefaultPosition, wx.wxDefaultSize)
    sizer_button:Add(wx.wxStaticText(panel, wx.wxID_ANY, ""), 1, wx.wxALL + wx.wxGROW, 5)
    sizer_button:Add(buttnctrl_yes, 0, wx.wxALL + wx.wxGROW, 5)
    sizer_button:Add(buttnctrl_no, 0, wx.wxALL + wx.wxGROW, 5)
    sizer:Add(sizer_button, 0, wx.wxGROW + wx.wxALIGN_CENTER + wx.wxALL, 5)
    dialog:Connect(YES_ID, wx.wxEVT_COMMAND_BUTTON_CLICKED, function(event)

      if not is_xpp then
        local scriptInformation = json.decode(textCtrlInformation:GetText())
        if not scriptInformation then
          xxt.IDE_Error(TR("The script information is invalid"), textCtrlInformation:GetText())
          return
        end
        local scriptEntitlements = json.decode(textCtrlEntitlements:GetText())
        if not scriptEntitlements then
          xxt.IDE_Error(TR("The script entitlements is invalid"), textCtrlEntitlements:GetText())
          return
        end
        p_info.information = scriptInformation
        p_info.entitlements = scriptEntitlements
      end

      p_info.name = textctrl_projectname:GetValue()
      p_info.bid = textctrl_projectbid:GetValue()
      
      p_info.libs = {}
      for i = 1, checklistbox_libraries:GetCount()do
        if checklistbox_libraries:IsChecked(i - 1) then
          table.insert(p_info.libs, checklistbox_libraries:GetString(i - 1))
          --ide:Print(checklistbox_libraries:GetString(i - 1))
        end
      end

      if false then
        p_info.auth = {
          server = textctrl_auth_server:GetValue(),
          --port = textctrl_auth_port:GetValue(),
          connectkey = textctrl_auth_connectkey:GetValue(),
        }
      end
      xxt.conifg.write(nil, p_info)
      dialog:EndModal(wx.wxID_YES)
    end)
    dialog:Connect(NO_ID, wx.wxEVT_COMMAND_BUTTON_CLICKED, function(event)
      dialog:EndModal(wx.wxID_NO)
    end)
  
    panel:SetSizer( sizer )
    sizer:SetSizeHints( dialog )
  
    do
      textctrl_projectname:SetValue(p_info.name)
      textctrl_projectbid:SetValue(p_info.bid)
    end
  
    do
      p_info.libs = type(p_info.libs) == 'table' and p_info.libs or {}
      local getextension = function(filename) return (filename:match(".+%.(%w+)$") or ''):lower() end
      local ishave = function(_item)
        for _, item in ipairs(p_info.libs) do
          if item == _item then
            return true
          end
        end
        return false
      end
      local function find_libs(_p, _r)
        local module_dir = wx.wxDir(_p)
        local _, f_name = module_dir:GetFirst()
        while _ do
          local f_path = _p .. f_name
          local r_f_path = _r .. f_name
          if f_name:sub(1,1) ~= '.' and getextension(f_name) == 'xxt' or getextension(f_name) == 'lua' then
            if wx.wxFileExists(f_path) then
              checklistbox_libraries:InsertItems({r_f_path}, 0)
            end
          elseif f_name:sub(1,1) ~= '.' and wx.wxDirExists(f_path) then
            find_libs(f_path .. '/', r_f_path .. '/')
          end
          _, f_name = module_dir:GetNext()
        end
      end
  
      local libs_path = wx.wxStandardPaths.Get():GetDocumentsDir() .. "/XXTStudio/module/"
      find_libs(libs_path, '')
  
      for i = 1, checklistbox_libraries:GetCount()do
        if ishave(checklistbox_libraries:GetString(i - 1)) then
          checklistbox_libraries:Check(i - 1)
        end
      end
    end
    if false then -- 暂时不需要网络授权
      if type(p_info.auth) == 'table' and p_info.auth then
        if type(p_info.auth.server) == 'string' then
          textctrl_auth_server:SetValue(p_info.auth.server)
        end
        --if type(p_info.auth.port) == 'string' then
        --	textctrl_auth_port:SetValue(p_info.auth.port)
        --end
        if type(p_info.auth.connectkey) == 'string' then
          textctrl_auth_connectkey:SetValue(p_info.auth.connectkey)
        end
      end
    end

    if not is_xpp then
      textCtrlInformation:ClearAll()
      textCtrlEntitlements:ClearAll()
  
      if type(p_info.information) == "table" then
        textCtrlInformation:AddText(json.encode(p_info.information, {indent = true}))
      else
        textCtrlInformation:AddText("[]")
      end
  
      if type(p_info.entitlements) == "table" then
        textCtrlEntitlements:AddText(json.encode(p_info.entitlements, {indent = true}))
      else
        textCtrlEntitlements:AddText(json.encode({
          ["allow-external-require"] = false,
        }, {indent = true}))
      end
    end
  
    if dialog:ShowModal() ~= wx.wxID_YES then
      return
    end

    -- p_info.libs = {}
    -- for i = 1, checklistbox_libraries:GetCount()do
    --   if checklistbox_libraries:IsChecked(i - 1) then
    --     table.insert(p_info.libs, checklistbox_libraries:GetString(i - 1))
    --     --ide:Print(checklistbox_libraries:GetString(i - 1))
    --   end
    -- end

    -- p_info.information = json.decode(textCtrlInformation:GetText()) or p_info.information
    -- p_info.entitlements = json.decode(textCtrlEntitlements:GetText()) or p_info.entitlements
    -- p_info.name = textctrl_projectname:GetValue()
    -- p_info.bid = textctrl_projectbid:GetValue()

    -- if false then
    --   p_info.auth = {
    --     server = textctrl_auth_server:GetValue(),
    --     --port = textctrl_auth_port:GetValue(),
    --     connectkey = textctrl_auth_connectkey:GetValue(),
    --   }
    -- end
    -- xxt.conifg.write(nil, p_info)

    -- xxt.IDE_log(json.encode(p_info, {indent = true}))
  
  end)
  frame:Connect(ID_PROJECT_ATTRIBUTES, wx.wxEVT_UPDATE_UI, function (event)
      
  end)

-- save and restore command line parameters
ide:AddPackage("core.project", {
    AddCmdLine = function(self, params)
      local settings = self:GetSettings()
      local arglist = settings.arglist or {}
      PrependStringToArray(arglist, params, ide.config.commandlinehistorylength)
      settings.arglist = arglist
      self:SetSettings(settings)
    end,
    GetCmdLines = function(self) return self:GetSettings().arglist or {} end,

    onProjectLoad = function(self, project)
      local settings = self:GetSettings()
      if type(settings.arg) == "table" then
        ide:SetConfig("arg.any", settings.arg[project], project)
      end
      local interpreter = ide:GetInterpreter()
      if interpreter then interpreter:UpdateStatus() end
    end,
    onProjectClose = function(self, project)
      local settings = self:GetSettings()
      if type(settings.arg) ~= "table" then settings.arg = {} end
      if settings.arg[project] ~= ide.config.arg.any then
        settings.arg[project] = ide.config.arg.any
        self:SetSettings(settings)
      end
    end,
})
