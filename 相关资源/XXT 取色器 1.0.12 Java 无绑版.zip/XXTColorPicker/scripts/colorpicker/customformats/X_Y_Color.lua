require("scripts.colorpicker.customformats")

return {
	name = "X, Y, Color",
	description = "X, Y, Color",
	formats = {
		settingsRule = {
			title = "自定义格式 [X, Y, Color] 的参数设置",
			args = {
				{"格式2相似度",
					85, -- 默认值为数字，且第三个参数用一个表描述范围则用一个 Slider（滑动条） 描述
					{
						1,   -- Slider 的最小值
						100, -- Slider 的最大值
					},
				},
				{"空格补齐", true}, -- 默认值是布尔类型则控件用 CheckBox（勾选框） 描述
				{"换行格式", true},
				{"色偏模式", false},
				{"默认色偏", 101010}, -- 默认值是字符串或者数字且没有第三个参数则用 TextFeild（文本框） 描述
				{"选项示例1",
					"选项1", -- 默认值是字符串且第三个参数用一个表描述则是一个 ComboBox（下拉选项框）
					{ -- 选项列表
						"选项1",
						"选项2",
						"选项3",
					},
					false, -- ComboBox 是否可以编辑输入文本
				},
				{"选项示例2",
					"选项1", -- 默认值是字符串且第三个参数用一个表描述则是一个 ComboBox（下拉选项框）
					{ -- 选项列表
						"选项1",
						"选项2",
						"选项3",
					},
					true, -- ComboBox 是否可以编辑输入文本
				},
				{"测试示例1", true},
				{"测试示例2", "测试示例2"},
				{"测试示例3", 3, {1, 10}},
			},
		},
		singlePosFormatRule = (function(p, a, s, x, c, set)
			local fmt = string.format("%4d, %4d, 0x%06x ", p.x, p.y, p.c)
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			return fmt
		end),
		multiPosFormatRule = (function(p, a, s, x, c, set)
			local fmt = string.format(" %4d, %4d, 0x%06x \n", p.x, p.y, p.c)
			if not toboolean(set["换行格式"]) then
				fmt = fmt:gsub("\n", ""):gsub("\t", "")
			end
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			return fmt
		end),
		mouseTrackInfoBottomRule = (function(p, a, s, x, c, set)
			return string.format("XY: (%4d, %4d)      Color: 0x%06x      RGB: (%3d, %3d, %3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end),
		mouseTrackInfoZoomRule = (function(p, a, s, x, c, set)
			return string.format("(%4d,%4d):0x%06x:(%3d,%3d,%3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end),
		makeScriptRules = {
			{
				maker = function(poslist, set)
					local fmt = "\t{ %4d, %4d, 0x%06x},\n"
					if #poslist < 1 then
						return "生成该自定义代码需要至少取 1 个点颜色"
					end
					local ret = "{\n"
					for _,currentPos in ipairs(poslist) do
						ret = ret..string.format("\t{ %4d, %4d, 0x%06x},\n", currentPos.x, currentPos.y, currentPos.c)
					end
					ret = ret.."}"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("\n", ""):gsub("\t", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("这个格式需要你自备一个解析函数", "说明")
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "生成该自定义代码需要至少取 1 个点颜色"
					end
					local ret = "if (screen.is_colors({\n"
					for i,currentPos in ipairs(poslist) do
						ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
					end
					ret = ret.."}, "..set["格式2相似度"]..")) then"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("\n", ""):gsub("\t", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx)
							alert("这个格式专用于 XXTouch 定义的函数 screen.is_colors 多点匹配色", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							local code = isColorCodeDefine..s..[[
									nLog("匹配")
								else
									nLog("不匹配")
								end
							]]
							if load(code) then
								Java.newThread(function()
									uploadScriptAndRun(code)
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "生成该自定义代码需要至少取 1 个点颜色"
					end
					local ret = "x, y = screen.find_color({\n"
					for i,currentPos in ipairs(poslist) do
						if toboolean(set["色偏模式"]) then
							ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", currentPos.x, currentPos.y, currentPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
						else
							ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
						end
					end
					if toboolean(set["色偏模式"]) then
						ret = ret.."}"
					else
						ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
					end
					if (0 ~= poslist.a.x) and
							(0 ~= poslist.a.y) and
							(0 ~= poslist.s.x) and
							(0 ~= poslist.s.y) then
						ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
					end
					ret = ret..")"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("[\n\t]", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = function(s, idx, poslist, set)
					if load(s) then
						return {
							{
								name = "查看说明",
								action = function(s, idx)
									alert("这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色", "说明")
								end,
							},
							{
								name = "于设备测试",
								action = function(s, idx)
									if load(s) then
										Java.newThread(function()
											uploadScriptAndRun(s..[[
										nLog("多点找色结果："..tostring(x)..", "..tostring(y))
									]])
										end):start()
									else
										alert("请按要求生成自定义代码。", "无法测试")
									end
								end,
							},
						}
					end
				end,
			},
			{
				maker = function(poslist, set)
					if #poslist < 1 then
						return "生成该自定义代码需要至少取 1 个点颜色"
					end
					local ret = "x, y = screen.find_color({\n"
					local firstPos
					for i,currentPos in ipairs(poslist) do
						if (1 == i) then
							firstPos = currentPos
							if toboolean(set["色偏模式"]) then
								ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", 0, 0, firstPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
							else
								ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", 0, 0, firstPos.c)
							end
						else
							ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x - firstPos.x, currentPos.y - firstPos.y, currentPos.c)
						end
					end
					if toboolean(set["色偏模式"]) then
						ret = ret.."}"
					else
						ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
					end
					if (0 ~= poslist.a.x) and
							(0 ~= poslist.a.y) and
							(0 ~= poslist.s.x) and
							(0 ~= poslist.s.y) then
						ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
					end
					ret = ret..")"
					if not toboolean(set["换行格式"]) then
						ret = ret:gsub("[\n\t]", "")
					end
					if not toboolean(set["空格补齐"]) then
						ret = ret:gsub(" ", "")
					end
					return ret
				end,
				menu = function(s, idx, poslist, set)
					if load(s) then
						return {
							{
								name = "查看说明",
								action = function(s, idx)
									alert("这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色", "说明")
								end,
							},
							{
								name = "于设备测试",
								action = function(s, idx)
									if load(s) then
										Java.newThread(function()
											uploadScriptAndRun(s..[[
										nLog("多点找色结果："..tostring(x)..", "..tostring(y))
									]])
										end):start()
									else
										alert("请按要求生成自定义代码。", "无法测试")
									end
								end,
							},
						}
					end
				end,
			},
			{
				maker = function(poslist, set)
					local a = poslist.a
					local s = poslist.s
					local x = poslist.x
					local c = poslist.c
					local ex, ey = getImageSize()
					if a.x~=s.x and a.y~=s.y and a.x > 0 and a.y > 0 and s.x < ex and s.y < ey then
	--					local function s2h(s,cp)return(string.gsub(s,"(.)",function(c)return string.format("\\x%02x%s",string.byte(c),cp or"")end))end
	--					return 'local x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..s2h(getRectPNGData(a.x, a.y, s.x, s.y))..'"\n, 95, __这里替换成区域__)'
						local noerr, xdata = pcall(getRectPNGDataHex, a.x, a.y, s.x, s.y)
						if noerr then
							if (not (x.x==x.y and c.x==c.y)) and -- 区域不为 0, 0, 0, 0
								x.x~=c.x and x.y~=c.y and x.x > 0 and x.y > 0 and --[[c.x < ex and c.y < ey and--]]
								x.x<=a.x and x.y<=a.y and c.x>=s.x and c.y>=s.y -- XC选区范围大于AS选区
							then
								return 'local x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..xdata..'"\n, 95, '..string.format("%d, %d, %d, %d)", x.x, x.y, c.x, c.y)
							else
								return 'local x, y = screen.find_image( -- 原图位置 '..string.format("左上: %d, %d | 右下: %d, %d", a.x, a.y, s.x, s.y)..'\n"'..xdata..'"\n, 95, __RECT__)'
							end
						else
							alertError(xdata)
							return "数据生成失败"
						end
					else
						return "生成这个自定义代码需要选定的区域在当前图像内"
					end
				end,
				menu = {
					{
						name = "查看说明",
						action = function(s, idx, poslist, set)
							alert("这个格式专用于 XXTouch 定义的函数 screen.find_image 区域或全屏找图", "说明")
						end,
					},
					{
						name = "于设备测试",
						action = function(s, idx)
							if load(s) then
								Java.newThread(function()
									uploadScriptAndRun(s..[[
									nLog("image.find_image 找图结果："..tostring(x)..", "..tostring(y))
									]])
								end):start()
							else
								alert("请按要求生成自定义代码。", "无法测试")
							end
						end,
					},
				},
			},
		},
	},
}