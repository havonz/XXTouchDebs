-- Please do not modify this file.
-- This file will restore to its initial state when the software starts.

-- 请不要修改本文件
-- 本文件会在软件启动时恢复初始状态

return {
    ["Language"] = "Language",
    ["XY: (%4d, %4d)\r\nColor: 0x%06x\r\nRGB: (%3d, %3d, %3d)\r\n"] = "XY: (%4d, %4d)\r\nColor: 0x%06x\r\nRGB: (%3d, %3d, %3d)\r\n",
    ["Content '%s' has been copied to the clipboard"] = "Content '%s' has been copied to the clipboard",
    ["Color '0x%06x' has been copied to the clipboard"] = "Color '0x%06x' has been copied to the clipboard",
    ["XY '%d, %d' have been copied to the clipboard"] = "XY '%d, %d' have been copied to the clipboard",
    ["The contents in the clipboard has been loaded into the PosColor list"] = "The contents in the clipboard has been loaded into the PosColor list",
    ["X, Y, Color"] = "X, Y, Color",
    ["Parameter settings for the custom format [X, Y, Color]"] = "Parameter settings for the custom format [X, Y, Color]",
    ["Default Color Similarity"] = "Color Similarity",
    ["Aligning Using Spaces"] = "Using Spaces",
    ["Using Line Break"] = "Using Line Break",
    ["Color Offset Mode"] = "Using Color Offset",
    ["Default Color Offset"] = "Color Offset",
    ["XXTDo Action"] = "XXTDo Action",
    ["Tap the first point in the PosColor list"] = "Tap the first point in the PosColor list",
    ["Tap the last point in the PosColor list"] = "Tap the last point in the PosColor list",
    ["Tap point A"] = "Tap point A",
    ["Tap point S"] = "Tap point S",
    ["Tap point X"] = "Tap point X",
    ["Tap point C"] = "Tap point C",
    ["Execute Custom Code"] = "Execute Custom Code",
    ["XXTDo Action Custom Code"] = "XXTDo Action Custom Code",
    ["Orientation During Testing"] = "Orientation During Testing",
    ["Home On Bottom"] = "Home On Bottom",
    ["Home On Right"] = "Home On Right",
    ["Home On Left"] = "Home On Left",
    ["Home On Top"] = "Home On Top",
    ["Default OCR Language"] = "Default OCR Language",
    ["Need to take at least 1 PosColor"] = "Need to take at least 1 PosColor",
    ["Format Readme"] = "Format Readme",
    ["Test On Device"] = "Test On Device",
    ["Please generate custom code as required"] = "Please generate custom code as required",
    ["Cannot Test"] = "Cannot Test",
    ["Please use [Shift + left mouse button] to select an rect on the image"] = "Please use [Shift + left mouse button] to select an rect on the image",
    ["Please use [Ctrl + left mouse button] to select an rect on the image"] = "Please use [Ctrl + left mouse button] to select an rect on the image",
    ["Code generation failed"] = "Code generation failed",
    ["A general point color table, used in various script frameworks, which requires developers to parse and use it themselves"] = "A general point color table, used in various script frameworks, which requires developers to parse and use it themselves",
    ["Generate an interface trigger for use by the XXTDo\nUse with the XXTDo"] = "Generate an interface trigger for use by the XXTDo\nUse with the XXTDo",
    ["This format is dedicated to the function screen.is_colors defined by XXTouch"] = "This format is dedicated to the function screen.is_colors defined by XXTouch",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nAll coordinates captured are absolute coordinates"] = "This format is specially used for the function screen.find_color defined by XXTouch\nAll coordinates captured are absolute coordinates",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nOnly relative coordinates are captured"] = "This format is specially used for the function screen.find_color defined by XXTouch\nOnly relative coordinates are captured",
    ["This format is specially used for the screen.ocr_text screen text recognition function defined by XXTouch\nUse [Shift + left mouse button] to select the text area that needs to be recognized"] = "This format is specially used for the screen.ocr_text screen text recognition function defined by XXTouch\nUse [Shift + left mouse button] to select the text area that needs to be recognized",
    ["This format is specially used for the function screen.find_image defined by XXTouch to find images in area or full screen\nUse [Shift + left mouse button] to select the image block to be found\nUse [Ctrl + left mouse button] to select the image search area"] = "This format is specially used for the function screen.find_image defined by XXTouch to find images in area or full screen\nUse [Shift + left mouse button] to select the image block to be found\nUse [Ctrl + left mouse button] to select the image search area",
    ["Testing code changes requires XXTDo.lua"] = "Testing code changes requires XXTDo.lua",
    ["Automatically importing XXTDo.lua to device path '%s'"] = "Automatically importing XXTDo.lua to device path '%s'",
    ["Automatic import of XXTDo.lua failed\nPlease manually import XXTDo.lua to the device path '%s'"] = "Automatic import of XXTDo.lua failed\nPlease manually import XXTDo.lua to the device path '%s'",
    ["The timeout is set to 5 seconds. If no match is found within the timeout, the matching loop will be exited"] = "The timeout is set to 5 seconds. If no match is found within the timeout, the matching loop will be exited",
    ["Preview Image"] = "Preview Image",
    ["Copy `image.load_data([data])`"] = "Copy `image.load_data([data])`",
    ["Use [Shift + left mouse button] to select the area"] = "Use [Shift + left mouse button] to select the area",
    ["Use [Ctrl + left mouse button] to select the area"] = "Use [Ctrl + left mouse button] to select the area",
    ["Double-click to crop the small image"] = "Double-click to crop the small image",
    ["Open small images folder"] = "Open small images folder",
    ["Path for saving small images"] = "Path for saving small images",
    ["After saving the small image, gen code to the clipboard"] =
    "After saving the small image, gen code to the clipboard",
    ["Please enter the name of the saved small image"] = "Please enter the name of the saved small image",
    ["The small image has been saved as: "] = "The small image has been saved as: ",
    ["Unable to save small image"] = "Unable to save small image",
    ["This format is used to extract small images and save them as files. \nThe option `Path for saving small images` can be configured to specify the path for saving the small images. \nThe option `After saving the small image, generate code to the clipboard` can be configured to specify the format for generating the code after saving the small image."] =
    "This format is used to extract small images and save them as files. \nThe option `Path for saving small images` can be configured to specify the path for saving the small images. \nThe option `After saving the small image, generate code to the clipboard` can be configured to specify the format for generating the code after saving the small image.",
    ["#NAME# is used to represent the name of the small image"] = "#NAME# is used to represent the name of the small image",
    ["#FILENAME# is used to represent the file name of the small image"] = "#FILENAME# is used to represent the file name of the small image",
    ["#IMAGEDATAHEX# is used to represent the hex-data of the small image"] = "#IMAGEDATAHEX# is used to represent the hex-data of the small image",
    ["#BINOPT# is used to represent the binaryzation option of the small image"] = "#BINOPT# is used to represent the binaryzation option of the small image",
    ["Double-click to perform binaryzation"] = "Double-click to perform binaryzation",
    ["Binaryization Preview Arguments"] = "Binaryization Preview Arguments",
    ["White Background"] = "White Background",
    ["Color Similarity Algorithm"] = "Color Similarity Algorithm",
    ["XXT Default"] = "XXT Default",
    ["Manhattan Algorithm"] = "Manhattan Algorithm",
    ["Euclidean Algorithm"] = "Euclidean Algorithm",
    ["Parameter settings for the custom format [XXT-Bin-Dict]"] = "Parameter settings for the custom format [XXT-Bin-Dict]",
    ["XXT Binaryzation Dictionary"] = "XXT Binaryzation Dictionary",
    ["Color offset mode binaryization arguments"] = "Color offset mode binaryization arguments",
    ["Color similarity binaryzation arguments"] = "Color similarity binaryzation arguments",
    ["Used to set the arguments for performing binaryzation"] = "Used to set the arguments for performing binaryzation",
    ["Binaryization Error"] = "Binaryization Error",
    ["Bad format, Please set valid Binaryzation Preview Arguments"] = "Bad format, Please set valid Binaryzation Preview Arguments",
    ["Small Images Scale"] = "Small Images Scale",
    ["Performing binaryzation..."] = "Performing binaryzation...",
    ["Binaryzation completed"] = "Binaryzation completed",
    ["Supports the following styles: blablabla..."] = [[
Supports the following styles:

DM-ColorOffset-style
Example: fab1c2-102030, bcbcbc-202020

Table-ColorOffset-style
Example: {{0xfab1c2, 0x102030}, {0xbcbcbc, 0x202020}}

Color-Similarity-style
Example: {csim_mode = true, {0xfab1c2, 90}, {0xbcbcbc, 90}}

Threshold value (range 0 ~ 255)
Example: 150

Auto-threshold
Example: auto

]],

}