-- 放到XXT取色器的 scripts/colorpicker/customformats/ 目录下（打开XXT取色器，右键点 “格式（Format）” 标签，选择 “从资源管理器查看” 可定位到自定义格式脚本目录）
-- 重启XXT取色器后该脚本会自动加载
-- 然后重新打开XXT取色器，在右侧 “格式（Format）” 下拉选项中选择 “取色器自定义格式打样”

require("scripts.colorpicker.customformats")

local File = Java.class("java.io.File")
local JOptionPane = Java.class("javax.swing.JOptionPane")

function toboolean(set)
	if type(set)=="boolean" then
		return set
	end
	if math.abs(tonumber(set) or 0)>0 then
		return true
	end
	return false
end

local rules_buffer = {}

return {
	name = "取色器自定义格式打样", -- 这个名称会显示在取色器的格式选择菜单中
	formats = {

		-- 配置界面规则，就是点 “配置” 按钮时弹出的界面
		settingsRule = {
			title = "配置界面的标题",
			args = {
				{"紧凑模式", false}, -- 默认值是布尔类型则控件用 CheckBox（勾选框） 描述

				{"颜色相似度",
				 85; -- 默认值为数字，且第三个参数用一个表描述范围则用一个 Slider（滑动条） 描述
				 {
					 10,  -- Slider 的最小值
					 100, -- Slider 的最大值
				 };
				};

				{"小图片保存路径", Java.new(File, ""):getAbsolutePath()};

				-- #NAME#     会替换成名称
				-- #FILENAME# 会替换成带扩展名的名称
				{"保存后拷贝代码到剪贴板", '#NAME# = image.load_file(XXT_RES_PATH.."/#FILENAME#");'};

				{"随机点色最大数量",
				 20; -- 默认值为数字，且第三个参数用一个表描述范围则用一个 Slider（滑动条） 描述
				 {
					 1,  -- Slider 的最小值
					 1000, -- Slider 的最大值
				 };
				};
			},
		};

		-- 单点颜色格式化规则
		singlePosFormatRule = (function(p, a, s, x, c, set)
			return string.format("%4d, %4d, 0x%06x ", p.x, p.y, p.c)
		end);
		-- 多点颜色格式化规则，多点取色文本框中的内容
		multiPosFormatRule = (function(p, a, s, x, c, set)
			return string.format(" %4d, %4d, 0x%06x \n", p.x, p.y, p.c)
		end);
		-- 图片底部栏鼠标跟踪信息格式化规则
		mouseTrackInfoBottomRule = (function(p, a, s, x, c, set)
			return string.format("坐标: (%4d, %4d)      颜色: 0x%06x      日狗逼: (%3d, %3d, %3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end);
		-- 放大镜下方鼠标跟踪信息格式化规则
		mouseTrackInfoZoomRule = (function(p, a, s, x, c, set)
			return string.format("(%4d,%4d):0x%06x:(%3d,%3d,%3d)", p.x, p.y, p.c, p.r, p.g, p.b)
		end);

		-- 生成脚本代码规则
		makeScriptRules = {
			{ -- 生成代码 第一行规则
			  -- 例子：`变量名 = {"变量名", {{96,294,0x7d0808},{98,308,0xa93b61},{106,312,0x69559a},},85,66,258,164,342}`
				-- 点 “生成代码” 按钮时运行，返回值为列表框对应框的代码内容，默认双击复制框中文本内容
				maker = function(poslist, set)
					if #poslist < 1 then
						return "点色区域变量：需要至少取一点颜色"
					end
					local buf = {'#NAME# = {"#NAME#", {'}
					local no_space = toboolean(set['紧凑模式'])
					for _,currentPos in ipairs(poslist) do
						local line = string.format(" { %4d, %4d, 0x%06x},", currentPos.x, currentPos.y, currentPos.c)
						if no_space then
							line = line:gsub(" ", "")
						end
						buf[#buf + 1] = line
					end
					buf[#buf + 1] = "},"
					if not no_space then
						buf[#buf + 1] = " "
					end
					buf[#buf + 1] = tostring(tonumber(set["颜色相似度"]) or 85)
					if not (0 == poslist.x.x and 0 == poslist.x.y and 0 == poslist.c.x and 0 == poslist.c.y) then
                        local line = string.format(", %4d, %4d, %4d, %4d", poslist.x.x, poslist.x.y, poslist.c.x, poslist.c.y)
						if no_space then
							line = line:gsub(" ", "")
						end
						buf[#buf + 1] = line
                    end
					buf[#buf + 1] = "}"
					rules_buffer['第一行规则缓存'] = buf
					return table.concat(buf)
				end;

				-- 双击动作
				doubleClick = function (s, idx, poslist, set)
					if #poslist < 1 then
						alert("点色区域变量：需要至少取一点颜色")
						return
					end
					local buf = rules_buffer['第一行规则缓存']
					if type(buf) ~= "table" then
						alert("点色区域变量：需要先点生成代码")
						return
					end
					local name = JOptionPane:showInputDialog(nil, "设置变量名称", "名称", JOptionPane.PLAIN_MESSAGE, nil, nil, "")
					if type(name) ~= 'string' or name == "" then
						return
					end
					buf[1] = string.format('%s = {%q, {', name, name)
					local ret = table.concat(buf)
					copyText(ret)
					return ret
				end;

				-- 列表中该框右键菜单选项
				menu = {
					{
						name = "格式说明",
						action = function(s, idx, poslist, set)
							alert([[变量名 = {"变量名", {{96,294,0x7d0808},{98,308,0xa93b61},{106,312,0x69559a},},85,66,258,164,342}]], "说明 - 点色区域变量")
						end,
					},
				},
			};

			{ -- 生成代码 第二行规则
				maker = function(poslist, set)
					if #poslist < 1 then
						return "触动多点找色：需要至少取一点颜色"
					end
					local no_space = toboolean(set['紧凑模式'])
					local ret = make_findMultiColorInRegionFuzzy(poslist) -- 生成触动的 findMultiColorInRegionFuzzy 函数代码
					if no_space then
						ret = ret:gsub(" ", "")
					end
					return ret
				end;
				menu = {
					{
						name = "格式说明",
						action = function(s, idx, poslist, set)
							alert([[x,y=findMultiColorInRegionFuzzy(0x7d0808,"2|14|0xa93b61,10|18|0x69559a",85,66,258,164,342)]], "说明 - 触动精灵多点找色")
						end,
					},
				};
			};

			{ -- 生成代码 第三行规则
				maker = function(poslist, set) -- 点击生成代码后运行，返回值为生成的代码
					return '右键点击选择动作'
				end;

				-- doubleClick 是在鼠标双击列表中该项会触发的动作，它的参数为 (当前项的文本内容, 当前项在列表中的序号, 点色列表及区域, 配置选项)
                doubleClick = function (s, idx, poslist, set)
					alertError("不对，你应该右键点击选择动作")
				end;

				-- 右键菜单选项
				menu = {
					{
						name = "将 A S 框选区域截图保存成文件",
						action = function(s, idx, poslist, set)
							local a = poslist.a
							local s = poslist.s
							local ex, ey = getImageSize()
							if a.x~=s.x and a.y~=s.y and a.x >= 0 and a.y >= 0 and s.x < ex and s.y < ey then
								local ok, data = pcall(getRectPNGData, a.x, a.y, s.x, s.y)
								if ok then
									local name = JOptionPane:showInputDialog("请输入保存的图像名称")
									if not name then
										return
									end
									if name == '' then
										name = os.date('IMG_%Y%m%d%H%M%S')
									end
									local fn = name..".png"
									local s = set['保存后拷贝代码到剪贴板']
									if s:find("#FILENAME#", 1, true) or s:find("#NAME#", 1, true) then
										copyText(s:gsub("#FILENAME#", fn):gsub("#NAME#", name))
									end
									local dir = set['小图片保存路径']
									if dir:sub(-1) ~= "/" and dir:sub(-1) ~= "\\" then
										dir = dir .. "/"
									end
									local path = dir..fn
									local f, err = io.open(path, "wb")
									if not f then
										alert(err, "无法保存截图")
										return
									end
									f:write(data)
									f:close()
									printLog("区域截图已保存到："..path)
								else
									alert(data, "无法保存截图")
								end
							else
								alert("你需要框选一个有效的截图区域", "无法保存截图")
							end
						end,
					},
					{
						name = "复制 A S 框选区域到剪贴板",
						action = function(s, idx, poslist, set)
							local a = poslist.a
							local s = poslist.s
							copyText(string.format("%d, %d, %d, %d", a.x, a.y, s.x, s.y))
						end,
					},
					{
						name = "复制 X C 框选区域到剪贴板",
						action = function(s, idx, poslist, set)
							local x = poslist.x
							local c = poslist.c
							copyText(string.format("%d, %d, %d, %d", x.x, x.y, c.x, c.y))
						end,
					},
				},
			};

			{ -- 生成代码 第四行规则
				-- 点击生成代码后运行，返回值为生成的代码
				maker = function(poslist, set)
					local w, h = getImageSize()
					if w <= 0 or h <= 0 and poslist.a.x < poslist.s.x and poslist.a.y < poslist.s.y then
						return "随机取点色：需要打开一张图片并使用 Shift + 鼠标左键 框选一个有效区域"
					end
					local tl = poslist.a
					local br = poslist.s
					local x_range = br.x - tl.x
					local y_range = br.y - tl.y
					local buf = {"{\n"}
					local max_points = math.floor(tonumber(set['随机点色最大数量']) or 20)
					for i=1, max_points do
						local x = math.random(tl.x, tl.x + x_range)
						local y = math.random(tl.y, tl.y + y_range)
						local c = getColor(x, y)
						local fmt = "\t{ %4d, %4d, 0x%06x},\n"
						buf[#buf+1] = string.format(fmt, x, y, c)
					end
					buf[#buf+1] = "}"
					local ret = table.concat(buf)
					if toboolean(set['紧凑模式']) then
						return string.gsub(ret, "[ \t\n]", "")
					end
					return ret
				end;
				-- 列表中该框右键菜单选项
				menu = {
					{
						name = "格式说明",
						action = function(s, idx, poslist, set)
							local max_points = math.floor(tonumber(set['随机点色最大数量']) or 20)
							alert("用 Shift + 鼠标左键框选区域，然后点生成代码可随机取 "..max_points.." 个点的颜色", "说明 - 区域随机取点色")
						end,
					},
				},
			};
		},
	},
}