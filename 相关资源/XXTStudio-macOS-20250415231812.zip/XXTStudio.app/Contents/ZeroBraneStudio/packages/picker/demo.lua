--[[
    放置于：\packages\picker
]]
return {
    name = "例子",
    description = "完全是为了展示效果",
    settings = {
        {"滑块", 1, {1, 10}},
        -- 滑块 {key, default, {min, max}}

        {"复选框", true},
        -- {key, default}

        {"下拉选项", "item1", {"item1", "item2", "item3"}, false},
        -- {key, default, items, true}

        {"可编辑下拉", "item2", {"item1", "item2", "item3"}, true},
        -- {key, default, items, true}

        {"文本框", "Are You OK?"},
        -- {key, default}

    },
    maker = function(poslist, set, img_hex, find_rect)
        --[[
            poslist:                table        点色列表
                {
                    x:              number        X轴坐标
                    y:              number        Y轴坐标
                    r:              number        红色[0-255]
                    g:              number        绿色[0-255]
                    b:              number        蓝色[0-255]
                    c:              string        颜色码十六进制(0xffffff)
                }
            
            set:                    table        配置列表
                {
                    ["滑块"]:        number        对应 滑块 中选择值或默认值
                    ["复选框"]:      boolean       对应 复选框 中选择值或默认值
                    ["下拉选项"]:    string        对应 下拉选项 中选择值或默认值
                    ["可编辑下拉"]:  string        对应 可编辑下拉 中选择值或默认值
                    ["文本框"]:      string        对应 文本框 中选择值或默认值
                }
            
            img_hex:                string        文本形式的图片十六进制数据(\xff\xff)
            
            find_rect:    table
                {
                    [1]                number        找图或找色框选范围(左上角X轴坐标)
                    [2]                number        找图或找色框选范围(左上角Y轴坐标)
                    [3]                number        找图或找色框选范围(右下角X轴坐标)
                    [4]                number        找图或找色框选范围(右下角Y轴坐标)
                }
        ]]
        return table.concat(
            {
                "点：" .. json.encode(poslist),
                "配置：" .. json.encode(set),
                "图像：" .. img_hex,
                "范围：" .. json.encode(find_rect),
            },
            "\r\n"
        )
    end,
}