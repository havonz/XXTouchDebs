local BUILD_DATE = '20250415231812'
local BUILD_DATE = BUILD_DATE or "0"
ide.xxt = ide.xxt or {}
ide.xxt.VERSION = '2.0'
ide.VERSION = [[2.01]]
ide.VERSION = table.concat({ide.VERSION, "XXTStudio " .. ide.xxt.VERSION.."-"..BUILD_DATE}, ';  ')