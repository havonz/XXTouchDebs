-- Please do not modify this file.
-- This file will restore to its initial state when the software starts.

-- 请不要修改本文件
-- 本文件会在软件启动时恢复初始状态

return {
    ["Language"] = "语言",
    ["XY: (%4d, %4d)\r\nColor: 0x%06x\r\nRGB: (%3d, %3d, %3d)\r\n"] = "坐标: (%4d, %4d)\r\n颜色值: 0x%06x\r\nRGB值: (%3d, %3d, %3d)\r\n",
    ["Content '%s' has been copied to the clipboard"] = "内容 '%s' 已复制到剪贴板",
    ["Color '0x%06x' has been copied to the clipboard"] = "颜色 '0x%06x' 已复制到剪贴板",
    ["XY '%d, %d' have been copied to the clipboard"] = "坐标 '%d, %d' 已复制到剪贴板",
    ["The contents in the clipboard has been loaded into the PosColor list"] = "已将剪贴板中的点色信息载入点色列表",
    ["X, Y, Color"] = "X, Y, Color",
    ["Parameter settings for the custom format [X, Y, Color]"] = "自定义格式 [X, Y, Color] 的参数设置",
    ["Default Color Similarity"] = "默认相似度",
    ["Aligning Using Spaces"] = "空格补齐",
    ["Using Line Break"] = "换行格式",
    ["Color Offset Mode"] = "色偏模式",
    ["Default Color Offset"] = "默认色偏",
    ["XXTDo Action"] = "XXTDo 动作",
    ["Tap the first point in the PosColor list"] = "点取色列表第一个点",
    ["Tap the last point in the PosColor list"] = "点取色列表最后一个点",
    ["Tap point A"] = "点击 A 点",
    ["Tap point S"] = "点击 S 点",
    ["Tap point X"] = "点击 X 点",
    ["Tap point C"] = "点击 C 点",
    ["Execute Custom Code"] = "自定义动作代码",
    ["XXTDo Action Custom Code"] = "XXTDo 动作自定义代码",
    ["Orientation During Testing"] = "代码测试时旋转方向",
    ["Home On Bottom"] = "Home在下",
    ["Home On Right"] = "Home在右",
    ["Home On Left"] = "Home在左",
    ["Home On Top"] = "Home在上",
    ["Default OCR Language"] = "默认 OCR 语言",
    ["Need to take at least 1 PosColor"] = "需要至少取 1 个点颜色",
    ["Format Readme"] = "格式说明",
    ["Please generate custom code as required"] = "请按要求生成自定义代码",
    ["Test On Device"] = "在设备上测试",
    ["Cannot Test"] = "无法测试",
    ["Please use [Shift + left mouse button] to select an rect on the image"] = "请使用 [Shift + 鼠标左键] 在图片上框选区域",
    ["Please use [Ctrl + left mouse button] to select an rect on the image"] = "请使用 [Ctrl + 鼠标左键] 在图片上框选区域",
    ["Code generation failed"] = "代码生成失败",
    ["A general point color table, used in various script frameworks, which requires developers to parse and use it themselves"] = "一种通用点色框架表，用于各种脚本框架，需要开发者自行解析使用",
    ["Generate an interface trigger for use by the XXTDo\nUse with the XXTDo"] = "抓取一个用于 XXTDo 框架的界面触发器\n配合 XXTDo 框架使用",
    ["This format is dedicated to the function screen.is_colors defined by XXTouch"] = "这个格式专用于 XXTouch 定义的函数 screen.is_colors 多点匹配色",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nAll coordinates captured are absolute coordinates"] = "这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色\n抓取的所有坐标都是绝对坐标，但不影响找色，所有坐标都以第一点为相对位置",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nOnly relative coordinates are captured"] = "这个格式专用于 XXTouch 定义的函数 screen.find_color 多点找色\n仅抓取相对坐标，不保留绝对坐标信息",
    ["This format is specially used for the screen.ocr_text screen text recognition function defined by XXTouch\nUse [Shift + left mouse button] to select the text area that needs to be recognized"] = "这个格式专用于 XXTouch 定义的函数 screen.ocr_text 屏幕文字识别函数\n使用 [Shift + 鼠标左键] 框选需要识别的文字区域",
    ["This format is specially used for the function screen.find_image defined by XXTouch to find images in area or full screen\nUse [Shift + left mouse button] to select the image block to be found\nUse [Ctrl + left mouse button] to select the image search area"] = "这个格式专用于 XXTouch 定义的函数 screen.find_image 区域或全屏找图\n使用 [Shift + 鼠标左键] 框选需要查找的图像块\n使用 [Ctrl + 鼠标左键] 框选图像搜索区域",
    ["Testing code changes requires XXTDo.lua"] = "测试该代码需要 XXTDo 框架",
    ["Automatically importing XXTDo.lua to device path '%s'"] = "正在自动导入 XXTDo.lua 到设备路径 '%s'",
    ["Automatic import of XXTDo.lua failed\nPlease manually import XXTDo.lua to the device path '%s'"] = "自动导入 XXTDo.lua 失败\n请手动导入 XXTDo.lua 到设备路径 '%s'",
    ["The timeout is set to 5 seconds. If no match is found within the timeout, the matching loop will be exited"] = "超时时间设为 5 秒，超时未匹配则跳出",
    ["Preview Image"] = "预览图片",
    ["Copy `image.load_data([data])`"] = "复制 `image.load_data([data])`",
    ["Use [Shift + left mouse button] to select the area"] = "使用 [Shift + 鼠标左键] 框选区域",
    ["Use [Ctrl + left mouse button] to select the area"] = "使用 [Ctrl + 鼠标左键] 框选区域",
    ["Double-click to crop the small image"] = "双击此处抓取小图片",
    ["Open small images folder"] = "打开小图片文件夹",
    ["Path for saving small images"] = "保存小图片的路径",
    ["Please enter the name of the saved small image"] = "请输入保存的小图片名称",
    ["After saving the small image, gen code to the clipboard"] = "保存小图片后，生成代码到剪贴板",
    ["The small image has been saved as: "] = "小图片已保存为: ",
    ["Unable to save small image"] = "无法保存小图片",
    ["This format is used to extract small images and save them as files. \nThe option `Path for saving small images` can be configured to specify the path for saving the small images. \nThe option `After saving the small image, generate code to the clipboard` can be configured to specify the format for generating the code after saving the small image."] = "这个格式用于提取小图像并将其保存为文件。\n选项\"保存小图片的路径\"可用于设置小图像的保存路径。\n选项\"保存小图片后，生成代码到剪贴板\"可用于设置保存小图像后生成代码的格式。",
    ["#NAME# is used to represent the name of the small image"] = "#NAME# 用来表示小图片的名称",
    ["#FILENAME# is used to represent the file name of the small image"] = "#FILENAME# 用来表示小图片的文件名",
    ["#IMAGEDATAHEX# is used to represent the hex-data of the small image"] = "#IMAGEDATAHEX# 用来表示小图片的十六进制数据",
    ["#BINOPT# is used to represent the binaryzation option of the small image"] = "#BINOPT# 用来表示小图片的二值化选项",
    ["Set the arguments and then"] = "设置参数并",
    ["Double-click to perform binaryzation"] = "双击进行二值化",
    ["Binaryization Preview Arguments"] = "二值化预览参数",
    ["White Background"] = "白色背景",
    ["Color Similarity Algorithm"] = "颜色相似度算法",
    ["XXT Default"] = "XXT 默认",
    ["Manhattan Algorithm"] = "曼哈顿算法",
    ["Euclidean Algorithm"] = "欧式距离算法",
    ["Parameter settings for the custom format [XXT-Bin-Dict]"] = "自定义格式 [XXT-Bin-Dict] 的参数设置",
    ["XXT Binaryzation Dictionary"] = "XXT 二值化字典",
    ["Color offset mode binaryization arguments"] = "色偏模式二值化参数",
    ["Color similarity binaryization arguments"] = "颜色相似度二值化参数",
    ["Used to set the arguments for performing binaryzation"] = "用来设置进行二值化的参数",
    ["Binaryization Error"] = "二值化错误",
    ["Bad format, Please set valid Binaryzation Preview Arguments"] = "格式错误，请设置有效的二值化预览参数",
    ["Small Images Scale"] = "小图片缩放",
    ["Performing binaryzation..."] = "正在进行二值化...",
    ["Binaryization completed"] = "二值化完成",
    ["Supports the following styles: blablabla..."] = [[
支持如下几种样式：

大漠色偏样式
例如：fab1c2-102030,bcbcbc-202020

表色偏样式
例如：{{0xfab1c2, 0x102030}, {0xbcbcbc, 0x202020}}

相似度样式
例如：{csim_mode = true, {0xfab1c2, 90}, {0xbcbcbc, 90}}

阈值，阈值范围 0 ~ 255
例如：150

自动阈值
例如：auto

]],

}
