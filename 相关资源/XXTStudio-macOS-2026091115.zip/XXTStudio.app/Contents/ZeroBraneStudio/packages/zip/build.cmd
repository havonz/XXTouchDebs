@echo off
setlocal
set "SRC=%~1"
set "WORK=%~2"
set "KIT=%~3"
cd /d "%WORK%"
if errorlevel 1 exit /b 1
set "PATH=%KIT%\bin;%SystemRoot%\system32;%SystemRoot%"
set "FLAGS=-std=gnu11 -O2 -DNDEBUG -DWINVER=0x0501 -D_WIN32_WINNT=0x0501 -D__MSVCRT_VERSION__=0x0700"
set "SOURCE_DATE_EPOCH=1520647200"

cmake -S "%SRC%/zlib-1.2.11" -B "%WORK%/zlib-build" -G Ninja -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DCMAKE_BUILD_TYPE=Release "-DCMAKE_C_FLAGS=%FLAGS%"
if errorlevel 1 exit /b 1
cmake --build "%WORK%/zlib-build" --target zlibstatic -j 4
if errorlevel 1 exit /b 1
if not exist stage\include mkdir stage\include
if not exist stage\lib mkdir stage\lib
copy /y "%SRC%\zlib-1.2.11\zlib.h" stage\include\ >nul
if errorlevel 1 exit /b 1
copy /y zlib-build\zconf.h stage\include\ >nul
if errorlevel 1 exit /b 1
copy /y zlib-build\libzlibstatic.a stage\lib\libz.a >nul
if errorlevel 1 exit /b 1

cmake -S "%SRC%/libzip-1.4.0" -B "%WORK%/libzip-build" -G Ninja -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DCMAKE_BUILD_TYPE=Release "-DCMAKE_C_FLAGS=%FLAGS%" -DBUILD_SHARED_LIBS=OFF -DCMAKE_DISABLE_FIND_PACKAGE_BZip2=TRUE "-DZLIB_INCLUDE_DIR=%WORK%/stage/include" "-DZLIB_LIBRARY=%WORK%/stage/lib/libz.a"
if errorlevel 1 exit /b 1
cmake --build "%WORK%/libzip-build" --target zip -j 4
if errorlevel 1 exit /b 1
copy /y "%SRC%\libzip-1.4.0\lib\zip.h" stage\include\ >nul
if errorlevel 1 exit /b 1
copy /y libzip-build\zipconf.h stage\include\ >nul
if errorlevel 1 exit /b 1
copy /y libzip-build\lib\libzip.a stage\lib\ >nul
if errorlevel 1 exit /b 1

dlltool -d lua51.def -l lua51.a
if errorlevel 1 exit /b 1
gcc %FLAGS% -shared -static -static-libgcc -Istage/include "-I%SRC%/lua-zip-master" "%SRC%/lua-zip-master/lua_zip.c" "%SRC%/lua-zip-master/lua_zip.def" lua51.a stage/lib/libzip.a stage/lib/libz.a -ladvapi32 -Wl,--major-os-version,5,--minor-os-version,1,--major-subsystem-version,5,--minor-subsystem-version,1,--no-insert-timestamp -o zip.dll
if errorlevel 1 exit /b 1
strip --strip-unneeded zip.dll
exit /b %errorlevel%
