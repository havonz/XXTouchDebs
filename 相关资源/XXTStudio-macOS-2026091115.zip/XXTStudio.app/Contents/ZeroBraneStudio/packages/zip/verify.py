#!/usr/bin/env python3
"""Reject ZIP builds that require an extra runtime or post-XP imports."""

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from pe import read_pe


# 白名单覆盖 ZIP 与随包 Lua 的 XP 导入；新函数必须单独核查，不能从候选 DLL 自动放行。
# 依据及验证边界见 README.md；延迟导入同样由 read_pe 检查。
XP_IMPORTS = {
    "advapi32.dll": set("""
        CryptAcquireContextA CryptGenRandom CryptReleaseContext GetSecurityInfo
    """.split()),
    "kernel32.dll": set("""
        CloseHandle CreateFileW DeleteCriticalSection DeleteFileW EnterCriticalSection
        ExitProcess FormatMessageA FreeLibrary GetCPInfo GetFileSizeEx GetFileTime GetFileType
        GetLastError GetModuleFileNameA GetModuleHandleA GetModuleHandleExA GetProcAddress
        GetTickCount InitializeCriticalSection LeaveCriticalSection LoadLibraryA LocalFree
        MoveFileExW MultiByteToWideChar ReadFile SetFilePointerEx SetLastError
        SetUnhandledExceptionFilter Sleep TlsGetValue VirtualAlloc VirtualFree VirtualProtect
        VirtualQuery WideCharToMultiByte WriteFile
    """.split()),
    "msvcrt.dll": set("""
        __dllonexit __getmainargs __lc_codepage __p___mb_cur_max __p__environ __p__fmode
        __p__iob __set_app_type _amsg_exit _cexit _errno _filelengthi64 _fmode _initterm
        _iob _isatty _lock _onexit _pclose _popen _setmode _snprintf _snwprintf _strdup
        _stricmp _unlock _wcsdup abort atexit calloc clearerr clock cosh difftime exit
        fclose fflush fgetpos fgets floor fopen fprintf fputc fputs fread free fscanf
        fsetpos fwrite getc getenv gmtime ldexp localtime localeconv malloc memchr memcmp
        memcpy memmove memset mktime putchar realloc remove rename setlocale setvbuf
        signal sinh sprintf strchr strcmp strcpy strerror strftime strlen strncmp strncpy
        strpbrk strrchr strstr strtoul system tanh time tmpfile tmpnam ungetc vfprintf wcslen
    """.split()),
}


def verify_dll(path, lua_path):
    module = read_pe(path)
    lua = read_pe(lua_path)
    if not module["is_dll"] or "luaopen_zip" not in module["exports"]:
        raise ValueError("Expected a DLL exporting luaopen_zip")
    if module["exports"]["luaopen_zip"]["forwarder"]:
        raise ValueError("luaopen_zip must be implemented by zip.dll")
    if "lua51.dll" not in module["imports"]:
        raise ValueError("zip.dll must use the shipped lua51.dll")
    if not lua["is_dll"]:
        raise ValueError("Expected lua51.dll")
    # 同时验证传递依赖；随包 Lua 升级后不能仅凭 ZIP 的直接导入表宣称免运行库。
    images = [(path, module), (lua_path, lua)]
    lua_exe = Path(lua_path).with_name("lua.exe")
    if lua_exe.is_file():
        images.append((lua_exe, read_pe(lua_exe)))
    for filename, image in images:
        for version in ["os_version", "subsystem_version"]:
            if image[version] > (5, 1):
                raise ValueError(f"{filename}: {version} exceeds Windows XP: {image[version]}")
        for dll, symbols in image["imports"].items():
            allowed = lua["exports"] if dll == "lua51.dll" else XP_IMPORTS.get(dll)
            if allowed is None:
                raise ValueError(f"{filename}: non-system dependency: {dll}")
            for symbol in symbols:
                if not isinstance(symbol, str) or symbol not in allowed:
                    raise ValueError(f"{filename}: unreviewed XP import: {dll}!{symbol}")
                if dll == "lua51.dll" and lua["exports"][symbol]["forwarder"]:
                    raise ValueError(f"{filename}: forwarded Lua import: {symbol}")
    return {
        "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        "size": Path(path).stat().st_size,
        "machine": "PE32 / Intel 80386",
        "os_version": module["os_version"],
        "subsystem_version": module["subsystem_version"],
        "exports": sorted(module["exports"]),
        "imports": module["imports"],
        "lua51_sha256": hashlib.sha256(Path(lua_path).read_bytes()).hexdigest(),
    }


def main():
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dll", nargs="?", type=Path, default=root / "bin" / "clibs" / "zip.dll")
    parser.add_argument("--lua-dll", type=Path, default=root / "bin" / "lua51.dll")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        report = verify_dll(args.dll, args.lua_dll)
    except (ValueError, OSError, struct.error, UnicodeError, IndexError) as error:
        print(f"ZIP dependency check failed: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print("ZIP dependency check passed: x86, XP import baseline, "
              "lua51.dll and Windows system libraries only")
    return 0


if __name__ == "__main__":
    sys.exit(main())
