"""Read PE32 imports and exports without a platform-specific binary tool."""

import struct
from pathlib import Path


def read_pe(path):
    data = Path(path).read_bytes()
    if data[:2] != b"MZ":
        raise ValueError(f"{path}: missing DOS header")
    pe = struct.unpack_from("<I", data, 60)[0]
    if data[pe:pe + 4] != b"PE\0\0":
        raise ValueError(f"{path}: missing PE header")
    machine, section_count = struct.unpack_from("<HH", data, pe + 4)
    optional_size, characteristics = struct.unpack_from("<HH", data, pe + 20)
    optional = pe + 24
    magic = struct.unpack_from("<H", data, optional)[0]
    if machine != 0x14c or magic != 0x10b:
        raise ValueError(f"{path}: expected PE32 / Intel 80386")
    image_base = struct.unpack_from("<I", data, optional + 28)[0]
    os_version = struct.unpack_from("<HH", data, optional + 40)
    subsystem_version = struct.unpack_from("<HH", data, optional + 48)
    sections = []
    for i in range(section_count):
        section = optional + optional_size + i * 40
        virtual_size, rva, size, offset = struct.unpack_from("<IIII", data, section + 8)
        sections.append((rva, max(virtual_size, size), offset, size))

    def file_offset(rva):
        for start, length, offset, size in sections:
            if start <= rva < start + length:
                if rva - start >= size:
                    break
                return offset + rva - start
        raise ValueError(f"{path}: invalid RVA {rva:#x}")

    def string_at(rva):
        offset = file_offset(rva)
        return data[offset:data.index(b"\0", offset)].decode("ascii")

    directory_count = struct.unpack_from("<I", data, optional + 92)[0]
    directories = [struct.unpack_from("<II", data, optional + 96 + i * 8)
                   for i in range(min(directory_count, 16))]
    imports = {}
    for index, descriptor_size in [(1, 20), (13, 32)]:
        if index >= len(directories) or not directories[index][0]:
            continue
        descriptor = file_offset(directories[index][0])
        while True:
            fields = struct.unpack_from("<" + "I" * (descriptor_size // 4), data, descriptor)
            if not any(fields):
                break
            if index == 1:
                name, thunk = fields[3], fields[0] or fields[4]
            else:
                name, thunk = fields[1], fields[4] or fields[3]
                if not fields[0] & 1:
                    name, thunk = name - image_base, thunk - image_base
            dll = string_at(name).lower()
            symbols = imports.setdefault(dll, [])
            cursor = file_offset(thunk)
            while True:
                value = struct.unpack_from("<I", data, cursor)[0]
                if not value:
                    break
                if value & 0x80000000:
                    symbols.append(value & 0xffff)
                else:
                    if index == 13 and not fields[0] & 1:
                        value -= image_base
                    symbols.append(string_at(value + 2))
                cursor += 4
            descriptor += descriptor_size

    exports = {}
    if directories and directories[0][0]:
        export_rva, export_size = directories[0]
        fields = struct.unpack_from("<IIHHIIIIIII", data, file_offset(export_rva))
        base, count, names, functions_rva, names_rva, ordinals_rva = fields[5:]
        functions = struct.unpack_from(f"<{count}I", data, file_offset(functions_rva))
        if names:
            name_table = struct.unpack_from(f"<{names}I", data, file_offset(names_rva))
            ordinals = struct.unpack_from(f"<{names}H", data, file_offset(ordinals_rva))
            for name_rva, ordinal in zip(name_table, ordinals):
                address = functions[ordinal]
                exports[string_at(name_rva)] = {
                    "ordinal": base + ordinal,
                    "forwarder": string_at(address)
                    if export_rva <= address < export_rva + export_size else None,
                }
    return {
        "machine": machine,
        "is_dll": bool(characteristics & 0x2000),
        "os_version": os_version,
        "subsystem_version": subsystem_version,
        "imports": imports,
        "exports": exports,
    }
