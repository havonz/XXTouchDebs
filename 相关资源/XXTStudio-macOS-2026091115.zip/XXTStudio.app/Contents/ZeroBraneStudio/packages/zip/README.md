# Windows ZIP 模块

`bin/clibs/zip.dll` 是 XXTStudio 的 Lua 5.1 ZIP 模块，用于生成 XPA。
本次构建将 libzip、zlib 和编译器支持代码静态链接，保留项目自带的
`lua51.dll`，使用 Windows 自带的 `msvcrt.dll`。用户无需安装 VC++ 2013
运行库，也不需要额外安装 UCRT、GCC 或线程运行库。

最低编译目标为 **Windows XP SP3 x86、支持 SSE2 的处理器**。
此目标仅针对 ZIP 模块。现有 `wx.dll` 导入 `GetTickCount64`，整个 IDE
的 XP 兼容性不由本次修改保证；没有原生 Windows XP 实测结果。

## 来源和版本

| 组件 | 来源 / 版本 | 许可 |
| --- | --- | --- |
| Lua ZIP 绑定 | 仓库 `lua-zip-project-win.zip` 内的 `lua-zip-master`；上游 [brimworks/lua-zip](https://github.com/brimworks/lua-zip) | MIT |
| libzip | 同一源码包，1.4.0 | BSD 3-Clause，内含 Gladman AES 许可 |
| zlib | 同一源码包，1.2.11 | zlib |
| Lua 头文件 | 同一源码包，5.1.5；不编译或嵌入 Lua | MIT |
| 编译器 | [w64devkit 2.9.1 x86](https://github.com/skeeto/w64devkit/releases/tag/v2.9.1)，GCC 16.2.0、CMake 4.4.2 | 各组件许可；GCC 运行库例外 |

原始源码压缩包不变，没有修改第三方 C 源码。许可证文本保存在 `licenses/`，
随 `packages/` 一起进入发行包；不将编译工具链放入发行包。

固定输入的 SHA-256：

```text
lua-zip-project-win.zip
7d5098f8a0829ca06504e1b2a3edd905fa71ba9039eca1099fe438709f35078c

w64devkit-x86-2.9.1.7z.exe
91017cbbb8766cb9b3094a9a461213ed809e9f06aa678257bf9bec32fed6b157
```

## 在 macOS 重编译

需要 Python 3、7-Zip（`7zz` 或 `7z`）和 CrossOver。
在仓库根目录执行：

```sh
python3 -B packages/zip/build.py
```

脚本下载并校验指定工具链，在新的临时目录解压源码、建立独立的
Windows 7 64 位 CrossOver 容器，使用其中的 x86 编译器构建。
构建宿主系统和 DLL 的最低目标系统不同。

成功后输出候选 `zip.dll`、`compile.log`、`test.log`、`report.json` 的位置，
并保留测试 XPA。临时容器进程会退出；目录保留以便复查。
编译和回归全部通过后，可以使用 `--install` 自动替换仓库中的 DLL：

```sh
python3 -B packages/zip/build.py --install
```

可用 `--toolchain-archive /path/to/w64devkit-x86-2.9.1.7z.exe` 复用下载，
`--work-dir /path/to/new-empty-directory` 指定空工作目录，
`--crossover /path/to/CrossOver` 指定包含 `bin/wine` 的 CrossOver 运行时目录。
已有目录中的内容不会被删除。操作系统权限限制本地 Wine 通信时，需允许该构建进程运行。

实际 Windows 编译命令在 `build.cmd`，依次接收解压后的 `lua-zip-project`
路径、工作目录、解压后的 `w64devkit` 路径。工作目录中的 `lua51.def`
由 `build.py` 根据当前 `bin/lua51.dll` 的导出名称生成，避免复用旧导入库的序号绑定。

编译约束：

- 使用 `-std=gnu11 -O2 -DNDEBUG`、`WINVER=0x0501`、`_WIN32_WINNT=0x0501`、
  `__MSVCRT_VERSION__=0x0700`，PE OS 和子系统版本为 5.1。
- CMake 设置 `CMAKE_POLICY_VERSION_MINIMUM=3.5` 以读取旧项目，
  只构建 `zlibstatic` 和静态 `zip`，禁用 BZip2 探测。
- `zipconf.h` 提供 `ZIP_STATIC`；最终 DLL 使用 `-shared -static -static-libgcc`，
  通过导入库连接现有 Lua，保留 `luaopen_zip` 和原有 83 个导出名称及序号。
- 固定 `SOURCE_DATE_EPOCH` 并关闭 PE 链接时间戳。不得使用本机默认 UCRT
  工具链的预编译静态库混合链接。

## 验证和打包

```sh
python3 -B packages/zip/verify.py
python3 -B tests/zip_dependencies.py
```

依赖检查读取普通和延迟导入表，检查 x86、DLL 入口、PE 版本，以及 ZIP、
随包 Lua DLL 和 Lua 可执行文件的系统依赖。DLL 名称和函数名称均使用封闭白名单；
新增导入必须核查旧系统可用性。白名单依据固定的 XP 目标工具链及 Windows API
文档，包括 [GetFileSizeEx](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfilesizeex)、
[GetModuleHandleExA](https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulehandleexa)、
[GetSecurityInfo](https://learn.microsoft.com/en-us/windows/win32/api/aclapi/nf-aclapi-getsecurityinfo)。
这是构建约束检查，不能替代原生 XP 测试。

`build.py` 用随包 `bin/lua.exe` 执行 `tests/zip.lua`，覆盖创建归档、EXCL 冲突、
文件缺失、目录、中文及空格路径、含所有字节值的二进制文件、空文件，以及
20 次打开、读取、关闭和垃圾回收。Python `zipfile` 独立核对 XPA 的目录、内容和 CRC。
测试时禁用 CrossOver 中的 VC++ 2013 和 UCRT 实现，以免它们掩盖额外依赖。

需要在原生 Windows 复测时，将脚本生成的 `runtime/fixtures` 中的输入文件复制到
新的空测试目录（不复制已生成的 XPA），然后运行：

```bat
bin\lua.exe tests\zip.lua bin/clibs C:/zip-test/fixtures
```

最终仍需在未安装 VC++ 运行库的原生 XP SP3 和 Windows 10/11 上验收。

`build.sh` 在任何清理操作之前执行依赖检查；检查失败立即退出。
Windows 包不再携带 `vcredist_x86.exe`，仓库根目录的历史安装程序保留。
完整 `build.sh` 仍具有清空 `build/` 和覆盖 macOS 已安装应用的原有行为，
单独重编译 ZIP 不会运行它。

## 2026-09-11 构建记录

- 两个全新源码目录构建得到完全相同的 DLL，242,418 字节。
- SHA-256：`f75e91fb2aa448db17e59c75999149008c3dadc26aba41e62544aabeb46fec33`。
- 导入 DLL：`lua51.dll`、`ADVAPI32.dll`、`KERNEL32.dll`、`msvcrt.dll`。
- 原有 83 个导出名称及序号保持一致；具体导入和输入校验值见 `build-report.json`。
- CrossOver ZIP 回归 143 项通过，独立 XPA 校验通过；依赖检查回归 10 项通过。
- 在隔离副本执行 `build.sh` 的 Windows 打包段，包内不含运行库安装程序；
  解压后的 Lua 和 ZIP 模块在 CrossOver XP 版本模式下再次通过 143 项回归和 XPA 校验。
- 现有设备兼容性及设备路径回归共 175 项通过。
- 原生 XP、Windows 10/11：未执行，不将 CrossOver 结果记作原生验收。
