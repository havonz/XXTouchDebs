#!/usr/bin/env python3
"""Build and exercise the Windows ZIP module in an isolated CrossOver bottle."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
from pe import read_pe


TOOLCHAIN_URL = (
    "https://github.com/skeeto/w64devkit/releases/download/v2.9.1/"
    "w64devkit-x86-2.9.1.7z.exe"
)
TOOLCHAIN_SHA256 = "91017cbbb8766cb9b3094a9a461213ed809e9f06aa678257bf9bec32fed6b157"
SOURCE_SHA256 = "7d5098f8a0829ca06504e1b2a3edd905fa71ba9039eca1099fe438709f35078c"
ROOT = Path(__file__).resolve().parents[2]


def verify_hash(path, expected):
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f"SHA-256 mismatch for {path}: {actual}")


def windows_path(path):
    # CrossOver 的 Z: 映射到主机根目录；仅转换路径，不通过 shell 拼接用户参数。
    return "Z:" + str(path.resolve()).replace("/", "\\")


def prepare_fixtures(directory):
    directory.mkdir(parents=True)
    (directory / "中文 空格").mkdir()
    (directory / "中文 空格" / "资源.bin").write_bytes(bytes(range(256)) * 257)
    (directory / "empty.txt").write_bytes(b"")


def verify_xpa(path):
    prefix = "Payload/com.example.zip.xpp/"
    expected = {
        "Payload/": b"",
        prefix: b"",
        prefix + "中文 空格/": b"",
        prefix + "empty directory/": b"",
        prefix + "Info.lua": b"return {bid = 'com.example.zip'}\n",
        prefix + "中文 空格/资源.bin": bytes(range(256)) * 257,
        prefix + "empty.txt": b"",
    }
    with zipfile.ZipFile(path) as archive:
        if len(archive.infolist()) != len(expected) or set(archive.namelist()) != set(expected):
            raise ValueError("Unexpected XPA directory structure")
        if archive.testzip() is not None:
            raise ValueError("XPA CRC check failed")
        for name, contents in expected.items():
            if archive.read(name) != contents:
                raise ValueError(f"XPA contents differ: {name}")
    print("Independent XPA directory, content and CRC checks passed", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--toolchain-archive", type=Path, help="use a previously downloaded archive")
    parser.add_argument("--work-dir", type=Path, help="new, empty work directory (default: temporary)")
    parser.add_argument("--crossover", type=Path, default=Path(
        "/Applications/CrossOver.app/Contents/SharedSupport/CrossOver"))
    parser.add_argument("--install", action="store_true", help="replace the repository DLL after tests")
    args = parser.parse_args()
    extractor = shutil.which("7zz") or shutil.which("7z")
    if not extractor:
        parser.error("7zz or 7z is required to extract w64devkit")
    wine = args.crossover / "bin" / "wine"
    cxbottle = args.crossover / "bin" / "cxbottle"
    if not wine.is_file() or not cxbottle.is_file():
        parser.error("CrossOver was not found; set --crossover")
    source_archive = ROOT / "lua-zip-project-win.zip"
    verify_hash(source_archive, SOURCE_SHA256)
    if args.work_dir:
        work = args.work_dir.resolve()
        work.mkdir(parents=True, exist_ok=True)
        if any(work.iterdir()):
            parser.error("--work-dir must be empty; existing build artifacts are never removed")
    else:
        work = Path(tempfile.mkdtemp(prefix="xxtstudio-zip-")).resolve()
    print(f"Work directory: {work}", flush=True)
    toolchain_archive = args.toolchain_archive
    if toolchain_archive is None:
        toolchain_archive = work / "w64devkit-x86-2.9.1.7z.exe"
        print(f"Downloading {TOOLCHAIN_URL}", flush=True)
        with urllib.request.urlopen(TOOLCHAIN_URL, timeout=60) as response:
            with toolchain_archive.open("wb") as output:
                shutil.copyfileobj(response, output)
    verify_hash(toolchain_archive, TOOLCHAIN_SHA256)
    with (work / "extract.log").open("w") as log:
        subprocess.run([extractor, "x", "-y", f"-o{work / 'toolchain'}", str(toolchain_archive)],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    with zipfile.ZipFile(source_archive) as archive:
        archive.extractall(work / "source")
    source = work / "source" / "lua-zip-project"
    kit = work / "toolchain" / "w64devkit"

    lua = read_pe(ROOT / "bin" / "lua51.dll")
    if not lua["is_dll"] or not all(name in lua["exports"]
                                    for name in ["luaL_register", "lua_gettop", "lua_pushinteger"]):
        raise ValueError("Expected the shipped Lua 5.1 DLL")
    (work / "lua51.def").write_text(
        "LIBRARY lua51.dll\nEXPORTS\n" + "\n".join(sorted(lua["exports"])) + "\n")
    shutil.copyfile(Path(__file__).with_name("build.cmd"), work / "build.cmd")
    bottle = work / "bottle"
    env = dict(os.environ, WINEDEBUG="-all", WINEDLLOVERRIDES="winemenubuilder.exe=d")
    print("Creating isolated CrossOver bottle", flush=True)
    subprocess.run([str(cxbottle), "--bottle", str(bottle), "--create", "--template", "win7_64",
                    "--description", "XXTStudio isolated ZIP build"], env=env, check=True)
    wine_args = [str(wine), "--bottle", str(bottle), "--no-gui"]
    print(f"Compiling (log: {work / 'compile.log'})", flush=True)
    try:
        with (work / "compile.log").open("w") as log:
            subprocess.run(wine_args + ["cmd", "/c", windows_path(work / "build.cmd"),
                                       windows_path(source), windows_path(work), windows_path(kit)],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        from verify import verify_dll
        report = verify_dll(work / "zip.dll", ROOT / "bin" / "lua51.dll")
        runtime = work / "runtime"
        (runtime / "bin" / "clibs").mkdir(parents=True)
        for name in ["lua.exe", "lua51.dll"]:
            shutil.copyfile(ROOT / "bin" / name, runtime / "bin" / name)
        shutil.copyfile(work / "zip.dll", runtime / "bin" / "clibs" / "zip.dll")
        prepare_fixtures(runtime / "fixtures")
        # 禁用 Wine 自带的 VC/UCRT 实现，避免模拟器掩盖意外引入的运行库依赖。
        env["WINEDLLOVERRIDES"] += ";msvcr120,msvcp120,vcruntime140,vcruntime140_1,ucrtbase="
        with (work / "test.log").open("w") as log:
            subprocess.run(wine_args + [str(runtime / "bin" / "lua.exe"),
                                       windows_path(ROOT / "tests" / "zip.lua"),
                                       windows_path(runtime / "bin" / "clibs"),
                                       windows_path(runtime / "fixtures")],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        print((work / "test.log").read_text(), end="", flush=True)
        verify_xpa(runtime / "fixtures" / "中文 包.xpa")
        report.update({
            "toolchain": "w64devkit 2.9.1 x86 (GCC 16.2.0, CMake 4.4.2)",
            "toolchain_sha256": TOOLCHAIN_SHA256,
            "source_sha256": SOURCE_SHA256,
            "runtime_test": "CrossOver; VC++ 2013 and UCRT overrides disabled",
            "native_windows_xp": "not tested",
            "native_windows_10_11": "not tested",
        })
        (work / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        if args.install:
            shutil.copyfile(work / "zip.dll", ROOT / "bin" / "clibs" / "zip.dll")
            shutil.copyfile(work / "report.json", Path(__file__).with_name("build-report.json"))
            print("Installed bin/clibs/zip.dll", flush=True)
        print(f"Verified candidate: {work / 'zip.dll'}", flush=True)
    finally:
        # 仅停止本次临时容器；保留日志、工具链和产物供复查。
        subprocess.run([str(args.crossover / "bin" / "wineserver"), "-k"],
                       env=dict(env, WINEPREFIX=str(bottle)), check=False)


if __name__ == "__main__":
    main()
