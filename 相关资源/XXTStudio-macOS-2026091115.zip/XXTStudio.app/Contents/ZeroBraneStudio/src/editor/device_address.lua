local address = {}

function address.parse(device)
  local ip, port
  if type(device) == "table" then
    ip, port = device.ip, device.port
  elseif type(device) == "string" then
    local value = device:match("^%s*(.-)%s*$")
    ip, port = value:match("^([^:]+):(%d+)$")
    if not ip then ip = value end
  end
  if type(ip) ~= "string" or not ip:match("^[%w_.%-]+$") then return nil end
  if port == nil then port = 46952 end
  if type(port) == "string" and port:match("^%d+$") then port = tonumber(port) end
  if type(port) ~= "number" or port ~= math.floor(port)
    or port < 1 or port > 65535 then return nil end
  return ip, port
end

function address.format(device, include_default_port)
  local ip, port = address.parse(device)
  if not ip then return "" end
  if port == 46952 and not include_default_port then return ip end
  return ip .. ":" .. port
end

return address
