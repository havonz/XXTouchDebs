return {
  [0] = function(c) return c == 1 and 1 or 2 end, -- plural
  ["traced %d instruction"] = {"traced %d instruction", "traced %d instructions"}, -- src\editor\debugger.lua
  ["Found %d instance."] = {"Found %d instance.", "Found %d instances."}, -- src\editor\findreplace.lua
  ["Replaced %d instance."] = {"Replaced %d instance.", "Replaced %d instances."}, -- src\editor\findreplace.lua
  ["Updated %d file."] = {"Updated %d file.", "Updated %d files."}, -- src\editor\findreplace.lua
  ["Enter the device IP address, optionally followed by :port"] =
    "Enter the device IP address, optionally followed by :port",
  ["Enter a valid IP address and a port between 1 and 65535"] =
    "Enter a valid IP address and a port between 1 and 65535",
}
