local func = loadfile("src/editor/device_log_orig.lua")
func(...)

local _FileWrite = FileWrite
FileWrite = function (fn, data, ...)
	if type(fn) == 'string' and fn:sub(-8, -1) == "nLog.xxt" and type(data) == 'string' and data:sub(1, 4) == "\x1BXXT" then
		fn = fn:sub(1, -4).."lua"
		data = [[
local args = proc_get("spawn_args")
local ip = "0.0.0.0"
local port = 46542
args = json.decode(args)
if type(args) == "table" then
	ip = args.log_ip or ip
	port = args.log_port or port
else
	return function()return function()end end
end
return (function()
	local socket = require("socket")
	local select = select
	local insert = table.insert
	local deep_print = table.deep_print
	local type = type
	local format = string.format
	local getinfo = debug.getinfo
	local concat = table.concat
	local len = string.len
	local modf = math.modf
	local char = string.char
	local SendMessage = function(...)
		if not (ip and ip ~= '') then return end
		local s = socket.tcp()
		s:settimeout(1)
		if s:connect(ip, 46542) == 1 then
			local _m = {};
			for i = 1, select('#', ...) do
				if type(select(i, ...)) == 'table' then
					insert(_m, table.deep_print(({...})[i]))
				elseif type(select(i, ...)) == 'nil' then
					insert(_m, 'nil')
				elseif type(select(i, ...)) == 'string' then
					local m = tostring(select(i, ...)):gsub('%[DATE%]',os.date('[%Y-%m-%d %H:%M:%S]')):gsub('%[LINE%]','['..tostring(debug.getinfo(2).currentline)..']')
					insert(_m, m)
				else
					insert(_m, format('%s',select(i, ...)))
				end
			end
			local _message = concat(_m,'\t') .. '\n'
			--sys.alert(string.format("%05x", #_message))
			s:send(string.format("%05x", #_message));
			s:send(string.sub(_message, 1, 0xffff));
			s:receive(1)
			s:close()
		end
		return ...
	end
	return SendMessage
end)
]]
	end
	return _FileWrite(fn, data, ...)
end

function file_reads(fname)
	local f, err = io.open(fname, "r")
	if not f then
		return nil, err
	end
	local s = f:read("*a")
	f:close()
	return s
end

debug.sethook(function(event, line)
    local info = debug.getinfo(2)
    if info.name == "connect_device" then
		local _, t = debug.getupvalue(info.func, 2)
		local request = t.http.request
		t.http.request = function(req, ...)
			if type(req) == 'table' and type(req.url) == 'string' then
				if req.url:sub(-6, -1) == '/spawn' then
					local spawn_args = req.headers.spawn_args
					spawn_args = json.decode(spawn_args)
					spawn_args.cert = file_reads("cert/cert.crt")
					spawn_args.prikey = file_reads("cert/pri.key")
					req.headers.spawn_args = json.encode(spawn_args)
				elseif req.url:sub(-8, -1) == '/encript' then
					local args = req.headers.args
					args = json.decode(args)
					args.cert = file_reads("cert/cert.crt")
					args.prikey = file_reads("cert/pri.key")
					req.headers.args = json.encode(args)
				end
			end
			return request(req, ...)
		end
		debug.sethook()
    end
end, "c")