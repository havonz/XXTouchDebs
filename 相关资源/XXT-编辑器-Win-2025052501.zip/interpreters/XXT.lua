dofile 'interpreters/luabase.lua'
local interpreter = MakeLuaInterpreter(5.3, ' 5.3')
interpreter.skipcompile = true
interpreter.name = 'XXT with'..interpreter.name
table.insert(interpreter.api, 'XXT')
return interpreter
