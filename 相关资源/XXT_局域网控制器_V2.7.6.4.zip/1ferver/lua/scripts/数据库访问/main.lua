local CC = require('CC')
if not CC.connect() then
	error('连接失败')
end

CC.log({['脚本'] = "数据库访问"})

CC.log('添加账号')
for i = 1, 10 do
	local username = '测试账号 ' .. i
	local password = '测试密码 ' .. i
	local server = '一区'
	local ret = CC.db.add(
		'账号表',
		{
			{	-- 此处要和数据库一一对应
				['账号'] = username,
				['密码'] = password,
				['区'] = server
			}
		}
	)
	if ret[1].state then
		CC.log({['添加账号'] = username})
	else
		CC.log('数据库添加失败')
	end
	sys.sleep(1)
end
CC.log{['添加账号'] = ''}




CC.log('读取账号改写数据')
while true do
	local ret = CC.db.get('账号表', {
		{	-- 取号判断依据
			['区'] = '一区'
		},
		{	-- 取完后改写字段避免重复获取
			['区'] = '一区已操作'
		}
	})
	if #ret == 0 then
		break
	else
		CC.log({['得到账号'] = ret[1]['账号']})
	end
	sys.sleep(1)
end
CC.log{['得到账号'] = ''}




CC.log('读取账号并删除')
while true do
	local ret = CC.db.get('账号表', {
		{	-- 取号判断依据
			['区'] = '一区已操作'
		},
		{}
	})
	if #ret == 0 then
		break
	else
		local username = ret[1]['账号']
		local ret = CC.db.del(
			'账号表',
			{     --删除id为6的项
				{
					['id'] = ret[1].id
				}
			}
		)
		if ret[1].state then
			CC.log({['删除账号'] = username})
		end
	end
	sys.sleep(1)
end
CC.log{['删除账号'] = ''}




CC.log('结束操作')

