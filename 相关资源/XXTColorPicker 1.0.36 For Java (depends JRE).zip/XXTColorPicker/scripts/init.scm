(import "java.lang.*")

(log-newline)

(log-write "hehe")

(log-newline)

(log-write (concat "hehe" "\t" "haha"))

(log-newline)

(log-print "呵呵" "哈哈" "呵呵")

(log-print (concat "hehe" "haha"))
