if exist "%systemroot%\system32\winebrowser.exe" (
	winebrowser.exe %~dp0\XXTColorPicker.jar
) else (
	start javaw.exe -Xms128m -Xmx512m -Dfile.encoding=UTF-8 -Dsun.java2d.dpiaware=false -jar %~dp0\XXTColorPicker.jar
)
