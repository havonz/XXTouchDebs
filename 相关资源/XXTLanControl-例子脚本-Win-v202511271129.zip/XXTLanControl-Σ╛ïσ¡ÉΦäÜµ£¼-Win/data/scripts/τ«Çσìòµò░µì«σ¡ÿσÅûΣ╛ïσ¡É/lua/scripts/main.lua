local LCC = require "XXTLanControl"

while not LCC.connect() do
    sys.alert("连接中控失败，一秒后重试", 1)
end

-- KVDB 存储操作完成可以在中控的 KVDB 管理器查看
-- KVDB 将会保存在 data 路径下的 kvdb.db 文件

local kvdb = LCC.kvdb

-- 1.日志
LCC.log(1, "脚本开始 "..sys.mtime())

-- 队列
local sz, err = kvdb.queue.push_back("队列1", "ABC") -- 存储一个值 ABC 到中控端名叫 "队列1" 的队列
if sz then
    LCC.log(1, "推入值后尺寸：", sz)
else
    LCC.log(1, "推入值发生错误：", err)
end

local val, err = kvdb.queue.pop_front("队列1") -- 从中控端名叫 "队列1" 的队列中弹出一个值
if val then
    LCC.log(1, "弹出一个值：", val)
else
    LCC.log(1, "弹出值发生错误：", err)
end

local sz, err = kvdb.queue.push_front("队列1", "BCD")
local sz, err = kvdb.queue.push_back("队列1", "CDE")
local sz, err = kvdb.queue.push_back("队列1", "EFG")
local arr, err = kvdb.queue.list("队列1")
if arr then
    LCC.log(1, "队列1：", arr)
end
local n, err   = kvdb.queue.count("队列1")
if n then
    LCC.log(1, "队列1尺寸：", n)
end

-- local cleared, err = kvdb.queue.clear("队列1") -- 清空队列
-- LCC.log(1, cleared)

-- 词典
local old, err = kvdb.dict.put("词典1", "键1", "值1")
LCC.log(1, "词典1.键1 旧值：", old)

local v, err = kvdb.dict.get("词典1", "键1")
LCC.log(1, "词典1.键1 的值：", v)

local all, err = kvdb.dict.get_all("词典1")
LCC.log(1, "词典1 的所有值：", all)

-- local removed, err = kvdb.dict.clear("词典1") -- 清空的词典
-- LCC.log(1, removed)

LCC.log(1, "脚本结束 "..sys.mtime())
