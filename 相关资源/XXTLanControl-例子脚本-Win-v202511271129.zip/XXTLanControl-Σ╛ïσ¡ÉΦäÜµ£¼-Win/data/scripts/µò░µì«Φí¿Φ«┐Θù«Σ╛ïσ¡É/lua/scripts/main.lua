--[[
    启动脚本后，可以在中控的 "日志 #1" 中看到脚本运行情况
    同时可以在中控的 "数据表" 的 "测试表" 中看到脚本添加/更新的数据
--]]

local LCC = require "XXTLanControl"

while not LCC.connect() do
    sys.alert("连接中控失败，一秒后重试", 1)
end

thread.dispatch(function()
    while true do
        sys.toast('请在中控端打开"数据表-测试表"刷新查看数据')
        sys.msleep(500)
    end
end)

LCC.log(1, "脚本开始 "..sys.mtime())

-- 创建测试表，如果表已经存在，则忽略
LCC.log(1, '正在创建测试表...')
LCC.db.create("测试表", {"账号", "密码", "分区", "状态"})
sys.msleep(1000)

-- 添加测试数据
LCC.log(1, "正在添加测试数据...")
LCC.db.add("测试表", {
    {['账号'] = "admin0", ['密码'] = "123456", ['分区'] = "1", ['状态'] = "还没开始"},
    {['账号'] = "admin1", ['密码'] = "123456", ['分区'] = "2", ['状态'] = "还没开始"},
    {['账号'] = "admin2", ['密码'] = "123456", ['分区'] = "3", ['状态'] = "还没开始"},
    {['账号'] = "admin3", ['密码'] = "123456", ['分区'] = "4", ['状态'] = "还没开始"},
    {['账号'] = "admin4", ['密码'] = "123456", ['分区'] = "5", ['状态'] = "还没开始"},
    {['账号'] = "admin5", ['密码'] = "123456", ['分区'] = "6", ['状态'] = "还没开始"},
})
sys.msleep(1000)

LCC.log(1, "现在可以打开数据表刷新查看数据...")
sys.msleep(5000)

local tasks = {}

for i=1, 7 do
    local v, err = LCC.db.fetch_one("测试表", {conditions = {['状态'] = '还没开始'}, update = {['状态'] = '进行中'}})
    if v then
        LCC.log(1, "获取到一条数据", v["账号"])
        tasks[#tasks + 1] = v
    else
        LCC.log(1, "获取数据失败", err)
    end
    sys.msleep(2000)
end

for i=1, 10 do
    LCC.log(1, "假装正在做任务..."..sys.mtime())
    sys.msleep(1000)
end

for _, v in ipairs(tasks) do
    local r, err = LCC.db.edit("测试表", {
        {
            id = v["id"],
            ['状态'] = "已完成"
        }
    })
    if r then
        LCC.log(1, "更新数据成功", v["账号"])
    else
        LCC.log(1, "更新数据失败", v["账号"], err)
    end
    sys.msleep(2000)
end

LCC.log(1, "脚本结束 "..sys.mtime())
os.exit()