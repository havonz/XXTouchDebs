local LCC = require "XXTLanControl"

while not LCC.connect() do
    sys.alert("连接中控失败，一秒后重试", 1)
end

-- 在中控上选择脚本之后，点脚本名称右边的 “配置” 按钮可以配置一些参数
-- 可以在 “文件管理” 中找到脚本文件夹，右键点击 “编辑脚本 UI 配置”
-- 配置完成后，点运行脚本时，main.json 会同脚本一起发送到设备执行，脚本里只需要读取 LCC.get_ui_config() 即可
-- 如果脚本是以分组配置运行，则 LCC.get_ui_config() 将获取到分组上配置的参数

-- 1.日志
LCC.log(1, "脚本开始 "..sys.mtime())

local conf = LCC.get_ui_config()

print("姓名", conf['姓名'])
print("性别", conf['性别'])
print("最爱玩", conf['最爱玩的游戏'])
print("喜欢玩")
for k, _ in pairs(conf['喜欢的游戏们']) do
    print("", k)
end

LCC.log(1, "已在设备上弹窗显示你的配置 "..sys.mtime())
sys.alert(print.out())

LCC.log(1, "脚本结束 "..sys.mtime())
