local LCC = require "XXTLanControl"

while not LCC.connect() do
    sys.alert("连接中控失败，一秒后重试", 1)
end

local web_file = LCC.web_file

-- 1.日志
LCC.log(1, "脚本开始 "..sys.mtime())

local data, err = web_file.reads("/暇头像~o^.png")
if data then
    LCC.log(1, "已经在设备上显示图像 "..sys.mtime())
    dialog()
        :add_label('电脑上的 "data/files/暇头像~o^.png"')
        :add_image(image.load_data(data))
        :show()
else
    sys.alert(tostring(err), 0, "web_file.reads 发生错误")
end

local ok, err = web_file.writes('/设备截屏.png', screen.image():png_data())
if ok then
    LCC.log(1, "设备截屏已经保存到电脑 "..sys.mtime())
    sys.alert('设备截屏已经保存到电脑端\n"data/files/设备截屏.png"')
else
    sys.alert(tostring(err), 0, "web_file.writes 发生错误")
end


LCC.log(1, "脚本结束 "..sys.mtime())
