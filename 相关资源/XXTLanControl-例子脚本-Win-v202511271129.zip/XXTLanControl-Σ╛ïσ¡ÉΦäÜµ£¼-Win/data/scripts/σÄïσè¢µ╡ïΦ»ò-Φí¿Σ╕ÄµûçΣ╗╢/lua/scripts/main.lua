local LCC = require "XXTLanControl"

-- 与示例保持一致：先连接中控，失败则提示后重试
while not LCC.connect() do
    sys.alert("连接中控失败，一秒后重试", 1)
end

-- 配置
local TIMEOUT = 30
local SEED_COUNT = 4000
local SLEEP_MS = 5         -- 更高频率循环
local UDID = device.udid()
local TABLE = "压力测试-任务表"
local COLS = { "名称", "状态", "设备", "备注", "创建者" }

-- 文件路径：一个设备独享 + 一个全设备共享，制造一定争用
local DIR = "stress"
local DEV_FILE = DIR .. "/device-" .. UDID .. ".txt"
local SHARED_FILE = DIR .. "/共享-测试-队列.txt"

local function logi(msg) pcall(function() LCC.log(1, tostring(msg)) end) end
local function logw(msg) pcall(function() LCC.log(2, "[WARN] " .. tostring(msg)) end) end
local function loge(msg) pcall(function() LCC.log(3, "[ERR] " .. tostring(msg)) end) end

-- 安全调用封装：既捕获 Lua 异常，也处理二返回值的 err
local function call(name, fn, ...)
  local ok, r1, r2 = pcall(fn, ...)
  if not ok then
    loge(name .. " exception: " .. tostring(r1))
    return nil, r1
  end
  if r1 == nil and r2 ~= nil then
    loge(name .. " error: " .. tostring(r2))
  end
  return r1, r2
end

-- 针对 get_line / get_range_lines 的“204 No Content”容错包装：
-- 后端在无内容场景返回 204 且响应体为空字符串，LCC 封装返回 (nil, "")。
-- 这里把这种情况当作“空内容”而不是错误，避免日志刷屏。
local function safe_get_line(path, line)
  local v, err = LCC.web_file.get_line(path, line, TIMEOUT)
  if v ~= nil then return v end
  if err == "" then return "" end
  loge("web_file.get_line failed: " .. tostring(err))
  return ""
end

local function safe_get_range(path, start_line, count)
  local v, err = LCC.web_file.get_range_lines(path, start_line, count, TIMEOUT)
  if v ~= nil then return v end
  if err == "" then return {} end
  loge("web_file.get_range_lines failed: " .. tostring(err))
  return {}
end

-- 1) 准备表：创建 + 预填行（幂等）
do
  local created, err = call("db.create", LCC.db.create, TABLE, COLS, TIMEOUT)
  if created == false and err == "table already exists" then
    -- 已存在，忽略
  elseif created == false then
    logw("db.create: " .. tostring(err))
  end

  -- 每台设备按“创建者=本设备UDID”补齐到 SEED_COUNT 行
  do
    local CREATOR_COL = "创建者"
    local ownCount, e1 = LCC.db.count(TABLE, { [CREATOR_COL] = UDID }, TIMEOUT)
    if ownCount == nil and e1 and tostring(e1):find("unknown column", 1, true) then
      -- 老表无“创建者”列时退化为使用“设备”列
      CREATOR_COL = "设备"
      local v = LCC.db.count(TABLE, { [CREATOR_COL] = UDID }, TIMEOUT)
      ownCount = tonumber(v or 0) or 0
    else
      ownCount = tonumber(ownCount or 0) or 0
    end

    local need = SEED_COUNT - ownCount
    if need > 0 then
      local batch = {}
      local function flush()
        if #batch > 0 then
          call("db.add", LCC.db.add, TABLE, batch, TIMEOUT)
          batch = {}
        end
      end
      for i = 1, need do
        local idx = ownCount + i
        local note = string.format("seed@%s#%d-%s", os.date("%H%M%S"), idx, UDID)
        local row = {
          ["名称"] = "任务-" .. tostring(idx),
          ["状态"] = "空闲",
          ["设备"] = "",
          ["备注"] = note,
        }
        row[CREATOR_COL] = UDID
        batch[#batch+1] = row
        if #batch >= 200 then flush() end
      end
      flush()
      logi(string.format("创建者=%s 补齐 %d 行，共 %d", UDID, need, SEED_COUNT))
    else
      logi(string.format("创建者=%s 已有 %d 行，无需补齐", UDID, ownCount))
    end
  end
end

-- 2) 准备文件目录 + 设备文件
do
  call("web_file.mkdir", LCC.web_file.mkdir, DIR, TIMEOUT)
  local devTyp = call("web_file.exists(dev)", LCC.web_file.exists, DEV_FILE, TIMEOUT)
  if not devTyp then
    call("web_file.writes(dev)", LCC.web_file.writes, DEV_FILE, "init\n", TIMEOUT)
  end
  local sharedTyp = call("web_file.exists(shared)", LCC.web_file.exists, SHARED_FILE, TIMEOUT)
  if not sharedTyp then
    call("web_file.writes(shared)", LCC.web_file.writes, SHARED_FILE, "shared-init\n", TIMEOUT)
  end
end

-- math.randomseed(os.time() ~- tonumber(string.sub(UDID or "0", -4)) )

-- 3) 压力循环：循环调用以下 API
-- LCC.db.count / LCC.db.fetch_one / LCC.db.list / LCC.web_file.exists / LCC.web_file.remove_line
local iter, okFetch, cntIdle, listGot, fileOps = 0, 0, 0, 0, 0
local cntRunning = 0
local picks = { "min", "max", "random" }

-- 维护本设备已领取的 id 集合（进行中），用于成批归还，且不超过自身配额
local claimed_ids = {}
local claimed_pos = {}   -- id -> index in claimed_ids

local function claimed_count() return #claimed_ids end
local function claimed_has(id) return id ~= nil and claimed_pos[id] ~= nil end
local function claimed_add(id)
  if id == nil or claimed_pos[id] then return end
  claimed_ids[#claimed_ids + 1] = id
  claimed_pos[id] = #claimed_ids
end
local function claimed_remove_index(idx)
  local n = #claimed_ids
  if idx < 1 or idx > n then return nil end
  local id = claimed_ids[idx]
  local last = claimed_ids[n]
  claimed_ids[idx] = last
  claimed_ids[n] = nil
  claimed_pos[id] = nil
  if last ~= id then claimed_pos[last] = idx end
  return id
end
local function claimed_pop_random()
  local n = #claimed_ids
  if n == 0 then return nil end
  local idx = math.random(1, n)
  return claimed_remove_index(idx)
end
local function claimed_pop_random_n(n)
  local out = {}
  for i = 1, n do
    local id = claimed_pop_random()
    if not id then break end
    out[#out + 1] = id
  end
  return out
end

-- 插入/删除突发参数（针对同一个共享文件，多个设备共同竞争）
-- 等量对冲（简化版）：仅按设备自身插入配额控制插入与删除
local OWN_INS_TOTAL = 0    -- 本设备累计成功插入行数
local OWN_DEL_TOTAL = 0    -- 本设备累计成功删除行数

local function safe_line_count(path)
  local c, err = LCC.web_file.line_count(path, TIMEOUT)
  if c == nil then return 0 end
  return tonumber(c) or 0
end

while true do
  iter = iter + 1
  -- 记录本轮表数据领取与归还数量
  local fetched_iter, returned_iter = 0, 0

  -- 3.1 count: 统计空闲数量
  do
    local n = call("db.count(空闲)", LCC.db.count, TABLE, { ["状态"] = "空闲" }, TIMEOUT)
    cntIdle = tonumber(n or 0) or 0
  end

  -- 3.2 领取/归还对冲（数据表）：
  do
    local MAX_CLAIMED = 3000
    local FETCH_MAX = 1000
    local RETURN_MAX = 1000

    local owned = claimed_count()
    if owned >= MAX_CLAIMED then
      -- 仅归还
      local retN = math.min(owned, math.random(1, RETURN_MAX))
      if retN > 0 then
        local ids = claimed_pop_random_n(retN)
        returned_iter = returned_iter + (#ids)
        if #ids > 0 then
          local edits = {}
          for i = 1, #ids do
            edits[#edits + 1] = { id = ids[i], ["状态"] = "空闲", ["设备"] = "", ["备注"] = "release@" .. os.date("%H:%M:%S") }
          end
          call("db.edit(release)", LCC.db.edit, TABLE, edits, TIMEOUT)
        end
      end
    else
      -- 领取 [1..1000]
      local fetchN = math.random(1, FETCH_MAX)
      for j = 1, fetchN do
        local pick = picks[((iter + j) % #picks) + 1]
        local row = call("db.fetch_one", LCC.db.fetch_one, TABLE, {
          conditions = { ["状态"] = "空闲" },
          update = { ["状态"] = "进行中", ["设备"] = UDID, ["备注"] = "pick=" .. pick },
          pick = pick,
        }, TIMEOUT)
        if row and row.id then
          okFetch = okFetch + 1
          fetched_iter = fetched_iter + 1
          claimed_add(row.id)
        else
          break
        end
      end
      -- 随机归还 [1..1000]（不得超过本机已领取）
      local owned2 = claimed_count()
      if owned2 > 0 then
        local retN = math.min(owned2, math.random(1, RETURN_MAX))
        if retN > 0 then
          local ids = claimed_pop_random_n(retN)
          returned_iter = returned_iter + (#ids)
          if #ids > 0 then
            local edits = {}
            for i = 1, #ids do
              edits[#edits + 1] = { id = ids[i], ["状态"] = "空闲", ["设备"] = "", ["备注"] = "release@" .. os.date("%H:%M:%S") }
            end
            call("db.edit(release)", LCC.db.edit, TABLE, edits, TIMEOUT)
          end
        end
      end
    end
  end

  -- 3.3 list: 列出部分“进行中”，分页/排序
  do
    local lst = call("db.list(进行中)", LCC.db.list, TABLE, {
      conditions = { ["状态"] = "进行中" },
      order_by = "id",
      desc = false,
      limit = 5,
      offset = 0,
    }, TIMEOUT)
    if type(lst) == "table" then
      listGot = (lst and #lst or 0)
      cntRunning = listGot -- 仅作近似观测
    end
  end

  -- 3.3.1（已替换为上面的对冲逻辑）

  -- 3.4 文件 exists + 高频追加 + 高频读取 + 删除首/末行（设备文件）
  do
    local typ = call("web_file.exists(dev)", LCC.web_file.exists, DEV_FILE, TIMEOUT)
    if not typ then
      call("web_file.writes(dev)", LCC.web_file.writes, DEV_FILE, "init\n", TIMEOUT)
    end
    -- 高频追加
    call("web_file.appends(dev)", LCC.web_file.appends, DEV_FILE,
         string.format("dev %s tick %d @ %s\n", UDID, iter, os.date("%H:%M:%S")), TIMEOUT)
    fileOps = fileOps + 1
    -- 高频读取：首/末行与头尾范围（204 视为空内容，不记为错误）
    safe_get_line(DEV_FILE, 1)
    safe_get_line(DEV_FILE, -1)
    safe_get_range(DEV_FILE, 1, 3)
    safe_get_range(DEV_FILE, -3, 3)
    if (iter % 100) == 0 then
      call("web_file.reads(dev)", LCC.web_file.reads, DEV_FILE, TIMEOUT)
      call("web_file.md5(dev)", LCC.web_file.md5, DEV_FILE, TIMEOUT)
    end
    -- 高频删除：交替删除首行/末行
    if (iter % 2) == 0 then
      call("web_file.remove_line(dev#1)", LCC.web_file.remove_line, DEV_FILE, 1, TIMEOUT)
    else
      call("web_file.remove_line(dev#-1)", LCC.web_file.remove_line, DEV_FILE, -1, TIMEOUT)
    end
    fileOps = fileOps + 1
  end

  -- 3.5 共享文件：制造争用 + 高频读取 + 等量对冲（按自身插入控制）
  do
    -- 高频共享文件争用 + 读取
    call("web_file.exists(shared)", LCC.web_file.exists, SHARED_FILE, TIMEOUT)
    safe_get_line(SHARED_FILE, 1)
    safe_get_line(SHARED_FILE, -1)
    safe_get_range(SHARED_FILE, 1, 3)
    safe_get_range(SHARED_FILE, -3, 3)
    -- 去除基础 append/基线删除，完全由 insert_line/remove_line 控制增长
    if (iter % 100) == 0 then
      call("web_file.reads(shared)", LCC.web_file.reads, SHARED_FILE, TIMEOUT)
      call("web_file.md5(shared)", LCC.web_file.md5, SHARED_FILE, TIMEOUT)
    end

    -- 简化策略：
    -- 1) 若自身未对冲插入(outstanding) > 2000，则本轮仅删除100行（若不足则删至0），不插入
    -- 2) 否则插入 [1..30] 行，并删除 [1..30] 行（删除不得超过自身 outstanding）
    local outstanding = OWN_INS_TOTAL - OWN_DEL_TOTAL
    if outstanding > 2000 then
      local del_target = math.min(1000, outstanding)
      local lc = safe_line_count(SHARED_FILE)
      local removed_ok = 0
      for k = 1, del_target do
        if lc <= 0 then break end
        local idx = math.random(1, lc)
        local line, err = LCC.web_file.remove_line(SHARED_FILE, idx, TIMEOUT)
        -- 成功删除应返回被删行内容；空字符串表示未删（可能越界/并发漂移）
        if type(line) == 'string' and #line > 0 then
          removed_ok = removed_ok + 1
          lc = lc - 1
        end
      end
      if removed_ok > 0 then OWN_DEL_TOTAL = OWN_DEL_TOTAL + removed_ok; fileOps = fileOps + removed_ok end
    else
      -- 插入 [1..30]
      local ins_target = math.random(1, 30)
      local inserted_ok = 0
      for k = 1, ins_target do
        local line = string.format("INS %s #%d iter=%d @ %s", UDID, k, iter, os.date("%H:%M:%S"))
        local ok, err = LCC.web_file.insert_line(SHARED_FILE, 0, line, TIMEOUT)
        if ok then inserted_ok = inserted_ok + 1 end
      end
      if inserted_ok > 0 then OWN_INS_TOTAL = OWN_INS_TOTAL + inserted_ok; fileOps = fileOps + inserted_ok end

      -- 删除 [1..30]，但不得超过自身 outstanding
      outstanding = OWN_INS_TOTAL - OWN_DEL_TOTAL
      local del_target = math.min(math.random(1, 30), outstanding)
      if del_target > 0 then
        local lc = safe_line_count(SHARED_FILE)
        local removed_ok = 0
        for k = 1, del_target do
          if lc <= 0 then break end
          local idx = math.random(1, lc)
          local line, err = LCC.web_file.remove_line(SHARED_FILE, idx, TIMEOUT)
          if type(line) == 'string' and #line > 0 then
            removed_ok = removed_ok + 1
            lc = lc - 1
          end
        end
        if removed_ok > 0 then OWN_DEL_TOTAL = OWN_DEL_TOTAL + removed_ok; fileOps = fileOps + removed_ok end
      end
    end
  end

  -- 3.6 每轮统计输出（设备当前持有量 + 本轮领取/归还）
  logi(string.format("迭代=%d 已持有=%d 本轮领取=%d 本轮归还=%d (累计fetch_ok=%d)",
    iter, claimed_count(), fetched_iter, returned_iter, okFetch))

  -- 3.7 让出时间片（可调小/大以改变压力）
  sys.msleep(SLEEP_MS)
end
