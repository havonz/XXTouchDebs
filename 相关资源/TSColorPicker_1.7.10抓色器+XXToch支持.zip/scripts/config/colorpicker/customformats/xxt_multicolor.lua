﻿
--[[

格式说明：

{
	下拉选项标题,
	{
		customKeyMap = 自定义快捷键映射表,
		singlePosFormatRule = 单点取色生成格式函数,
		multiPosFormatRule = 多点取色生成格式函数,
		currentPosInfo = 鼠标所指当前点的格式生成函数（面板上那个随着鼠标移动时刻在变化的内容）,
		makeScriptRule = { -- 自定义脚本规则
			生成第 1 个文本框内容的函数,
			生成第 2 个文本框内容的函数,
			生成第 3 个文本框内容的函数,
		},
	},
}

customKeyMap 说明：
	可参考 scripts/config/colorpicker/keymap.lua 的返回值


singlePosFormatRule、multiPosFormatRule 参数说明：
	p：		当前点信息，包括 x、y、c、r、g、b、num
	a：		坐标缓冲位 A 的信息，包括 x、y
	s：		坐标缓冲位 S 的信息，包括 x、y
	x：		坐标缓冲位 X 的信息，包括 x、y
	c：		坐标缓冲位 C 的信息，包括 x、y
	set:	扩展设置列表


makeScriptRule 参数说明：
	poslist: {
		p,
		p,
		p,
		...
		a = {x, y},
		s = {x, y},
		x = {x, y},
		c = {x, y},
	}

	set: 扩展设置列表

如需自定义格式，可以复制当前文件的考备份重命名然后做修改
修改完成后，可以在文件 scripts/config/colorpicker/cf_enabled.lua 应用添加自定义格式

--]]

return
{"XXTouch_多点找色",
	{
		settingsRule = {
			title = "自定义格式 [动脚按摸_多点找色] 的参数设置",
			caption = {"参数名", "参数值"},
			args = {
				{"默认相似度", "90"},
				{"空格补齐", "1"},
				{"换行格式", "1"},
				{"色偏模式", "0"},
				{"默认色偏", "0x101010"},
			},
		},
		singlePosFormatRule = (function(p, a, s, x, c, set)
			local fmt
			if toboolean(set["色偏模式"]) then
				fmt = string.format("{ %4d, %4d, {0x%06x, 0x%06x} }", p.x, p.y, p.c, (tonumber(set["默认色偏"], 16) or 0x101010))
			else
				fmt = string.format("{ %4d, %4d, 0x%06x }", p.x, p.y, p.c)
			end
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			require "sz"
			print("图片数据已经写入剪贴板")
			local function s2h(s,cp)return(string.gsub(s,"(.)",function(c)return string.format("\\x%02x%s",string.byte(c),cp or"")end))end
			return 'local x, y = screen.find_image(\n"'..s2h(getRectPNGData(a.x, a.y, s.x, s.y))..'"\n, 95, __这里替换成区域__)'
		end),
		multiPosFormatRule = (function(p, a, s, x, c, set)
			local fmt
			if toboolean(set["色偏模式"]) then
				fmt = string.format("{ %4d, %4d, {0x%06x, 0x%06x} },\n", p.x, p.y, p.c, (tonumber(set["默认色偏"], 16) or 0x101010))
			else
				fmt = string.format("{ %4d, %4d, 0x%06x },\n", p.x, p.y, p.c)
			end
			if not toboolean(set["换行格式"]) then
				fmt = fmt:gsub("\n", ""):gsub("\t", "")
			end
			if not toboolean(set["空格补齐"]) then
				fmt = fmt:gsub(" ", "")
			end
			return fmt
		end),
		currentPosInfo = make_currentPosInfo("{ %4d, %4d, 0x%06x }"),
		makeScriptRule = {
			(function(poslist, set)
				local ret = "{\n"
				for _,currentPos in ipairs(poslist) do
					if toboolean(set["色偏模式"]) then
						ret = ret..string.format("\t{ %4d, %4d, {0x%06x, 0x%06x} },\n", currentPos.x, currentPos.y, currentPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
					else
						ret = ret..string.format("\t{ %4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
					end
				end
				ret = ret.."}"
				if not toboolean(set["换行格式"]) then
					ret = ret:gsub("[\n\t]", "")
				end
				if not toboolean(set["空格补齐"]) then
					ret = ret:gsub(" ", "")
				end
				return ret
			end),
			(function(poslist, set)
				local ret = "x, y = screen.find_color({\n"
				for i,currentPos in ipairs(poslist) do
					if toboolean(set["色偏模式"]) then
						ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", currentPos.x, currentPos.y, currentPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
					else
						ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x, currentPos.y, currentPos.c)
					end
				end
				if toboolean(set["色偏模式"]) then
					ret = ret.."}"
				else
					ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
				end
				if (0 ~= poslist.a.x) and
				   (0 ~= poslist.a.y) and
				   (0 ~= poslist.s.x) and
				   (0 ~= poslist.s.y) then
				   ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
				end
				ret = ret..")"
				if not toboolean(set["换行格式"]) then
					ret = ret:gsub("[\n\t]", "")
				end
				if not toboolean(set["空格补齐"]) then
					ret = ret:gsub(" ", "")
				end
				return ret
			end),
			(function(poslist, set)
				local ret = "x, y = screen.find_color({\n"
				local firstPos
				for i,currentPos in ipairs(poslist) do
					if (1 == i) then
						firstPos = currentPos
						if toboolean(set["色偏模式"]) then
							ret = ret..string.format("\t{%4d, %4d, {0x%06x, 0x%06x} },\n", 0, 0, firstPos.c, (tonumber(set["默认色偏"], 16) or 0x101010))
						else
							ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", 0, 0, firstPos.c)
						end
					else
						ret = ret..string.format("\t{%4d, %4d, 0x%06x },\n", currentPos.x - firstPos.x, currentPos.y - firstPos.y, currentPos.c)
					end
				end
				if toboolean(set["色偏模式"]) then
					ret = ret.."}"
				else
					ret = ret.."}, "..tostring(tonumber(set["默认相似度"]) or 90)
				end
				if (0 ~= poslist.a.x) and
				   (0 ~= poslist.a.y) and
				   (0 ~= poslist.s.x) and
				   (0 ~= poslist.s.y) then
				   ret = ret..string.format(", %4d, %4d, %4d, %4d", poslist.a.x, poslist.a.y, poslist.s.x, poslist.s.y)
				end
				ret = ret..")"
				if not toboolean(set["换行格式"]) then
					ret = ret:gsub("[\n\t]", "")
				end
				if not toboolean(set["空格补齐"]) then
					ret = ret:gsub(" ", "")
				end
				return ret
			end),
			testRule = { -- [+ 1.7.7]
				nil,
				(function(s)
					return s..[[ 
						nLog("多点找色结果："..tostring(x).." ,"..tostring(y))
					]]
				end),
				(function(s)
					return s..[[ 
						nLog("多点找色结果："..tostring(x).." ,"..tostring(y))
					]]
				end),
			},
		},
	},
}
