﻿--[[

	文件名:
		scripts/config/colorpicker/cf_enabled.lua
	说明:
		自定义格式启用列表配置文件

--]]

return {
-- 当前文件表示激活的自定义格式列表
-- 文件名请用英文，此处不要写扩展名
-- 当前文件中的内容的顺序是有意义的
-- 格式文件放在这个目录中 scripts/config/colorpicker/customformats/
	"taotao_rgb",
	"taotao_hex",
	"simple_matrix",
	"old_ver",
	"xxt_multicolor",
}
