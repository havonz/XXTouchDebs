
function posToRegA()
    setRegA(getCurrentXY())
end

function posToRegS()
    setRegS(getCurrentXY())
end

function posToRegX()
    setRegX(getCurrentXY())
end

function posToRegC()
    setRegC(getCurrentXY())
end

function moveMouseToPosOfRegA()
    moveMouseToXY(getRegA())
end

function moveMouseToPosOfRegS()
    moveMouseToXY(getRegS())
end

function moveMouseToPosOfRegX()
    moveMouseToXY(getRegX())
end

function moveMouseToPosOfRegC()
    moveMouseToXY(getRegC())
end

function moveMouseUp()
    local x, y = getCurrentXY()
    y = y - 1
    moveMouseToXY(x, y)
end

function moveMouseDown()
    local x, y = getCurrentXY()
    y = y + 1
    moveMouseToXY(x, y)
end

function moveMouseLeft()
    local x, y = getCurrentXY()
    x = x - 1
    moveMouseToXY(x, y)
end

function moveMouseRight()
    local x, y = getCurrentXY()
    x = x + 1
    moveMouseToXY(x, y)
end

function moveMouseUp10()
    local x, y = getCurrentXY()
    y = y - 10
    moveMouseToXY(x, y)
end

function moveMouseDown10()
    local x, y = getCurrentXY()
    y = y + 10
    moveMouseToXY(x, y)
end

function moveMouseLeft10()
    local x, y = getCurrentXY()
    x = x - 10
    moveMouseToXY(x, y)
end

function moveMouseRight10()
    local x, y = getCurrentXY()
    x = x + 10
    moveMouseToXY(x, y)
end

function copyRectAS()
    local ax, ay = getRegA()
    local text = table.concat({ax, ay, getRegS()}, ", ")
    copyText(text)
end

function copyRectXC()
    local ax, ay = getRegX()
    local text = table.concat({ax, ay, getRegC()}, ", ")
    copyText(text)
end

function x_AS_XC()
    local x, y = getRegA()
    setRegA(getRegX())
    setRegX(x, y)
    x, y = getRegS()
    setRegS(getRegC())
    setRegC(x, y)
end

function eraseRectAS()
    setRegA(0, 0)
    setRegS(0, 0)
end

function loadPosColorsText(text)
    if type(text) ~= 'string' then
        text = clipText()
    end
    if text:find('while') or text:find('for') or text:find('repeat') or text:find('function') then
        return
    end
    local f = load("return "..text, 'loadPosColorsText', 't', {})
    if type(f) ~= 'function' then
        f = load("return {" .. text .. "}", 'loadPosColorsText', 't', {})
    end
    if type(f) ~= 'function' then
        local t = {}
        t[#t + 1] = "return {"
        for _, v in ipairs(text:split('\n')) do
            v = v:gsub("%s","")
            if v ~= "" then
                t[#t + 1] = "{"
                t[#t + 1] = v
                t[#t + 1] = "},"
            end
        end
        t[#t + 1] = "}"
        f = load(table.concat(t), 'loadPosColorsText', 't', {})
    end
    if type(f) == 'function' then
        local ok, ret = pcall(f)
        if ok and type(ret) == 'table' then
            if reloadPosColors(ret) then
                printLog(TR("The contents in the clipboard has been loaded into the PosColor list"))
            end
        end
    end
end

function copyASRectOrCopyWholeImage()
    local a, s = getPosASXC()
    if isASRectShow() and a.x~=s.x and a.y~=s.y then
        local ok, data = pcall(getRectPNGData, a.x, a.y, s.x, s.y)
        if ok then
            writePasteboard(data)
        else
            alertErr(data)
        end
    else
        local w, h = getImageSize()
        local ok, data = pcall(getRectPNGData, 0, 0, w-1, h-1)
        if ok then
            writePasteboard(data)
        else
            alertErr(data)
        end
    end
end

function openPasteboardImageInNewTab()
    local data = readPasteboard()
    local ok, msg = pcall(loadImageData, data)
    if not ok then
        loadPosColorsText(data)
    end
end