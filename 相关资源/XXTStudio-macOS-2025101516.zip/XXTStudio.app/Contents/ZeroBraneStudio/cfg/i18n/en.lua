return {
  [0] = function(c) return c == 1 and 1 or 2 end, -- plural
  ["traced %d instruction"] = {"traced %d instruction", "traced %d instructions"}, -- src\editor\debugger.lua
  ["Found %d instance."] = {"Found %d instance.", "Found %d instances."}, -- src\editor\findreplace.lua
  ["Replaced %d instance."] = {"Replaced %d instance.", "Replaced %d instances."}, -- src\editor\findreplace.lua
  ["Updated %d file."] = {"Updated %d file.", "Updated %d files."}, -- src\editor\findreplace.lua
  ["Project Browser"] = "Project Browser", -- src\editor\project_browser.lua
  ["Set as Active Project"] = "Set as Active Project", -- src\editor\project_browser.lua
  ["Current project: %s"] = "Current project: %s", -- src\editor\project_browser.lua
  ["Cannot access %s"] = "Cannot access %s", -- src\editor\project_browser.lua
  ["Remove from Project Browser"] = "Remove from Project Browser", -- src\editor\project_browser.lua
  ["Remove %s from Project Browser? (Files on disk stay intact)"] = "Remove %s from Project Browser? (Files on disk stay intact)", -- src\editor\project_browser.lua
  ["Directory %s is already listed in Project Browser"] = "Directory %s is already listed in Project Browser", -- src\editor\project_browser.lua
  ["Load All Projects"] = "Load All Projects", -- src\editor\project_browser.lua
  ["Clear All Projects"] = "Clear All Projects", -- src\editor\project_browser.lua
  ["Please drop onto a directory."] = "Please drop onto a directory.", -- src\editor\project_browser.lua
  ["Target '%s' already exists."] = "Target '%s' already exists.", -- src\editor\project_browser.lua
  ["Cannot place '%s' inside itself."] = "Cannot place '%s' inside itself.", -- src\editor\project_browser.lua
  ["Copied '%s' to '%s'."] = "Copied '%s' to '%s'.", -- src\editor\project_browser.lua
  ["Moved '%s' to '%s'."] = "Moved '%s' to '%s'.", -- src\editor\project_browser.lua
  ["Removed %d missing project(s) from Project Browser."] = "Removed %d missing project(s) from Project Browser.", -- src\editor\project_browser.lua
  ["Cleared %d project(s), kept current project."] = "Cleared %d project(s), kept current project.", -- src\editor\project_browser.lua
  ["No project directories to clear."] = "No project directories to clear.", -- src\editor\project_browser.lua
  ["Clear all project directories except the current one? (Files on disk stay intact)"] = "Clear all project directories except the current one? (Files on disk stay intact)", -- src\editor\project_browser.lua
  ["Unable to locate the documents directory."] = "Unable to locate the documents directory.", -- src\editor\project_browser.lua
  ["Directory '%s' does not exist."] = "Directory '%s' does not exist.", -- src\editor\project_browser.lua
  ["Unable to open directory '%s': %s"] = "Unable to open directory '%s': %s", -- src\editor\project_browser.lua
  ["Loaded %d project(s) from %s."] = "Loaded %d project(s) from %s.", -- src\editor\project_browser.lua
  ["No new projects found in %s."] = "No new projects found in %s.", -- src\editor\project_browser.lua
  ["Source path '%s' does not exist."] = "Source path '%s' does not exist.", -- src\editor\project_browser.lua
  ["Operation failed."] = "Operation failed.", -- src\editor\project_browser.lua
  ["'%s' is not a readable directory"] = "'%s' is not a readable directory", -- src\editor\project_browser.lua
  ["Select project directory"] = "Select project directory", -- src\editor\project_browser.lua
  ["Add Project Directory..."] = "Add Project Directory...", -- src\editor\project_browser.lua
  ["No project directories configured."] = "No project directories configured.", -- src\editor\project_browser.lua
  ["Open Containing Folder"] = "Open Containing Folder", -- src\editor\gui.lua, src\editor\filetree.lua
}
