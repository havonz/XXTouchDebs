-- Please do not modify this file.
-- This file will restore to its initial state when the software starts.

-- 请不要修改本文件
-- 本文件会在软件启动时恢复初始状态

return {
    ["apev"] = {
        type = "snippet",
        description = "app.eval(...)",
        template = "app.eval({\n\tbid = ${app.front_bid()},\n\targs = {${}},\n\tlua = function(args)\n\t\t${cursor}\n\tend,\n})"
    },
    ["prnt"] = {
        type = "snippet",
        description = "print(...)",
        template = "print(${...})${cursor}"
    },
    ["prou"] = {
        type = "snippet",
        description = "print.out()",
        template = "print.out()${cursor}"
    },
    ["tabp"] = {
        type = "snippet",
        description = "table.deep_print(t)",
        template = "table.deep_print(${t})${cursor}"
    },
    ["funn"] = {
        type = "snippet",
        description = "function name(...) .. end",
        template = "function ${name}(${...})\n\t${cursor}\nend"
    },
    ["fori"] = {
        type = "snippet",
        description = "for i,v in ipairs(t) do .. end",
        template = "for i,v in ipairs(${t}) do\n\t${cursor}\nend"
    },
    ["forp"] = {
        type = "snippet",
        description = "for k,v in pairs(t) do .. end",
        template = "for k,v in pairs(${t}) do\n\t${cursor}\nend"
    },
    ["whit"] = {
        type = "snippet",
        description = "while (true) do .. end",
        template = "while (${true}) do\n\t${cursor}\nend"
    },
    ["whif"] = {
        type = "snippet",
        description = "while (false) do .. end",
        template = "while (${false}) do\n\t${cursor}\nend"
    },
    ["ife"] = {
        type = "snippet",
        description = "if .. then .. else .. end",
        template = "if (${true}) then\n\t${}\nelse\n\t${cursor}\nend"
    },
    ["if"] = {
        type = "snippet",
        description = "if (true) then .. end",
        template = "if (${true}) then\n\t${cursor}\nend"
    },
}
