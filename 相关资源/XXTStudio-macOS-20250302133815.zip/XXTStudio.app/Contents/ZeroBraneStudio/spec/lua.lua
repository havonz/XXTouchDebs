-- authors: Luxinia Dev (Eike Decker & Christoph Kubisch)
---------------------------------------------------------

local unpack = table.unpack or unpack
local funcdef = "([A-Za-z_][A-Za-z0-9_%.%:]*)%s*"
local decindent = {
  ['else'] = true, ['elseif'] = true, ['until'] = true, ['end'] = true}
local incindent = {
  ['else'] = true, ['elseif'] = true, ['for'] = true, ['do'] = true,
  ['if'] = true, ['repeat'] = true, ['while'] = true}
local function isfndef(str)
  local l
  local s,e,cap,par = string.find(str, "function%s+" .. funcdef .. "(%(.-%))")
  -- try to match without brackets now, but only at the beginning of the line
  if (not s) then
    s,e,cap = string.find(str, "^%s*function%s+" .. funcdef)
  end
  -- try to match "foo = function()"
  if (not s) then
    s,e,cap,par = string.find(str, funcdef .. "=%s*function%s*(%(.-%))")
  end
  if (s) then
    l = string.find(string.sub(str,1,s-1),"local%s+$")
    cap = cap .. " " .. (par or "(?)")
  end
  return s,e,cap,l
end
local q = EscapeMagic

local PARSE = require 'lua_parser_loose'
local LEX = require 'lua_lexer_loose'

local function ldoc(tx, typepatt)
  local varname = "([%w_]+)"
  -- <type> == ?string, ?|T1|T2
  -- anything that follows optional "|..." is ignored
  local typename = "%??"..typepatt
  -- @tparam[...] <type> <paramname>
  -- @param[type=<type>] <paramname>
  -- @string[...] <paramname>; not handled
  local t, v = tx:match("--%s*@tparam%b[]%s+"..typename.."%s+"..varname)
  if not t then -- try without optional [...] part
    t, v = tx:match("--%s*@tparam%s+"..typename.."%s+"..varname)
  end
  if not t then
    t, v = tx:match("--%s*@param%s*%[type="..typename.."%]%s+"..varname)
  end
  return t, v
end

return {
  exts = {"lua", "rockspec", "wlua"},
  lexer = wxstc.wxSTC_LEX_LUA,
  apitype = "lua",
  linecomment = "--",
  sep = ".:",
  isdecindent = function(str)
    str = (str
      :gsub('%[=*%[.-%]=*%]','') -- remove long strings
      :gsub("%b[]","") -- remove all table indexes
      :gsub('%[=*%[.*',''):gsub('.*%]=*%]','') -- remove partial long strings
      :gsub('%-%-.*','') -- strip comments after strings are processed
      :gsub("%b()","()") -- remove all function calls
    )
    -- this handles three different cases:
    local term = (str:match("^%s*([%w_]+)%s*$")
      or str:match("^%s*(elseif)[%s%(]")
      or str:match("^%s*(until)[%s%(]")
      or str:match("^%s*(else)%f[^%w_]")
    )
    -- (1) 'end', 'elseif', 'else', 'until'
    local match = term and decindent[term]
    -- (2) 'end)', 'end}', 'end,', and 'end;'
    if not term then term, match = str:match("^%s*(end)%s*([%)%}]*)%s*[,;]?") end
    -- endFoo could be captured as well; filter it out
    if term and str:match("^%s*(end)[%w_]") then term = nil end
    -- (3) '},', '};', '),' and ');'
    if not term then match = str:match("^%s*[%)%}]+%s*[,;]?%s*$") end

    return match and 1 or 0, match and term and 1 or 0
  end,
  isincindent = function(str)
    -- remove "long" comments and escaped slashes (to process \' and \" below)
    str = str:gsub('%-%-%[=*%[.-%]=*%]',' '):gsub('\\[\\\'"]','')
    while true do
      local num, sep = nil, str:match("['\"]")
      if not sep then break end
      str, num = str:gsub(sep..".-\\"..sep,sep):gsub(sep..".-"..sep," ")
      if num == 0 then break end
    end
    str = (str
      :gsub('%[=*%[.-%]=*%]',' ') -- remove long strings
      :gsub('%b[]',' ') -- remove all table indexes
      :gsub('%[=*%[.*',''):gsub('.*%]=*%]','') -- remove partial long strings
      :gsub('%-%-.*','') -- strip comments after strings are processed
      :gsub("%b()","()") -- remove all function calls
    )

    local func = (isfndef(str) or str:match("%f[%w_]function%s*%(")) and 1 or 0
    local term = str:match("^%s*([%w_]+)%W*")
    local terminc = term and incindent[term] and 1 or 0
    -- fix 'if' not terminated with 'then'
    -- or 'then' not started with 'if'
    if (term == 'if' or term == 'elseif') and not str:match("%f[%w_]then%f[^%w_]")
    or (term == 'for') and not str:match("%f[%w_]do%f[^%w_]")
    or (term == 'while') and not str:match("%f[%w_]do%f[^%w_]")
    -- or `repeat ... until` are on the same line
    or (term == 'repeat') and str:match("%f[%w_]until%f[^%w_]")
    -- if this is a function definition, then don't increment the level
    or func == 1 then
      terminc = 0
    elseif not (term == 'if' or term == 'elseif') and str:match("%f[%w_]then%f[^%w_]")
    or not (term == 'for') and str:match("%f[%w_]do%f[^%w_]")
    or not (term == 'while') and str:match("%f[%w_]do%f[^%w_]") then
      terminc = 1
    end
    local _, opened = str:gsub("([%{%(])", "%1")
    local _, closed = str:gsub("([%}%)])", "%1")
    -- ended should only be used to negate term and func effects
    local anon = str:match("%f[%w_]function%s*%(.+[^%w_]end%f[^%w_]")
    local ended = (terminc + func > 0) and (str:match("[^%w_]+end%s*$") or anon) and 1 or 0

    return opened - closed + func + terminc - ended
  end,
  marksymbols = function(code, pos, vars)
    local lx = LEX.lexc(code, nil, pos)
    return coroutine.wrap(function()
      local varnext = {}
      PARSE.parse_scope_resolve(lx, function(op, name, lineinfo, vars, nobreak)
        if not(op == 'Id' or op == 'Statement' or op == 'Var'
            or op == 'Function' or op == 'String'
            or op == 'VarNext' or op == 'VarInside' or op == 'VarSelf'
            or op == 'FunctionCall' or op == 'Scope' or op == 'EndScope') then
          return end -- "normal" return; not interested in other events

        -- level needs to be adjusted for VarInside as it comes into scope
        -- only after next block statement
        local at = vars[0] and (vars[0] + (op == 'VarInside' and 1 or 0))
        if op == 'Statement' then
          for _, token in pairs(varnext) do coroutine.yield(unpack(token)) end
          varnext = {}
        elseif op == 'VarNext' or op == 'VarInside' then
          table.insert(varnext, {'Var', name, lineinfo, vars, at, nobreak})
        end

        coroutine.yield(op, name, lineinfo, vars, op == 'Function' and at-1 or at, nobreak)
      end, vars)
    end)
  end,

  typeassigns = function(editor)
    local maxlines = 48 -- scan up to this many lines back
    local iscomment = editor.spec.iscomment
    local assigns = {}
    local endline = editor:GetCurrentLine()-1
    local line = math.max(endline-maxlines, 0)

    while (line <= endline) do
      local ls = editor:PositionFromLine(line)
      local tx = editor:GetLine(line) --= string
      local s = bit.band(editor:GetStyleAt(ls + #tx:match("^%s*") + 2),31)

      -- check for assignments
      local sep = editor.spec.sep
      local varname = "([%w_][%w_"..q(sep:sub(1,1)).."]*)"
      local identifier = "([%w_][%w_"..q(sep).."%s]*)"

      -- special hint
      local typ, var = tx:match("%s*%-%-=%s*"..varname.."%s+"..identifier)
      local ldoctype, ldocvar = ldoc(tx, varname)
      if var and typ then
        assigns[var] = typ:gsub("%s","")
      elseif ldoctype and ldocvar then
        assigns[ldocvar] = ldoctype
      elseif not iscomment[s] then
        -- real assignments
        local var,typ = tx:match("%s*"..identifier.."%s*=%s*([^;]+)")

        var = var and var:gsub("local",""):gsub("%s","")
        -- remove assert() calls as they don't affect their parameter types
        typ = typ and typ:gsub("assert%s*(%b())", function(s) return s:gsub("^%(",""):gsub("%)$","") end)
        -- handle `require` as a special case that returns a type that matches its parameter
        -- (this is without deeper analysis on loaded files and should work most of the time)
        local req = typ and typ:match("^require%s*%(?%s*['\"](.+)['\"]%s*%)?")
        typ = req or typ
        typ = (typ and typ
          :gsub("%b()","")
          :gsub("%b{}","")
          :gsub("%b[]",".0")
          -- replace concatenation with addition to avoid misidentifying types
          :gsub("%.%.+","+")
          -- remove comments; they may be in strings, but that's okay here
          :gsub("%-%-.*",""))
        if (typ and (typ:match(",") or typ:match("%sor%s") or typ:match("%sand%s"))) then
          typ = nil
        end
        typ = typ and typ:gsub("%s","")
        typ = typ and typ:gsub(".+", function(s)
            return (s:find("^'[^']*'$")
              or s:find('^"[^"]*"$')
              or s:find('^%[=*%[.*%]=*%]$')) and 'string' or s
          end)

        -- filter out everything that is not needed
        if typ and typ ~= 'string' -- special value for all strings
        and (not typ:match('^'..identifier..'$') -- not an identifier
          or typ:match('^%d') -- or a number
          or editor.api.tip.keys[typ] -- or a keyword
          ) then
          typ = nil
        end

        if (var and typ) then
          -- expand known types
          local tbl, rest = typ:match("^(.+)(["..sep.."][^"..sep.."]+)$")
          if tbl and assigns[tbl] then typ = assigns[tbl]..rest end

          if (assigns[typ] and not req) then
            assigns[var] = assigns[typ]
          else
            if req then assigns[req] = nil end
            assigns[var] = typ
          end
        end
      end
      line = line+1
    end

    return assigns
  end,

  lexerstyleconvert = {
    text = {wxstc.wxSTC_LUA_IDENTIFIER,},

    lexerdef = {wxstc.wxSTC_LUA_DEFAULT,},
    comment = {wxstc.wxSTC_LUA_COMMENT,
      wxstc.wxSTC_LUA_COMMENTLINE,
      wxstc.wxSTC_LUA_COMMENTDOC,},
    stringtxt = {wxstc.wxSTC_LUA_STRING,
      wxstc.wxSTC_LUA_CHARACTER,
      wxstc.wxSTC_LUA_LITERALSTRING,},
    stringeol = {wxstc.wxSTC_LUA_STRINGEOL,},
    preprocessor= {wxstc.wxSTC_LUA_PREPROCESSOR,},
    operator = {wxstc.wxSTC_LUA_OPERATOR,},
    number = {wxstc.wxSTC_LUA_NUMBER,},

    keywords0 = {wxstc.wxSTC_LUA_WORD,},
    keywords1 = {wxstc.wxSTC_LUA_WORD2,},
    keywords2 = {wxstc.wxSTC_LUA_WORD3,},
    keywords3 = {wxstc.wxSTC_LUA_WORD4,},
    keywords4 = {wxstc.wxSTC_LUA_WORD5,},
    keywords5 = {wxstc.wxSTC_LUA_WORD6,},
    keywords6 = {wxstc.wxSTC_LUA_WORD7,},
    keywords7 = {wxstc.wxSTC_LUA_WORD8,},
  },

  keywords = {
    -- keywords
    [[and break do else elseif end for function goto if in local not or repeat return then until while]],

    -- constants/variables
    [[_G _VERSION _ENV false io.stderr io.stdin io.stdout nil math.huge math.pi self true package.cpath package.path]],

    -- core/global functions
    [[assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring
      module next pairs pcall print rawequal rawget rawlen rawset require
      select setfenv setmetatable tonumber tostring type unpack xpcall]],

    -- library functions
    [[bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract
      bit32.lrotate bit32.lshift bit32.replace bit32.rrotate bit32.rshift
      coroutine.create coroutine.resume coroutine.running coroutine.status coroutine.wrap coroutine.yield
      coroutine.isyieldable
      debug.debug debug.getfenv debug.gethook debug.getinfo debug.getlocal
      debug.getmetatable debug.getregistry debug.getupvalue debug.getuservalue debug.setfenv
      debug.sethook debug.setlocal debug.setmetatable debug.setupvalue debug.setuservalue
      debug.traceback debug.upvalueid debug.upvaluejoin
      io.close io.flush io.input io.lines io.open io.output io.popen io.read io.tmpfile io.type io.write
      close flush lines read seek setvbuf write
      math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.cosh math.deg math.exp
      math.floor math.fmod math.frexp math.ldexp math.log math.log10 math.max math.min math.modf
      math.pow math.rad math.random math.randomseed math.sin math.sinh math.sqrt math.tan math.tanh
      math.type math.tointeger math.maxinteger math.mininteger math.ult
      os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname
      package.loadlib package.searchpath package.seeall package.config
      package.loaded package.loaders package.preload package.searchers
      string.byte string.char string.dump string.find string.format string.gmatch string.gsub string.len
      string.lower string.match string.rep string.reverse string.sub string.upper
      byte find format gmatch gsub len lower match rep reverse sub upper
      table.move string.pack string.unpack string.packsize
      table.concat table.insert table.maxn table.pack table.remove table.sort table.unpack]]..[[
  bit32 coroutine debug io math os package string table
  os.restart
  screen.init screen.rotate_xy screen.unrotate_xy screen.init_home_on_bottom screen.init_home_on_right screen.init_home_on_left screen.init_home_on_top screen.size screen.keep screen.unkeep screen.is_kept screen.get_color screen.get_color_rgb
  screen.is_colors screen.find_color screen.find_color screen.find_color screen.find_color screen.image screen.ocr_text screen.find_image 
  touch.tap touch.on touch.move touch.off move press off msleep step_len step_delay delay touch.show_pose msleep
  key.press key.down key.up key.send_text
  accelerometer.simulate accelerometer.shake accelerometer.rotate_home_on_left accelerometer.rotate_home_on_right accelerometer.rotate_home_on_top accelerometer.rotate_home_on_bottom
  sys.toast sys.alert sys.input_box sys.input_text sys.msleep sys.sleep sys.time_of_day sys.net_time sys.mtime sys.rnd sys.memory_info sys.available_memory sys.free_disk_space sys.log sys.version sys.xtversion
  sys.mgcopyanswer sys.MGCopyAnswer
  pasteboard.write pasteboard.read
  clear.memory clear.keychain clear.all_keychain clear.pasteboard clear.cookies clear.caches clear.all_photos clear.idfav clear.app_data
  app.bundle_path app.data_path app.run app.close app.quit app.is_running app.input_text app.localized_name app.png_data_for_bid app.pid_for_bid app.used_memory app.front_bid app.front_pid app.open_url
  app.bundles app.all_procs app.set_speed_add app.install app.uninstall app.group_info app.pop_banner
  device.reset_idle device.lock_screen device.unlock_screen device.is_screen_locked device.front_orien device.lock_orien device.unlock_orien device.is_orien_locked device.vibrator device.play_sound
  device.type device.name device.set_name device.udid device.serial_number device.wifi_mac device.ifaddrs device.battery_level device.battery_state device.turn_on_wifi device.turn_off_wifi device.turn_on_data
  device.turn_off_data device.turn_on_bluetooth device.turn_off_bluetooth device.turn_on_airplane device.turn_off_airplane device.turn_on_vpn device.turn_off_vpn device.is_vpn_on device.flash_on device.flash_off device.reduce_motion_on
  device.reduce_motion_off device.brightness device.set_brightness device.set_autolock_time device.set_volume device.change_resolution device.reset_resolution device.join_wifi device.assistive_touch_on device.assistive_touch_off 
  image.is image.new image.oper_merge image.new_text_image image.load_file image.load_data copy crop save_to_album save_to_png_file save_to_jpeg_file png_data qr_scan jpeg_data turn_left turn_right turn_upondown size get_color set_color replace_color draw_image binaryzation find_color is_colors qr_decode destroy dm_ocr dm_find_str cv_find_image cv_binaryzation cv_resize tess_ocr
  proc_put proc_get proc_queue_push proc_queue_pop proc_queue_clear proc_queue_size proc_queue_push_front proc_queue_push_back proc_queue_pop_front proc_queue_pop_back
  thread.dispatch thread.current_id thread.kill thread.timer_start thread.timer_stop thread.wait thread.register_event thread.unregister_event
  webview.show webview.hide webview.destroy webview.frame webview.eval
  matrix_dict.new matrix_dict.load_file matrix_dict.load_string copy add_with_file add_with_string add_with_dict remove
  table.deep_copy table.deep_print table.deep_dump table.load_string
  file.exists file.list file.size file.reads file.writes file.appends file.line_count file.remove_line file.get_line file.get_lines file.set_line file.set_lines file.insert_line file.insert_lines file.md5 file.sha1
  string.to_hex string.from_hex string.from_gbk string.md5 string.sha1 string.base64_encode string.base64_decode string.aes128_encrypt string.aes128_decrypt string.split string.ltrim string.rtrim string.trim string.atrim string.random string.strip_utf8_bom
  to_hex from_hex from_gbk md5 sha1 base64_encode base64_decode aes128_encrypt aes128_decrypt split ltrim rtrim trim atrim random strip_utf8_bom
  http.get http.post http.head http.delete http.put http.download httpGet httpPost 
  ftp.download ftp.upload 
  json.encode json.decode json.null 
  plist.read plist.write 
  utils.add_contacts utils.remove_all_contacts utils.open_code_scanner utils.close_code_scanner utils.qr_encode utils.launch_args utils.is_launch_via_app utils.video_to_album 
  nLog print.out dialog config timeout title add_label add_input add_picker add_switch add_checkbox add_image add_range add_radio show set_config set_timeout set_title set_size set_frame set_corner_radius 
  vpnconf.create vpnconf.list vpnconf.select vpnconf.delete vpnconf.connect vpnconf.disconnect vpnconf.status 
  xpp.info xpp.resource_path xpp.bundle_path xpp.ui_setup xpp.show_ui 
  gps.fake gps.clear 
  screen touch key accelerometer sys pasteboard clear app device image thread webview http ftp json plist utils vpnconf xpp xui 
  ]]
  },
}
