#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
: "${GOTRACEBACK:=crash}"
# To enable GC trace (uncomment the next line):
# : "${GODEBUG:=gctrace=1}"
arch="$(uname -m)"
case "$arch" in
  x86_64|amd64) BIN="./XXTLanControl-backend-linux-amd64" ;;
  aarch64|arm64) BIN="./XXTLanControl-backend-linux-arm64" ;;
  *) BIN="./XXTLanControl-backend-linux-amd64" ;;
esac
LOG="logs/backend-$(date +%F).log"
echo "Version: v202511271129 (commit 56a0b78)"
echo "Starting $BIN, logging to $LOG"
"$BIN" 2>&1 | tee -a "$LOG"
