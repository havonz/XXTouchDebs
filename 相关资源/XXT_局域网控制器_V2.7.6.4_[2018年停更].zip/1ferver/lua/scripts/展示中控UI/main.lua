local CC = require('CC')
if not CC.connect() then
	error('连接失败')
end

-- 必须由中控启动

args = proc_take('CC_args')
local args = json.decode(args)

local Edit = args["输入框"]

local ComboBox = args["下拉框"]
local ComboBox_t = {"1", "2", "3", "4", "5", "6", "7"}	-- 与中控端内容保持一致


local RadioGroup = args["单选框"]
local RadioGroup_t = {"111", "222", "333", "444", "555", "666"}	-- 与中控端内容保持一致


local CheckBoxGroup = args["多选框"]
local CheckBoxGroup_t = {"aaa", "bbb", "ccc", "ddd", "eee"}	-- 与中控端内容保持一致

local get_checkbox = function(_tab, _tab_val)
	local _ret = {}
	for _, item in ipairs(_tab) do
		table.insert(_ret, _tab_val[item])
	end
	return _ret
end

if Edit and ComboBox and RadioGroup and CheckBoxGroup then	-- 判断是否传入值
	sys.alert(
		"输入框：" .. Edit
	)
	sys.alert(
		"下拉框：" .. ComboBox_t[ComboBox]
	)
	sys.alert(
		"单选框：" .. RadioGroup_t[RadioGroup]
	)
	sys.alert(
		"多选框：" .. table.concat(
			get_checkbox(CheckBoxGroup, CheckBoxGroup_t),
			", "
		)
	)
else
	CC.log("未传入有效内容")
end




