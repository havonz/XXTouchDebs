return {	name = "Lua 5.3 函数",
	{	name = "assert",
		title = "断言",
		description = [[声明
	ret, ... = assert(v[, message])

参数及返回值
	v, message 
		任意类型 
			如果这个值为 nil 或 false，则会调用 error 错误信息为 message
			否则，assert 将返回所有的参数

说明
	如果其参数 v 的值为假（nil 或 false）， 它就调用 error； 否则，返回所有的参数。 在错误情况时， message 指那个错误对象； 如果不提供这个参数，参数默认为 "assertion failed!" 。

示例 
假设 /var/mobile/Media/1ferver/lua/scripts/test.txt 的内容为：
Hello XXTouch
执行：
local f = assert(io.open("/var/mobile/Media/1ferver/lua/scripts/test.txt", "r"))
sys.toast(f:read("*a"))
f:close()
将输出：
Hello XXTouch
假设 /var/mobile/Media/1ferver/lua/scripts/test.txt 文件不存在将输出：
并抛出一个错误：
...: 1: /var/mobile/Media/1ferver/lua/scripts/test.txt: No such file or directory]],
		pos = 1
	},
	{	name = "collectgarbage",
		title = "垃圾收集器通用接口",
		description = [==[声明
	collectgarbage([opt[, arg]])

参数及返回值
	opt, arg 
		文本型，通过这个参数提供了一组不同的功能 
			"collect": 做一次完整的垃圾收集循环。 这是默认选项。
			"stop": 停止垃圾收集器的运行。 在调用重启前，收集器只会因显式的调用运行。
			"restart": 重启垃圾收集器的自动运行。
			"count": 以 K 字节数为单位返回 Lua 使用的总内存数。 这个值有小数部分，所以只需要乘上 1024 就能得到 Lua 使用的准确字节数（除非溢出）。
			"step": 单步运行垃圾收集器。 步长“大小”由 arg 控制。 传入 0 时，收集器步进（不可分割的）一步。 传入非 0 值， 收集器收集相当于 Lua 分配这些多（K 字节）内存的工作。 如果收集器结束一个循环将返回 true 。
			"setpause": 将 arg 设为收集器的 间歇率。 返回 间歇率 的前一个值。
			"setstepmul": 将 arg 设为收集器的 步进倍率。 返回 步进倍率 的前一个值。
			"isrunning": 返回表示收集器是否在工作的布尔值 （即未被停止）。

说明
	这个函数是垃圾收集器的通用接口

示例
collectgarbage("collect")]==],
		pos = 1
	},
	{	name = "dofile",
		title = "执行一个文件",
		description = [[声明
	ret, ... = dofile([filename])

参数及返回值
	filename 
		文本型，需要执行的文件名
	ret, ... 
		返回该文件中代码块的所有返回值

说明
	打开该名字的文件，并执行文件中的 Lua 代码块。 不带参数调用时， dofile 执行标准输入的内容（stdin）。 返回该代码块的所有返回值。 对于有错误的情况，dofile 将错误反馈给调用者 （即，dofile 没有运行在保护模式下）。

示例 
假设 /var/mobile/Media/1ferver/lua/scripts/test.lua 的内容为：
return "Hello dofile"
执行：
h = dofile("/var/mobile/Media/1ferver/lua/scripts/test.lua")
print(h)
将输出：
Hello dofile]],
		pos = 1
	},
	{	name = "error",
		title = "抛出错误信息",
		description = [[声明
	error(message[, level])

参数及返回值
	message 
		文本型，错误信息
	level 
		整数型，可选参数，错误抛出的层，默认为 1

说明
	中止上一次保护函数调用， 将错误对象 message 返回。 函数 error 永远不会返回。 
	当 message 是一个字符串时，通常 error 会把一些有关出错位置的信息附加在消息的前头。 level 参数指明了怎样获得出错位置。 对于 level 1 （默认值），出错位置指 error 函数调用的位置。 Level 2 将出错位置指向调用 error的函数的函数；以此类推。 传入 level 0 可以避免在消息前添加出错位置信息。

示例
error("呵呵")
将输出：
并抛出一个错误：
...: 1: 呵呵]],
		pos = 1
	},
	{	name = "getmetatable",
		title = "获取对象的元表",
		description = [[声明
	mt = getmetatable(object)

参数及返回值
	object 
		对象，类型可以是 table、userdata
	mt 
		表型 | nil，如果 object 不包含元表，返回 nil，否则返回对象的元表

说明
	如果 object 不包含元表，返回 nil 。 否则，如果在该对象的元表中有 "__metatable" 域时返回其关联值， 没有时返回该对象的元表。

示例
mt = getmetatable("") -- 获得字符串的元表
print(mt.__index.sub("XXTouch", 3, 5))
将输出：
Tou]],
		pos = 1
	},
	{	name = "ipairs",
		title = "顺序迭代器",
		description = [[声明
	it, t, 0 = ipairs(t)

参数及返回值
	t（参数） 
		表型，需要迭代的表
	it 
		函数型，返回一个迭代函数
	t（返回值） 
		表型，这个表原封不动返回参数 t
	0 
		常量 0（零） 不用多说吧？

说明
	返回三个值（迭代函数、表 t 以及 0 ）， 如此，以下代码 
	for i,v in ipairs(t) do ... end 
	将迭代键值对（1,t[1]) ，(2,t[2])， ... ，直到第一个空值。

示例
for i,v in ipairs({5, 7, 8}) do
	print(i, v)
end
将输出：
1	5
2	7
3	8]],
		pos = 1
	},
	{	name = "load",
		title = "加载一个代码块",
		description = [==[声明
	func, err = load(chunk[, chunkname[, mode[, env]]])

参数及返回值
	chunk 
		字符串型，需要加载的代码块
	chunkname 
		字符串型，可选参数，代码块的名字，默认为第一个参数 chunk
	mode 
		"b" 
			只能是二进制代码块模式
		"t" 
			只能是文本代码块模式
		"bt" 
			可以是二进制也可以是文本模式
	env 
		表型，如果结果函数有上值，env 被设为第一个上值。若不提供此参数，将全局环境替代它。
	func, err 
		函数型 | nil，如果代码块没有语法错误，则以函数形式返回编译好的代码块；否则，返回 nil 加上错误消息

说明
	加载一个代码块。
	如果 chunk 是一个字符串，代码块指这个字符串。 如果 chunk 是一个函数， load 不断地调用它获取代码块的片断。 每次对 chunk 的调用都必须返回一个字符串紧紧连接在上次调用的返回串之后。 当返回空串、nil、或是不返回值时，都表示代码块结束。
	如果没有语法错误， 则以函数形式返回编译好的代码块； 否则，返回 nil 加上错误消息。
	如果结果函数有上值， env 被设为第一个上值。 若不提供此参数，将全局环境替代它。 所有其它上值初始化为 nil。 （当你加载主代码块时候，结果函数一定有且仅有一个上值 _ENV ）。 然而，如果你加载一个用函数（参见 string.dump， 结果函数可以有任意数量的上值） 创建出来的二进制代码块时，所有的上值都是新创建出来的。 也就是说它们不会和别的任何函数共享。
	chunkname 在错误消息和调试消息中，用于代码块的名字。 如果不提供此参数，它默认为字符串chunk 。 chunk 不是字符串时，则为 "=(load)" 。
	字符串 mode 用于控制代码块是文本还是二进制（即预编译代码块）。 它可以是字符串 "b" （只能是二进制代码块）， "t" （只能是文本代码块）， 或 "bt" （可以是二进制也可以是文本）。 默认值为 "bt"。
	Lua 不会对二进制代码块做健壮性检查。 恶意构造一个二进制块有可能把解释器弄崩溃。

示例
f = load("print('XXTouch')")
print('Hello')
f()
将输出：
Hello
XXTouch
]==],
		pos = 1
	},
	{	name = "loadfile",
		title = "加载一个文件中的代码块",
		description = [==[声明
	func, err = loadfile([filename[, mode[, env]]])

参数及返回值
	filename 
		字符串型，需要加载的代码块所属的文件的文件名
	mode 
		"b" 
			只能是二进制代码块模式
		"t" 
			只能是文本代码块模式
		"bt" 
			可以是二进制也可以是文本模式
	env 
		表型，如果结果函数有上值，env 被设为第一个上值。若不提供此参数，将全局环境替代它。
	func, err 
		函数型 | nil，如果文件中代码块没有语法错误，则以函数形式返回编译好的代码块；否则，返回 nil 加上错误消息

说明
	和 load 类似， 不过是从文件 filename 或标准输入（如果文件名未提供）中获取代码块。

示例 
假设 /var/mobile/Media/1ferver/lua/scripts/test.lua 的内容为：
print('XXTouch')
return "Hello again"
执行：
f = loadfile("/var/mobile/Media/1ferver/lua/scripts/test.lua")
print('Hello')
print(f())
将输出：
Hello
XXTouch
Hello again]==],
		pos = 1
	},
	{	name = "next",
		title = "获取表中的下一个域 ",
		description = [[声明
	idx, value = next(t[, index])

参数及返回值
	t 
		表型，需要操作的表
	index 
		任意类型，可选参数，当前域的键，默认为 nil
	idx, value 
		任意类型 | nil，返回 index 键的下一个键 idx 及其关联的值，如果没有下一个键，返回 nil

说明
	运行程序来遍历表中的所有域。 第一个参数是要遍历的表，第二个参数是表中的某个键。 next 返回该键的下一个键及其关联的值。 如果用 nil 作为第二个参数调用 next 将返回初始键及其关联值。 当以最后一个键去调用，或是以 nil 调用一张空表时， next 返回 nil。 如果不提供第二个参数，将认为它就是 nil。 特别指出，你可以用 next(t) 来判断一张表是否是空的。
	索引在遍历过程中的次序无定义， 即使是数字索引也是这样。 （如果想按数字次序遍历表，可以使用数字形式的 for 。）
	当在遍历过程中你给表中并不存在的域赋值， next 的行为是未定义的。 然而你可以去修改那些已存在的域。 特别指出，你可以清除一些已存在的域。

示例
local t = {
	a = 1,
	b = 2,
	c = 3,
}
local k, v = nil, nil
for k, v in next, t, k do
	print(k, v)
end
可能的输出：
c	3
a	1
b	2]],
		pos = 1
	},
	{	name = "pairs",
		title = "哈希迭代器",
		description = [[声明
	next, idx, value = pairs(t[, index])

参数及返回值
	t 
		表型，需要遍历的表
	next 
		函数型，t 的 __pairs 元方法或者 next 函数
	idx, value 
		任意类型 | nil，返回 index 键的下一个键 idx 及其关联的值，如果没有下一个键，返回 nil

说明
	如果 t 有元方法 __pairs， 以 t 为参数调用它，并返回其返回的前三个值。
	否则，返回三个值：next 函数， 表 t，以及 nil。 因此以下代码
	for k,v in pairs(t) do body end 
	能迭代表 t 中的所有键值对。
	参见函数 next 中关于迭代过程中修改表的风险。

示例
t = {
	a = 1,
	b = 2,
	c = 3,
}
for k, v in pairs(t) do
	print(k, v)
end
可能的输出：
c	3
a	1
b	2]],
		pos = 1
	},
	{	name = "pcall",
		title = "保护模式调用函数",
		description = [[声明
	noerr, ... = pcall(f[, arg1, ···])

参数及返回值
	f 
		函数型，需要以保护模式调用的函数
	arg1, ... 
		任意类型，传给 f 的参数们
	noerr, ... 
		布尔型, ...，如果 f 的调用没有发生运行期错误，则返回 true 并附带 f 的返回值，否则返回 false 附带错误信息

说明
	传入参数，以 保护模式 调用函数 f 。 这意味着 f 中的任何错误不会抛出； 取而代之的是，pcall 会将错误捕获到，并返回一个状态码。 第一个返回值是状态码（一个布尔量）， 当没有错误时，其为真。 此时，pcall 同样会在状态码后返回所有调用的结果。 在有错误时，pcall 返回 false 加错误消息。

示例
function has_a_err(arg1, arg2)
	print(arg1)
	arg1 = nil + arg1
	print(arg2)
end
print(pcall(has_a_err, "XXT", "Terrible"))
将输出：
XXT
false	[string ""]:3: attempt to perform arithmetic on a nil value]],
		pos = 1
	},
	{	name = "print",
		title = "打印输出",
		description = [[声明
	print(···)

参数及返回值
	... 
		任意类型，接收任意数量的参数

说明
	接收任意数量的参数，并将它们的值打印到 stdout。 它用 tostring 函数将每个参数都转换为字符串。 print 不用于做格式化输出。仅作为看一下某个值的快捷方式。 多用于调试。 完整的对输出的控制，请使用 string.format 以及 io.write。

示例
print("Hello XXT")
将输出：
Hello XXT]],
		pos = 1
	},
	{	name = "rawequal",
		title = "原等于比较",
		description = [[声明
	b = rawequal(v1, v2)

参数及返回值
	v1, v2 
		任意类型，需要判断是否相等的两个值
	b 
		布尔型，如果 v1 原等于 v2，返回 true，否则返回 false

说明
	在不触发任何元方法的情况下 检查 v1 是否和 v2 相等。

示例
mt = {
	__eq = function(self, v)
		return true
	end
}
t1 = {}
t2 = {}
setmetatable(t1, mt)
setmetatable(t2, mt)
print(t1==t2)
print(rawequal(t1, t2))
将输出：
true
false]],
		pos = 1
	},
	{	name = "rawget",
		title = "原索引表",
		description = [[声明
	value = rawget(tab, index)

参数及返回值
	tab 
		表型，一张表
	index 
		任意类型，索引
	value 
		任意类型，索引到的值

说明
	在不触发任何元方法的情况下 获取 tab[index] 的值。 tab 必须是一张表； index 可以是任何值。

示例
t = {
	a = 3,
	b = 7,
}
mt = {
	__index = function(self, key)
		return "XXTouch "..key
	end
}
setmetatable(t, mt)
print(t["c"])
print(t["d"])
print(rawget(t, "c"))
print(rawget(t, "d"))
print(rawget(t, "b"))
print(rawget(t, "a"))
将输出：
XXTouch c
XXTouch d
nil
nil
7
3
]],
		pos = 1
	},
	{	name = "rawlen",
		title = "原获取长度 ",
		description = [[声明
	len = rawlen(object)

参数及返回值
	object 
		对象，类型可以是 string、table
	len 
		整数型，返回对象的长度信息

说明
	在不触发任何元方法的情况下 返回对象 v 的长度。 v 可以是表或字符串。

示例
t = {1, "XXTouch", 2, 3}
mt = {
	__len = function(self)
		return 9999999
	end
}
setmetatable(t, mt)
print(#t)
print(rawlen(t))
将输出：
9999999
4]],
		pos = 1
	},
	{	name = "rawset",
		title = "原设置表键值",
		description = [[声明
	rawset(tab, index, value)

参数及返回值
	tab 
		表型，需要设置值的表
	index 
		任意类型，键，不能是 nil 或 NaN
	value 
		任意类型，需要设置的值

说明
	在不触发任何元方法的情况下 将 tab[index] 设为 value。 tab 必须是一张表， index 可以是 nil 与 NaN 之外的任何值。 value 可以是任何 Lua 值。

示例
t = {}
mt = {
	__newindex = function(self, key, value)
		print("XXTouch deny")
	end
}
setmetatable(t, mt)
t.a = 1
print(t.a)
rawset(t, "a", 2)
print(t.a)
将输出：
XXTouch deny
nil
2]],
		pos = 1
	},
	{	name = "select",
		title = "选择参数",
		description = [[声明
	arg1, ... = select(index, ···)

参数及返回值
	index 
		整数型 | "#"，参数索引
	arg1, ... 
		整数型 | 任意类型, ...，如果 index 为 "#" 则返回参数个数，否则返回从 index 个参数开始的所有参数

说明
	如果 index 是个数字， 那么返回参数中第 index 个之后的部分； 负的数字会从后向前索引（-1 指最后一个参数）。 否则，index 必须是字符串 "#"， 此时 select 返回参数的个数。

示例
function var_args(...)
	print("有 "..select("#", ...).." 个参数")
	print(select(2, ...))
end
var_args("XXTouch", 1, 2, 3, 4)
var_args(1, "XXTouch", 2, 3)
将输出：
有 5 个参数
1	2	3	4
有 4 个参数
XXTouch 2	3]],
		pos = 1
	},
	{	name = "setmetatable",
		title = "设置表的元表",
		description = [[声明
	tab = setmetatable(tab, metatable)

参数及返回值
	tab 
		表型，需要设置元表的表
	metatable 
		表型，元表

说明
	给指定表设置元表。 （你不能在 Lua 中改变其它类型值的元表，那些只能在 C 里做。） 如果 metatable 是 nil， 将指定表的元表移除。 如果原来那张元表有 "__metatable" 域，抛出一个错误。
	这个函数返回 tab。

示例
mt = {
	awesome = function(self)
		print("Hello!")
		print(self.hello)
	end
}
mt.__index = mt
xxt = {}
xxt.hello = "XXTouch Awesome!"
setmetatable(xxt, mt)
xxt:awesome()
将输出：
Hello!
XXTouch Awesome!]],
		pos = 1
	},
	{	name = "tonumber",
		title = "转换值为数字",
		description = [[声明
	n = tonumber(e[, base])

参数及返回值
	e 
		文本型 | 实数型，需要转换为数字的值
	base 
		整数型，进制
	n 
		实数型 | nil，转换成功返回数字，否则返回 nil

说明
	如果调用的时候没有 base， tonumber 尝试把参数转换为一个数字。 如果参数已经是一个数字，或是一个可以转换为数字的字符串， tonumber 就返回这个数字； 否则返回 nil。
	字符串的转换结果可能是整数也可能是浮点数， 这取决于 Lua 的转换文法。 （字符串可以有前置和后置的空格，可以带符号。）
	当传入 base 调用它时， e 必须是一个以该进制表示的整数字符串。 进制可以是 2 到 36 （包含 2 和 36）之间的任何整数。 大于 10 进制时，字母 'A' （大小写均可）表示 10 ， 'B' 表示 11，依次到 'Z' 表示 35 。 如果字符串 e 不是该进制下的合法数字， 函数返回 nil。

示例
print(tonumber("not a number"))
print(tonumber(" 12444 "))
print(tonumber("ff", 16))
将输出：
nil
12444
255]],
		pos = 1
	},
	{	name = "tostring",
		title = "转换值为字符串",
		description = [[声明
	s = tostring(v)

参数及返回值
	v 
		任意类型，需要转换为字符串的值
	s 
		字符串型，转换后的字符串值

说明
	可以接收任何类型，它将其转换为人可阅读的字符串形式。 浮点数总被转换为浮点数的表现形式（小数点形式或是指数形式）。 （如果想完全控制数字如何被转换，可以使用 string.format。） 
	如果 v 有 "__tostring" 域的元表， tostring 会以 v 为参数调用它。 并用它的结果作为返回值。

示例
print(tostring(nil))
print(tostring(true))
print(tostring(1*1.0))
将输出：
nil
true
1.0]],
		pos = 1
	},
	{	name = "type",
		title = "获取值类型",
		description = [[声明
y = type(v)

参数及返回值
	v 
		任意类型，需要转换为字符串的值
	y 
		"nil": 表示值为 nil 
		"number": 表示值为数字型 
		"string": 表示值为字符串型 
		"boolean": 表示值为布尔型 
		"table": 表示值为表型 
		"function": 表示值为函数型 
		"thread": 表示值为 thread 型 
		"userdata": 表示值为 userdata 型

说明
	将参数的类型编码为一个字符串返回

示例
print(type(nil))
print(type(true))
print(type(1*1.0))
将输出：
nil
boolean
number]],
		pos = 1
	},
	{	name = "xpcall",
		title = "保护模式调用函数",
		description = [[声明
	noerr = xpcall(f, msgh[, arg1, ···])

参数及返回值
	f 
		函数型，需要以保护模式调用的函数
	msgh 
		函数型，错误回调函数，当函数 f 调用发生错误的时候错误信息会当作第一个参数调用这个函数
	arg1, ... 
		任意类型，传给 f 的参数们
	noerr 
		布尔型，如果 f 的调用没有发生运行期错误，则返回 true 并附带 f 的返回值，否则返回 false

说明
	这个函数和 pcall 类似。 不过它可以额外设置一个消息处理器 msgh。

示例
function has_a_err(arg1, arg2)
	print(arg1)
	arg1 = nil + arg1
	print(arg2)
end
function msgh(err)
	print(err)
end
print(xpcall(has_a_err, msgh, "XXT", "Terrible"))
将输出：
XXT
[string ""]:3: attempt to perform arithmetic on a nil value
false	nil]],
		pos = 1
	},
	{	name = "模块库",
		{	name = "require",
			title = "引入一个模块",
			description = [[声明
	ret, ... = require(modname)

参数及返回值
	modname 
		文本型，模块名
	ret, ... 
		任意类型，返回模块返回值

说明
	require 调用返回之前，不允许让出
	加载一个模块。 这个函数首先查找 package.loaded 表， 检测 modname 是否被加载过。 如果被加载过，require 返回 package.loaded[modname] 中保存的值。 否则，它试着为模块寻找 加载器 。
	require 遵循 package.searchers 序列的指引来查找加载器。 如果改变这个序列，我们可以改变 require 如何查找一个模块。 下列
	说明基于 package.searchers 的默认配置。
	首先 require 查找 package.preload[modname] 。 如果这里有一个值，这个值（必须是一个函数）就是那个加载器。 否则 require 使用 Lua 加载器去查找 package.path 的路径。 如果查找失败，接着使用 C 加载器去查找 package.cpath 的路径。 如果都失败了，再尝试 一体化 加载器 （参见 package.searchers）。
	每次找到一个加载器，require 都用两个参数调用加载器： modname 和一个在获取加载器过程中得到的参数。 （如果通过查找文件得到的加载器，这个额外参数是文件名。） 如果加载器返回非空值， require 将这个值赋给 package.loaded[modname]。 如果加载器没能返回一个非空值用于赋给 package.loaded[modname]， require 会在那里设入 true 。 无论是什么情况，require 都会返回 package.loaded[modname] 的最终值。
	如果在加载或运行模块时有错误， 或是无法为模块找到加载器， require 都会抛出错误。

示例 
假设 /var/mobile/Media/1ferver/lua/scripts/test.lua 的内容为：
print('XXTouch')
return "Hello again"
执行：
package.path = package.path..";/var/mobile/Media/1ferver/lua/scripts/"
print(require("test"))
print(require("test"))
将输出：
XXTouch
Hello again
Hello again]],
			pos = 1
		},
		{	name = "package.config",
			title = "一个描述有一些为包管理准备的编译期配置信息的串",
			description = [==[一个描述有一些为包管理准备的编译期配置信息的串。 这个字符串由一系列行构成：
	第一行是目录分割串。 对于 Windows 默认是 '\' ，对于其它系统是 '/' 。
	第二行是用于路径中的分割符。默认值是 ';' 。
	第三行是用于标记模板替换点的字符串。 默认是 '?' 。
	第四行是在 Windows 中将被替换成执行程序所在目录的路径的字符串。 默认是 '!' 。
	第五行是一个记号，该记号之后的所有文本将在构建 luaopen_ 函数名时被忽略掉。 默认是 '-'。]==],
			package = "",
		},
		{	name = "package.cpath",
			title = "C 加载器搜索路径",
			description = [==[这个路径被 require 在 C 加载器中做搜索时用到。
Lua 用和初始化 Lua 路径 package.path 相同的方式初始化 C 路径 package.cpath 。 它会使用环境变量 LUA_CPATH_5_3 或 环境变量 LUA_CPATH 初始化。 要么就采用 luaconf.h 中定义的默认路径。]==],
			package = "",
		},
		{	name = "package.loaded",
			title = "控制已经被加载的表",
			description = [==[用于 require 控制哪些模块已经被加载的表。 当你请求一个 modname 模块，且 package.loaded[modname] 不为假时， require 简单返回储存在内的值。
这个变量仅仅是对真正那张表的引用； 改变这个值并不会改变 require 使用的表。]==],
			pos = 1
		},
		{	name = "package.loadlib",
			title = "动态链接 C 库",
			description = [[声明
	func = package.loadlib(libname, funcname)

参数及返回值
	libname 
		文本型，C 库的绝对路径
	funcname 
		文本型，C 函数名
	func 
		函数型，返回一个可以调用的函数

说明
	让宿主程序动态链接 C 库 libname 。
	当 funcname 为 "*"， 它仅仅连接该库，让库中的符号都导出给其它动态链接库使用。 否则，它查找库中的函数 funcname ，以 C 函数的形式返回这个函数。 因此，funcname 必须遵循原型 lua_CFunction 。
	这是一个低阶函数。 它完全绕过了包模块系统。 和 require 不同， 它不会做任何路径查询，也不会自动加扩展名。 libname 必须是一个 C 库需要的完整的文件名，如果有必要，需要提供路径和扩展名。 funcname 必须是 C 库需要的准确名字 （这取决于使用的 C 编译器和链接器）。
	这个函数在标准 C 中不支持。 因此，它只在部分平台有效 （ Windows ，Linux ，Mac OS X, Solaris, BSD, 加上支持 dlfcn 标准的 Unix 系统）。

示例
local cjson_func = package.loadlib("/var/mobile/Media/1ferver/lib/cjson.so","luaopen_cjson")
local cjson = cjson_func()
将输出：
]],
			pos = 1
		},
		{	name = "package.path",
			title = "Lua 加载器搜索路径",
			description = [==[这个路径被 require 在 Lua 加载器中做搜索时用到。
在启动时，Lua 用环境变量 LUA_PATH_5_3 或环境变量 LUA_PATH 来初始化这个变量。 或采用 luaconf.h 中的默认路径。 环境变量中出现的所有 ";;" 都会被替换成默认路径。]==],
			package = "",
		},
		{	name = "package.preload",
			title = "特殊模块的加载器",
			description = [==[保存有一些特殊模块的加载器 （参见 require）。
这个变量仅仅是对真正那张表的引用； 改变这个值并不会改变 require 使用的表。]==],
			pos = 1
		},
		{	name = "package.searchers",
			title = "控制如何加载模块的表",
			description = [==[用于 require 控制如何加载模块的表。

这张表内的每一项都是一个 查找器函数。 当查找一个模块时， require 按次序调用这些查找器， 并传入模块名（require 的参数）作为唯一的一个参数。 此函数可以返回另一个函数（模块的 加载器）加上另一个将传递给这个加载器的参数。 或是返回一个描述为何没有找到这个模块的字符串 （或是返回 nil 什么也不想说）。

Lua 用四个查找器函数初始化这张表。

第一个查找器就是简单的在 package.preload 表中查找加载器。

第二个查找器用于查找 Lua 库的加载库。 它使用储存在 package.path 中的路径来做查找工作。 查找过程和函数 package.searchpath 描述的一致。

第三个查找器用于查找 C 库的加载库。 它使用储存在 package.cpath 中的路径来做查找工作。 同样， 查找过程和函数 package.searchpath 描述的一致。 例如，如果 C 路径是这样一个字符串

	 "./?.so;./?.dll;/usr/local/?/init.so"
查找器查找模块 foo 会依次尝试打开文件 ./foo.so，./foo.dll， 以及 /usr/local/foo/init.so。 一旦它找到一个 C 库， 查找器首先使用动态链接机制连接该库。 然后尝试在该库中找到可以用作加载器的 C 函数。 这个 C 函数的名字是 "luaopen_" 紧接模块名的字符串， 其中字符串中所有的下划线都会被替换成点。 此外，如果模块名中有横线， 横线后面的部分（包括横线）都被去掉。 例如，如果模块名为 a.b.c-v2.1， 函数名就是 luaopen_a_b_c。

第四个搜索器是　一体化加载器。 它从 C 路径中查找指定模块的根名字。 例如，当请求 a.b.c　时， 它将查找 a 这个 C 库。 如果找得到，它会在里面找子模块的加载函数。 在我们的例子中，就是找　luaopen_a_b_c。 利用这个机制，可以把若干 C 子模块打包进单个库。 每个子模块都可以有原本的加载函数名。

除了第一个（预加载）搜索器外，每个搜索器都会返回 它找到的模块的文件名。 这和 package.searchpath 的返回值一样。 第一个搜索器没有返回值。]==],
			pos = 1
		},
		{	name = "package.searchpath",
			title = "在指定路径中搜索模块",
			description = [==[声明
	fullpath, err = package.searchpath(name, path[, sep[, rep]])

参数及返回值
	name 
		文本型，需要搜索的模块名
	path 
		文本型，搜索路径
	sep 
		文本型，可选参数，默认是 "."
	rep 
		文本型，可选参数，默认是系统的目录分割符（Windows 下是 "\\"，*nix 系统是 "/"）
	fullpath, err 
		文本型，如果搜索到指定模块，则 fullpath 返回模块文件名，否则 fullpath 返回 nil 并附带错误信息 err

说明
	在指定 path 中搜索指定的 name 。
	路径是一个包含有一系列以分号分割的 模板 构成的字符串。 对于每个模板，都会用 name 替换其中的每个问号（如果有的话）。 且将其中的 sep （默认是点）替换为 rep （默认是系统的目录分割符）。 然后尝试打开这个文件名。
	例如，如果路径是字符串
	"./?.lua;./?.lc;/usr/local/?/init.lua"
	搜索 foo.a　这个名字将 依次尝试打开文件 ./foo/a.lua， ./foo/a.lc　，以及 /usr/local/foo/a/init.lua。
	返回第一个可以用读模式打开（并马上关闭该文件）的文件的名字。 如果不存在这样的文件，返回 nil 加上错误消息。 （这条错误消息列出了所有尝试打开的文件名。）

示例
print(package.searchpath("dm", "/var/mobile/Media/1ferver/lua/?.lua"))
如果 /var/mobile/Media/1ferver/lua/dm.lua 文件存在，将输出：
/var/mobile/Media/1ferver/lua/dm.lua
如果 /var/mobile/Media/1ferver/lua/dm.lua 文件不存在，将输出：
nil 
no file '/var/mobile/Media/1ferver/lua/dm.lua']==],
			pos = 1
		},
	},
	{	name = "字符串处理库",
		description = [[这个库提供了字符串处理的通用函数。 例如字符串查找、子串、模式匹配等。 当在 Lua 中对字符串做索引时，第一个字符从 1 开始计算（而不是 C 里的 0 ）。 索引可以是负数，它指从字符串末尾反向解析。 即，最后一个字符在 -1 位置处，等等。

字符串库中的所有函数都在表 string 中。 它还将其设置为字符串元表的 __index 域。 因此，你可以以面向对象的形式使用字符串函数。 例如，string.byte(s,i) 可以写成 s:byte(i)。

字符串库假定采用单字节字符编码。]],
		{	name = "string.byte",
			title = "获取字符串数字编码",
			description = [==[声明
	... = string.byte(s[, i[, j]])

参数及返回值
	s 
		字符串型，字符串本体
	i, j 
		整数型，可选参数，i 为需要操作的字符串索引起始位置，j 为需要操作的字符串索引终止位置，默认都为 1
	... 
		整数型，返回一个或多个数字（i 到 j 有多少个字节就返回多少个）

说明
	返回字符 s[i]， s[i+1]， ...　，s[j] 的内部数字编码。 i 的默认值是 1 ； j 的默认值是 i。 这些索引以函数 string.sub 的规则修正。 
	数字编码没有必要跨平台。

示例 
以下例子的编码为 UTF-8
s = "XXTouch"
print(string.byte(s))
print(string.byte(s, 1, -1))
print(s:byte())
print(s:byte(1, -1))
将输出：
88
88  88  84  111 117 99  104
88
88  88  84  111 117 99  104]==],
			pos = 1
		},
		{	name = "string.char",
			title = "数字编码转换成字符串",
			description = [[声明
	s = string.char(···)

参数及返回值
	... 
		整数型，需要转换成字符串的数字编码，可以有多个参数
	s 
		字符串型，返回转换后的字符串

说明
	接收零或更多的整数。 返回和参数数量相同长度的字符串。 其中每个字符的内部编码值等于对应的参数值。 
	数字编码没有必要跨平台。

示例 
以下例子的编码为 UTF-8
print(string.char(88, 88, 84, 111, 117, 99, 104))
将输出：
XXTouch]],
			pos = 1
		},
		{	name = "string.dump",
			title = "序列化函数",
			description = [[声明
	s = string.dump(func[, strip])

参数及返回值
	func 
		函数型，需要序列化的函数
	strip 
		布尔型，如果 strip 为真值， 二进制代码块不携带该函数的调试信息 （局部变量名，行号，等等。）
	s 
		字符串型，返回包含有以二进制方式表示的（一个 二进制代码块 ）指定函数的字符串

说明
	返回包含有以二进制方式表示的（一个 二进制代码块 ）指定函数的字符串。 之后可以用 load 调用这个字符串获得 该函数的副本（但是绑定新的上值）。 如果　strip 为真值， 二进制代码块不携带该函数的调试信息 （局部变量名，行号，等等。）。
	带上值的函数只保存上值的数目。 当（再次）加载时，这些上值被更新为 nil 的实例。 （你可以使用调试库按你需要的方式来序列化上值，并重载到函数中）

示例
function hello()
	print('Hello XXTouch')
end
s = string.dump(hello)
f = load(s)
f()
将输出：
Hello XXTouch]],
			pos = 1
		},
		{	name = "string.find",
			title = "字符串查找",
			description = [==[声明
	sp, ep = string.find(s, pattern[, init[, plain]])

参数及返回值
	s 
		字符串型，在这个字符串中查找
	pattern 
		字符串型，用于描述一个匹配模式，或需要查找的字符串
	init 
		整数型，可选参数，查找在字符串 s 的开始位置，默认为 1
	plain 
		布尔型，可选参数，关闭模式匹配机制，默认为 false
	sp, ep 
		整数型 | nil，如果查找成功，则 sp 为找到的串在 s 中的起始位置，ep 为结束位置；否则返回 nil

说明
	查找第一个字符串 s 中匹配到的 pattern。 如果找到一个匹配，find 会返回 s 中关于它起始及终点位置的索引； 否则，返回 nil。 第三个可选数字参数 init 指明从哪里开始搜索； 默认值为 1 ，同时可以是负值。 第四个可选参数 plain 为 true 时， 关闭模式匹配机制。 此时函数仅做直接的 “查找子串”的操作， 而 pattern 中没有字符被看作魔法字符。 注意，如果给定了 plain，就必须写上 init 。

示例
s = "XXTouch."
print(string.find(s, "Tou"))
print(string.find(s, "."))
print(string.find(s, ".", 1, true))
print(string.find(s, "%."))
将输出：
3	5
1	1
8	8
8	8
]==],
			pos = 1
		},
		{	name = "string.format",
			title = "格式化字符串",
			description = [[声明
	s = string.format(fmt, ···)

参数及返回值
	fmt 
		字符串型，格式化模式
	... 
		任意类型，将会被填充到 fmt 中的值
	s 
		字符串型，返回格式化后的字符串

说明
	返回不定数量参数的格式化版本， 格式化串为第一个参数（必须是一个字符串）。 格式化字符串遵循 ISO C 函数 sprintf 的规则。 不同点在于选项 *, h, L, l, n, p 不支持， 另外还增加了一个选项 q。 q 选项将一个字符串格式化为两个双引号括起，对内部字符做恰当的转义处理的字符串。 该字符串可以安全的被 Lua 解释器读回来。 例如，调用
	string.format('%q', 'a string with "quotes" and \n new line')
	会产生字符串：
	"a string with \"quotes\" and \
	new line"
	选项 A and a （如果有的话）， E, e, f, G, and g 都期待一个对应的数字参数。 选项 c, d, i, o, u, X, and x 则期待一个整数。 选项 q 期待一个字符串； 选项 s 期待一个没有内嵌零的字符串。 如果选项 s 对应的参数不是字符串，它会用和 tostring 一致的规则转换成字符串。

示例
print(string.format("%d + %d = %d", 100, 200, 100+200))
print(string.format("%f * %f = %f", 100, 200, 100*200))
print(string.format("%x + %x = %x", 100, 200, 100+200))
将输出：
100 + 200 = 300
100.000000 * 200.000000 = 20000.000000
64 + c8 = 12c]],
			pos = 1
		},
		{	name = "string.gmatch",
			title = "字符串迭代匹配",
			description = [[声明
	it = string.gmatch(s, pattern)

参数及返回值
	s 
		字符串型，需要迭代匹配的源字符串
	pattern 
		字符串型，匹配的模式（参见 匹配模式）
	it 
		函数型，一个迭代器函数，每次调用都会返回 s 中下一个 pattern 匹配的所有值，如果没有下一个匹配则调用返回 nil

说明
	返回一个迭代器函数。 每次调用这个函数都会继续以 pattern（参见 匹配模式） 对 s 做匹配，并返回所有捕获到的值。 如果 pattern 中没有指定捕获，则每次捕获整个 pattern。 
	下面这个例子会循环迭代字符串 s 中所有的单词， 并逐行打印：
	s = "hello world from Lua"
	for w in string.gmatch(s, "%a+") do
	  print(w)
	end
	下一个例子从指定的字符串中收集所有的键值对 key=value 置入一张表：
	t = {}
	s = "from=world, to=Lua"
	for k, v in string.gmatch(s, "(%w+)=(%w+)") do
	  t[k] = v
	end
	对这个函数来说，模板前开始的 '^' 不会当成锚点。因为这样会阻止迭代。

示例1
for k,v in string.gmatch("k=XXTouch,v=awesome#k=Soze,v=a goodman#", "k=(.-),v=(.-)#") do
	print(k, "is", v)
end
将输出：
XXTouch is  awesome
Soze	is  a goodman

示例2
local it = string.gmatch("k=XXTouch,v=Awesome#k=Soze,v=a Goodman#", "k=(.-),v=(.-)#")
while (true) do
	local k, v = it()
	if (k) then
		print(k, v)
	else
		break
	end
end
将输出：
XXTouch Awesome
Soze	a Goodman]],
			pos = 1
		},
		{	name = "string.gsub",
			title = "字符串迭代替换",
			description = [[声明
	ts, count = string.gsub(s, pattern, repl[, n])

参数及返回值
	s 
		字符串型，需要迭代替换的源字符串
	pattern 
		字符串型，匹配的模式（参见 匹配模式）
	ts, count 
		字符串型, 整数型，ts 为替换后的字符串，count 是当前调用替换匹配发生的次数

说明
	将字符串 s 中，所有的（或是在 n 给出时的前 n 个） pattern（参见 匹配模式） 都替换成 repl ，并返回其副本。 repl 可以是字符串、表、或函数。 gsub 还会在第二个返回值返回一共发生了多少次匹配。 gsub 这个名字来源于 Global SUBstitution 。 
	如果 repl 是一个字符串，那么把这个字符串作为替换品。 字符 % 是一个转义符： repl 中的所有形式为 %d 的串表示 第 d 个捕获到的子串，d 可以是 1 到 9 。 串 %0 表示整个匹配。 串 %% 表示单个 %。
	如果 repl 是张表，每次匹配时都会用第一个捕获物作为键去查这张表。
	如果 repl 是个函数，则在每次匹配发生时都会调用这个函数。 所有捕获到的子串依次作为参数传入。
	任何情况下，模板中没有设定捕获都看成是捕获整个模板。
	如果表的查询结果或函数的返回结果是一个字符串或是个数字， 都将其作为替换用串； 而在返回 false 或 nil　时不作替换 （即保留匹配前的原始串）。
	这里有一些用例：
	x = string.gsub("hello world", "(%w+)", "%1 %1")
	--> x="hello hello world world"
	x = string.gsub("hello world", "%w+", "%0 %0", 1)
	--> x="hello hello world"
	x = string.gsub("hello world from Lua", "(%w+)%s*(%w+)", "%2 %1")
	--> x="world hello Lua from"
	x = string.gsub("home = $HOME, user = $USER", "%$(%w+)", os.getenv)
	--> x="home = /home/roberto, user = roberto"
	x = string.gsub("4+5 = $return 4+5$", "%$(.-)%$", function (s)
		  return load(s)()
		end)
	--> x="4+5 = 9"
	local t = {name="lua", version="5.3"}
	x = string.gsub("$name-$version.tar.gz", "%$(%w+)", t)
	--> x="lua-5.3.tar.gz"

示例
print(string.gsub("k=XXTouch,v=Awesome#k=Soze,v=a Goodman#", "k=(.-),v=(.-)#", "%1 %2\n"))
将输出：
XXTouch Awesome
Soze a Goodman
	2]],
			pos = 1
		},
		{	name = "string.len",
			title = "获取字符串长度",
			description = [[声明
	l = string.len(s)

参数及返回值
	s 
		字符串型，一个字符串
	l 
		整数型，返回字符串的长度

说明
	接收一个字符串，返回其长度。 空串 "" 的长度为 0 。 内嵌零也统计在内，因此 "a\000bc\000" 的长度为 5 。

示例
print(string.len("XXTouch"))
将输出：
7]],
			pos = 1
		},
		{	name = "string.lower",
			title = "字符串转换为小写",
			description = [[声明
	ls = string.lower(s)

参数及返回值
	s 
		字符串型，源字符串
	ls 
		字符串型，转换成小写的字符串

说明
	接收一个字符串，将其中的大写字符都转为小写后返回其副本。 其它的字符串不会更改。 对大写字符的定义取决于当前的区域设置。

示例
print(string.lower("XXTouch"))
将输出：
xxtouch]],
			pos = 1
		},
		{	name = "string.upper",
			title = "字符串转换为大写",
			description = [[声明
	us = string.upper(s)

参数及返回值
	s 
		字符串型，源字符串
	us 
		字符串型，转换成大写的字符串

说明
	接收一个字符串，将其中的小写字符都转为大写后返回其副本。 其它的字符串不会更改。 对小写字符的定义取决于当前的区域设置。

示例
print(string.lower("XXTouch"))
将输出：
XXTOUCH]],
			pos = 1
		},
		{	name = "string.match",
			title = "对字符串进行一次模式匹配",
			description = [[声明
	ms = string.match(s, pattern[, init])

参数及返回值
	s 
		字符串型，源字符串
	pattern 
		字符串型，模式串（参见 匹配模式）
	init 
		整数型，可选参数，匹配于字符串 s 中的开始位置，默认为 1
	ms 
		字符串型 | nil，以模式 pattern 在 s 中匹配到的串，没有匹配到则返回 nil

说明
	在字符串 s 中找到第一个能用 pattern（参见 匹配模式） 匹配到的部分。 如果能找到，match 返回其中的捕获物； 否则返回 nil 。 如果 pattern 中未指定捕获， 返回整个 pattern 捕获到的串。 第三个可选数字参数 init 指明从哪里开始搜索； 它默认为 1 且可以是负数。

示例
print(string.match("XXTouch", "%d"))
print(string.match("XXT0uch", "%d"))
将输出：
nil
0]],
			pos = 1
		},
		{	name = "string.sub",
			title = "从字符串中截取部分",
			description = [[声明
	ss = string.sub(s, i[, j])

参数及返回值
	s 
		字符串型，源字符串
	i 
		整数型，需要取出的子字符串在字符串 s 的起始位置
	j 
		整数型，可选参数，需要取出的子字符串在字符串 s 的终止位置，默认为 -1
	ss 
		字符串型，从 s 中取出的子字符串

说明
	返回 s 的子串， 该子串从 i 开始到 j 为止； i 和 j 都可以为负数。 如果不给出 j ，就当它是 -1 （和字符串长度相同）。 特别是， 调用 string.sub(s,1,j) 可以返回 s 的长度为 j 的前缀串， 而 string.sub(s, -i) 返回长度为 i 的后缀串。
	如果在对负数索引转义后 i 小于 1 的话，就修正回 1 。 如果 j 比字符串的长度还大，就修正为字符串长度。 如果在修正之后，i 大于 j， 函数返回空串。

示例
print(string.sub("XXTouch", 3))
print(string.sub("XXT0uch", 3, 5))
将输出：
Touch
T0u]],
			pos = 1
		},
		{	name = "string.rep",
			title = "构造重复字符串",
			description = [[声明
	rs = string.rep(s, n[, sep])

参数及返回值
	s 
		字符串型，源字符串
	n 
		整数型，需要重复的次数
	sep 
		字符串型，可选参数，连接每个 s 的分隔符，默认为 ""
	rs 
		字符串型，构造出的字符串

说明
	返回 n 个字符串 s 以字符串 sep 为分割符连在一起的字符串。 默认的 sep 值为空字符串（即没有分割符）。 如果 n 不是正数则返回空串。

示例
print(string.rep("XXTouch", 3))
print(string.rep("XXTouch", 4, ","))
将输出：
XXTouchXXTouchXXTouch
XXTouch,XXTouch,XXTouch,XXTouch]],
			pos = 1
		},
		{	name = "string.reverse",
			title = "翻转字符串",
			description = [[声明
	rs = string.reverse(s)

参数及返回值
	s 
		字符串型，源字符串
	rs 
		字符串型，翻转后的字符串

说明
	返回字符串 s 的翻转串。

示例
print(string.reverse("XXTouch"))
将输出：
hcuoTXX]],
			pos = 1
		},
		{	name = "string.pack",
			title = "打包字符串",
			description = [[声明
	ps = string.pack(fmt, v1, v2, ···)

参数及返回值
	fmt 
		字符串型，打包的格式模式（参见 打包和解包用到的格式串）
	v1, v2, ... 
		任意类型，需要格式化打包的值
	ps 
		字符串型，返回打包好可以用于传输的二进制串

说明
	返回一个打包了（即以二进制形式序列化） v1, v2 等值的二进制字符串。 字符串 fmt 为打包格式（参见 打包和解包用到的格式串）。

示例
--]],
			pos = 1
		},
		{	name = "string.unpack",
			title = "解包字符串",
			description = [[声明
	..., epos = string.unpack(fmt, s[, pos])

参数及返回值
	fmt 
		字符串型，需要解包字符串的打包的格式模式（参见 打包和解包用到的格式串）
	s 
		字符串型，需要解包的二进制串
	pos 
		整数型，本次解包从 s 中开始的位置
	... 
		任意类型，返回解包出来的数据们
	epos 
		整数型，返回本次解包完毕终止于 s 中的位置

说明
	返回以格式 fmt（参见 打包和解包用到的格式串） 打包在字符串 s （参见 string.pack） 中的值。 选项 pos（默认为 1 ）标记了从 s 中哪里开始读起。 读完所有的值后，函数返回 s 中第一个未读字节的位置。

示例
--]],
			pos = 1
		},
		{	name = "string.packsize",
			title = "计算一个打包格式的尺寸",
			description = [[声明
	size = string.packsize(fmt)

参数及返回值
	fmt 
		字符串型，打包的格式模式（参见 打包和解包用到的格式串）
	size 
		整数型，返回这个格式化模式打包的数据的尺寸（单位：字节）

说明
	返回以指定格式用 string.pack 打包的字符串的长度。 格式化字符串中不可以有变长选项 's' 或 'z' 。

示例
--]],
			pos = 1
		},
		{	name = "string",
			title = "匹配模式",
			description = [[Lua 中的匹配模式直接用常规的字符串来描述。 它用于模式匹配函数 string.find, string.gmatch, string.gsub, string.match。 这一节表述了这些字符串的语法及含义（即它能匹配到什么）。

字符类 
	字符类 用于表示一个字符集合。 下列组合可用于字符类：
		x: （这里 x 不能是 魔法字符 ^$()%.[]*+-? 中的一员） 表示字符 x 自身。
		.: （一个点）可表示任何字符。
		%a: 表示任何字母。
		%c: 表示任何控制字符。
		%d: 表示任何数字。
		%g: 表示任何除空白符外的可打印字符。
		%l: 表示所有小写字母。
		%p: 表示所有标点符号。
		%s: 表示所有空白字符。
		%u: 表示所有大写字母。
		%w: 表示所有字母及数字。
		%x: 表示所有 16 进制数字符号。
		%x: （这里的 x 是任意非字母或数字的字符） 表示字符 x。 这是对魔法字符转义的标准方法。 所有非字母或数字的字符 （包括所有标点，也包括非魔法字符） 都可以用前置一个 '%' 放在模式串中表示自身。
		[set]: 表示 set　中所有字符的联合。 可以以 '-' 连接，升序书写范围两端的字符来表示一个范围的字符集。 上面提到的 %x 形式也可以在 set 中使用 表示其中的一个元素。 其它出现在 set 中的字符则代表它们自己。 例如，[%w_] （或 [_%w]） 表示所有的字母数字加下划线）， [0-7] 表示 8 进制数字， [0-7%l%-]　表示 8 进制数字加小写字母与 '-' 字符。交叉使用类和范围的行为未定义。 因此，像 [%a-z] 或 [a-%%] 这样的模式串没有意义。
		[^set]: 表示 set 的补集， 其中 set 如上面的解释。
所有单个字母表示的类别（%a，%c，等）， 若将其字母改为大写，均表示对应的补集。 例如，%S 表示所有非空格的字符。 
如何定义字母、空格、或是其他字符组取决于当前的区域设置。 特别注意：[a-z]　未必等价于 %l 。

模式条目 
模式条目 可以是 
单个字符类匹配该类别中任意单个字符； 
单个字符类跟一个 '*'， 将匹配零或多个该类的字符。 这个条目总是匹配尽可能长的串； 
单个字符类跟一个 '+'， 将匹配一或更多个该类的字符。 这个条目总是匹配尽可能长的串； 
单个字符类跟一个 '-'， 将匹配零或更多个该类的字符。 和 '*' 不同， 这个条目总是匹配尽可能短的串； 
单个字符类跟一个 '?'， 将匹配零或一个该类的字符。 只要有可能，它会匹配一个； 
%n， 这里的 n 可以从 1 到 9； 这个条目匹配一个等于 n 号捕获物（后面有描述）的子串。 
%bxy， 这里的 x 和 y 是两个明确的字符； 这个条目匹配以 x 开始 y 结束， 且其中 x 和 y 保持 平衡 的字符串。 意思是，如果从左到右读这个字符串，对每次读到一个 x 就 +1 ，读到一个 y 就 -1， 最终结束处的那个 y 是第一个记数到 0 的 y。 举个例子，条目 %b() 可以匹配到括号平衡的表达式。 
%f[set]，指 边境模式； 这个条目会匹配到一个位于 set 内某个字符之前的一个空串， 且这个位置的前一个字符不属于 set 。 集合 set 的含义如前面所述。 匹配出的那个空串之开始和结束点的计算就看成该处有个字符 '\0' 一样。

模式 
模式 指一个模式条目的序列。 在模式最前面加上符号 '^' 将锚定从字符串的开始处做匹配。 在模式最后面加上符号 '$' 将使匹配过程锚定到字符串的结尾。 如果 '^' 和 '$' 出现在其它位置，它们均没有特殊含义，只表示自身。

捕获 
模式可以在内部用小括号括起一个子模式； 这些子模式被称为 捕获物。 当匹配成功时，由 捕获物 匹配到的字符串中的子串被保存起来用于未来的用途。 捕获物以它们左括号的次序来编号。 例如，对于模式 "(a*(.)%w(%s*))" ， 字符串中匹配到 "a*(.)%w(%s*)" 的部分保存在第一个捕获物中 （因此是编号 1 ）； 由 "." 匹配到的字符是 2 号捕获物， 匹配到 "%s*" 的那部分是 3 号。

作为一个特例，空的捕获 () 将捕获到当前字符串的位置（它是一个数字）。 例如，如果将模式 "()aa()" 作用到字符串 "flaaap" 上，将产生两个捕获物： 3 和 5 。]],
			code = ""
		},
		{	name = "string",
			title = "打包和解包用到的格式串",
			description = [[用于 string.pack， string.packsize， string.unpack 的第一个参数。 它是一个描述了需要创建或读取的结构之布局。 
格式串是由转换选项构成的序列。

以下为转换选项 
	<: 设为小端编码 
	>: 设为大端编码 
	=: 大小端遵循本地设置 
	![n]: 将最大对齐数设为 n （默认遵循本地对齐设置） 
	b: 一个有符号字节 (char) 
	B: 一个无符号字节 (char) 
	h: 一个有符号 short （本地大小） 
	H: 一个无符号 short （本地大小） 
	l: 一个有符号 long （本地大小） 
	L: 一个无符号 long （本地大小） 
	j: 一个 lua_Integer 
	J: 一个 lua_Unsigned 
	T: 一个 size_t （本地大小） 
	i[n]: 一个 n 字节长（默认为本地大小）的有符号 int 
	I[n]: 一个 n 字节长（默认为本地大小）的无符号 int 
	f: 一个 float （本地大小） 
	d: 一个 double （本地大小） 
	n: 一个 lua_Number 
	cn: n字节固定长度的字符串 
	z: 零结尾的字符串 
	s[n]: 长度加内容的字符串，其长度编码为一个 n 字节（默认是个 size_t） 长的无符号整数。 
	x: 一个字节的填充 
	Xop: 按选项 op 的方式对齐（忽略它的其它方面）的一个空条目 
	' ': （空格）忽略
（ "[n]" 表示一个可选的整数。） 除填充、空格、配置项（选项 "xX <=>!"）外， 每个选项都关联一个参数（对于 string.pack） 或结果（对于 string.unpack）。

对于选项 "!n", "sn", "in", "In", n 可以是 1 到 16 间的整数。 所有的整数选项都将做溢出检查； string.pack 检查提供的值是否能用指定的字长表示； string.unpack 检查读出的值能否置入 Lua 整数中。

任何格式串都假设有一个 "!1=" 前缀， 即最大对齐为 1 （无对齐）且采用本地大小端设置。

对齐行为按如下规则工作： 对每个选项，格式化时都会填充一些字节直到数据从一个特定偏移处开始， 这个位置是该选项的大小和最大对齐数中较小的那个数的倍数； 这个较小值必须是 2 个整数次方。 选项 "c" 及 "z" 不做对齐处理； 选项 "s" 对对齐遵循其开头的整数。

string.pack 用零去填充 （string.unpack 则忽略它）。]],
			code = ""
		},
	},
	{	name = "UTF-8 支持模块",
		description = [[这个库提供了对 UTF-8 编码的基础支持。 所有的函数都放在表 utf8 中。 此库不提供除编码处理之外的任何 Unicode 支持。 所有需要了解字符含义的操作，比如字符分类，都不在此范畴。
除非另有说明， 当一个函数需要一个字节位置的参数时， 都假定这个位置要么从字节序列的开始计算， 要么从字符串长度加一的位置算。 和字符串库一样，负的索引从字符串末尾计起。]],
		{	name = "utf8.char",
			title = "",
			description = [[
utf8.char (···)

接收零或多个整数， 将每个整数转换成对应的 UTF-8 字节序列，并返回这些序列连接到一起的字符串。]],
			pos = 1
		},
		{	name = "utf8.charpattern",
			title = "",
			description = [[用于精确匹配到一个 UTF-8 字节序列的模式（是一个字符串，并非函数）"[\0-\x7F\xC2-\xF4][\x80-\xBF]*" （参见 §6.4.1）。 它假定处理的对象是一个合法的 UTF-8 字符串。]],
			pos = 1
		},
		{	name = "utf8.codes",
			title = "",
			description = [[
utf8.codes (s)

返回一系列的值，可以让
	 for p, c in utf8.codes(s) do body end
迭代出字符串 s 中所有的字符。 这里的 p 是位置（按字节数）而 c 是每个字符的编号。 如果处理到一个不合法的字节序列，将抛出一个错误。]],
			pos = 1
		},
		{	name = "utf8.codepoint",
			title = "",
			description = [=[
utf8.codepoint (s [, i [, j]])

一整数形式返回 s 中 从位置 i 到 j 间（包括两端） 所有字符的编号。 默认的 i 为 1 ，默认的 j 为 i。 如果碰上不合法的字节序列，抛出一个错误。
]=],
			pos = 1
		},
		{	name = "utf8.len",
			title = "",
			description = [==[utf8.len (s [, i [, j]])
返回字符串 s 中 从位置 i 到 j 间 （包括两端） UTF-8 字符的个数。 默认的 i 为 1 ，默认的 j 为 -1 。 如果它找到任何不合法的字节序列， 返回假值加上第一个不合法字节的位置。]==],
			pos = 1
		},
		{	name = "utf8.offset",
			title = "",
			description = [[
utf8.offset (s, n [, i])

返回编码在 s 中的第 n 个字符的开始位置（按字节数） （从位置 i 处开始统计）。 负 n 则取在位置 i 前的字符。 当 n 是非负数时，默认的 i 是 1， 否则默认为 #s + 1。 因此，utf8.offset(s, -n) 取字符串的倒数第 n 个字符的位置。 如果指定的字符不在其中或在结束点之后，函数返回 nil。
作为特例，当 n 等于 0 时， 此函数返回含有 s 第 i 字节的那个字符的开始位置。
这个函数假定 s 是一个合法的 UTF-8 字符串。]],
			pos = 1
		},
	},
	{	name = "表处理库",
		description = [[这个库提供了表处理的通用函数。 所有函数都放在表 table 中。 
记住，无论何时，若一个操作需要取表的长度， 这张表必须是一个真序列（顺序表），或是拥有 __len 元方法。 所有的函数都忽略传入参数的那张表中的非数字键。]],
		{	name = "table.concat",
			title = "将顺序表所有项拼接成字符串",
			description = [==[声明
	s = table.concat (list[, sep[, i[, j]]])

参数及返回值
	list 
		顺序表型，需要拼接成字符串的源表
	sep 
		字符串型，字符串连接符
	i 
		整数型，可选参数，需要拼接的项在表 list 中的起始索引，默认 1
	j 
		整数型，可选参数，需要拼接的项在表 list 中的终止索引，默认 #list
	s 
		字符串型，返回拼接好的字符串

说明
	提供一个列表，其所有元素都是字符串或数字，返回字符串 list[i]..sep..list[i+1] ··· sep..list[j]。 sep 的默认值是空串， i 的默认值是 1 ， j 的默认值是 #list 。 如果 i 比 j 大，返回空串。

示例
t = {
	"I", "will", "do", "whatever", "it",
	"takes", "to", "serve", "my", "country",
	"even", "at", "the", "cost", "of", "my",
	"own", "life",
}
print(table.concat(t, " "))
将输出：
I will do whatever it takes to serve my country even at the cost of my own life]==],
			pos = 1
		},
		{	name = "table.insert",
			title = "在顺序表中插入一个值",
			description = [[声明
	s = table.insert(list, [pos,] value)

参数及返回值
	list 
		顺序表型，需要插入值的源表
	pos 
		整数型，可选参数，需要插入值到表 list 中的位置，默认 #list+1 （表最后项之后）
	value 
		任意类型，需要插入到 pos 位置之前的值

说明
	在 list 的位置 pos 处插入元素 value ， 并后移元素 list[pos], list[pos+1], ···, list[#list] 。 pos 的默认值为 #list+1 ， 因此调用 table.insert(t,x) 会将 x 插在列表 t 的末尾。

示例
t = {
	"will", "do",
}
table.insert(t, "whatever")
table.insert(t, 1, "I")
print(table.concat(t, " "))
将输出：
I will do whatever]],
			pos = 1
		},
		{	name = "table.move",
			title = "顺序表批量传值",
			description = [[声明
	a3 = table.move(a1, f, e, t [,a2])

参数及返回值
	a1 
		顺序表型，数据源表
	f 
		整数型，数据源表 a1 中的起始索引
	e 
		整数型，数据源表 a1 中的终止索引
	t 
		整数型，目标表 a2 中的起始索引
	a2 
		顺序表型，可选参数，目标表，默认为 a1
	a3 
		顺序表型，如果有 a2 参数，则返回 a2，否则返回 a1

说明
	将元素从表 a1 移到表 a2。 这个函数做了次等价于后面这个多重赋值的等价操作： a2[t],··· = a1[f],···,a1[e]。 a2 的默认值为 a1。 目标区间可以和源区间重叠。 索引 f 必须是正数。

示例
t = {
	7, 2, 8
}
table.move(t, 1, #t, 2)
for i,v in ipairs(t) do
	print(i, v)
end
将输出：
1	7
2	7
3	2
4	8]],
			pos = 1
		},
		{	name = "table.remove",
			title = "删除表中元素",
			description = [[声明
	item = table.remove(list[, pos])

参数及返回值
	list 
		顺序表型，数据源表
	pos 
		整数型，需要删除的项在表 list 中的索引
	item 
		任意类型，返回被从表中移除的项

说明
	移除 list 中 pos 位置上的元素，并返回这个被移除的值。 当 pos 是在 1 到 #list 之间的整数时， 它向前移动元素　list[pos+1], list[pos+2], ···, list[#list] 并删除元素 list[#list]； 索引 pos 可以是 #list + 1 ，或在 #list 为 0 时可以是 0 ； 在这些情况下，函数删除元素 list[pos]。

示例
t = {
	7, 2, 8, 3
}
print(table.remove(t, 3))
print(table.remove(t))
print(table.remove(t))
print(table.remove(t))
print(table.remove(t))
将输出：
8
3
2
7
nil]],
			pos = 1
		},
		{	name = "table.sort",
			title = "对顺序表进行排序",
			description = [[声明
	table.sort(list[, comp])

参数及返回值
	list 
		顺序表型，数据源表
	comp 
		函数型，可选参数，比较函数，默认将使用标准 Lua 操作 < 作为替代品

说明
	在表内从 list[1] 到 list[#list] 原地 对其间元素按指定次序排序。 如果提供了 comp ， 它必须是一个可以接收两个列表内元素为参数的函数。 当第一个元素需要排在第二个元素之前时，返回真 （因此 not comp(list[i+1],list[i]) 在排序结束后将为真）。 如果没有提供 comp， 将使用标准 Lua 操作 < 作为替代品。 
	如果 not comp(a, b) 结果与 comp(a, b) 可能一样，那么排序将无法完成，应当避免写出这种排序函数

示例
t = {
	7, 4, 3, 1, 3, 9, 3, 6
}
table.sort(t)
print(table.concat(t, ", "))
table.sort(t, function(a, b)
	return a > b
end)
print(table.concat(t, ", "))
-- 以下为不严谨的排序函数，在当前
示例中将会抛出错误
-- 但是它在很多情况下都会正常运行，注意避免写出这样的排序函数
table.sort(t, function(a, b)
	return a >= b
end)
print(table.concat(t, ", "))
将输出：
1, 3, 3, 3, 4, 6, 7, 9
9, 7, 6, 4, 3, 3, 3, 1
并抛出错误：
...: 15: invalid order function for sorting]],
			pos = 1
		},
		{	name = "table.unpack",
			title = "解包顺序表",
			description = [==[声明
	... = table.unpack (list[, i [, j]])

参数及返回值
	list 
		顺序表型，数据源表
	i 
		整数型，可选参数，需要解包的项集合在表 list 的起始位置，默认 1
	j 
		整数型，可选参数，需要解包的项集合在表 list 的终止位置，默认 #list
	... 
		任意类型，可选参数，比较函数，默认将使用标准 Lua 操作 < 作为替代品

说明
	返回顺序表中的元素。这个函数等价于
	return list[i], list[i+1], ···, list[j]
	i 默认为 1 ，j 默认为 #list。

示例
t = {
	7, 4, 3, 1, 3, 9, 3, 6
}
print(table.unpack(t))
print(table.unpack(t, 3, 7))
将输出：
7	4	3	1	3	9	3	6
3	1	3	9	3]==],
			pos = 1
		},
	},
	{	name = "数学函数库",
		description = [[这个库提供了基本的数学函数。 所以函数都放在表 math 中。 注解有 "integer/float" 的函数会对整数参数返回整数结果， 对浮点（或混合）参数返回浮点结果。 圆整函数（math.ceil, math.floor, math.modf） 在结果在整数范围内时返回整数，否则返回浮点数。]],
		{	name = "math.abs",
			title = "取绝对值 ",
			description = [[声明
	y = math.abs(x)

参数及返回值
	x 
		实数型，源数字
	y 
		实数型，返回源数字 x 的绝对值

说明
	返回 x 的绝对值。(integer/float)

示例
print(math.abs(100))
print(math.abs(-100))
print(math.abs(-100.99))
将输出：
100
100
100.99]],
			pos = 1
		},
		{	name = "math.acos",
			title = "取反余弦值",
			description = [[声明
	y = math.acos(x)

参数及返回值
	x 
		实数型，源数字
	y 
		实数型，返回源数字 x 的反余弦值

说明
	返回 x 的反余弦值（用弧度表示）。

示例
print(math.acos(0.5))
将输出：
1.0471975511966]],
			pos = 1
		},
		{	name = "math.asin",
			title = "取反正弦值",
			description = [[声明
	y = math.asin(x)

参数及返回值
	x 
		实数型，源数字
	y 
		实数型，返回源数字 x 的反正弦值

说明
	返回 x 的反正弦值（用弧度表示）。

示例
print(math.asin(0.5))
将输出：
0.5235987755983]],
			pos = 1
		},
		{	name = "math.atan",
			title = "取反正切值",
			description = [[声明
	z = math.atan(y[, x])

参数及返回值
	y, x 
		实数型，源数字，x 为可选参数，默认 1
	z 
		实数型，返回 y/x 的反正切值（用弧度表示）

说明
	返回 y/x 的反正切值（用弧度表示）。 它会使用两个参数的符号来找到结果落在哪个象限中。（即使 x 为零时，也可以正确的处理。）
	默认的 x 是 1 ， 因此调用 math.atan(y) 将返回 y 的反正切值。

示例
print(math.atan(0.5))
print(math.atan(0.5, 0.7))
将输出：
0.46364760900081
0.62024948598282]],
			pos = 1
		},
		{	name = "math.ceil",
			title = "向上取整",
			description = [[声明
	y = math.ceil(x)

参数及返回值
	x 
		实数型，源数字
	y 
		整数型，返回不小于 x 的最小整数值

说明
	返回不小于 x 的最小整数值。

示例
print(math.ceil(0.5))
print(math.ceil(1))
将输出：
1
1]],
			pos = 1
		},
		{	name = "math.cos",
			title = "取余弦值",
			description = [[声明
	y = math.cos(x)

参数及返回值
	x 
		实数型，源数字
	y 
		实数型，返回 x 的余弦（假定参数是弧度）

说明
	返回 x 的余弦（假定参数是弧度）。

示例
print(math.cos(0.5))
将输出：
0.87758256189037]],
			pos = 1
		},
		{	name = "math.deg",
			title = "弧度转角度",
			description = [[声明
	y = math.deg(x)

参数及返回值
	x 
		实数型，源数字
	y 
		实数型，返回弧度 x 对应的角度

说明
	将角 x 从弧度转换为角度。

示例
print(math.deg(3.1415926535))
print(math.deg(math.pi))
将输出：
179.99999999486
180.0]],
			pos = 1
		},
		{	name = "math.floor",
			title = "向下取整",
			description = [[声明
	y = math.floor(x)

参数及返回值
	x 
		实数型，源数字
	y 
		整数型，返回不大于 x 的最大整数值

说明
	返回不大于 x 的最大整数值。

示例
print(math.ceil(0.5))
print(math.ceil(1))
将输出：
0
1]],
			pos = 1
		},
		{	name = "math.fmod",
			title = "取模运算",
			description = [[math.fmod (x, y)
返回 x 除以 y，将商向零圆整后的余数。 (integer/float)]],
			pos = 1
		},
		{	name = "math.huge",
			title = "最大数值",
			description = [[math.huge

浮点数 HUGE_VAL， 这个数比任何数字值都大。]],
			pos = 1
		},
		{	name = "math.log",
			title = "取对数",
			description = [[math.log (x [, base])

返回以指定底的 x 的对数。 默认的 base 是 e （因此此函数返回 x 的自然对数）。]],
			pos = 1
		},
		{	name = "math.max",
			title = "取最大值",
			description = [[math.max (x, ···)

返回参数中最大的值， 大小由 Lua 操作 < 决定。 (integer/float)]],
			pos = 1
		},
		{	name = "math.maxinteger",
			title = "最大值的整数",
			description = [[math.maxinteger

最大值的整数。]],
			pos = 1
		},
		{	name = "math.min",
			title = "取最小值",
			description = [[math.min (x, ···)

返回参数中最小的值， 大小由 Lua 操作 < 决定。 (integer/float)]],
			pos = 1
		},
		{	name = "math.mininteger",
			title = "最小值的整数",
			description = [[math.mininteger

最小值的整数。]],
			pos = 1
		},
		{	name = "math.modf",
			title = "整数小数分离",
			description = [[math.modf (x)

返回 x 的整数部分和小数部分。 第二个结果一定是浮点数。]],
			pos = 1
		},
		{	name = "math.pi",
			title = "π",
			description = [[math.pi

π 的值。]],
			package = "",
		},
		{	name = "math.rad",
			title = "角度转弧度",
			description = [[math.rad (x)

将角 x 从角度转换为弧度。]],
			pos = 1
		},
		{	name = "math.random",
			title = "生成伪随机数",
			description = [=[math.random ([m [, n] ])

当不带参数调用时， 返回一个 [0,1] 区间内一致分布的浮点伪随机数。 当以两个整数 m 与 n 调用时， math.random 返回一个 [m, n] 区间 内一致分布的整数伪随机数。 （值 m-n 不能是负数，且必须在 Lua 整数的表示范围内。） 调用 math.random(n) 等价于 math.random(1,n)。

这个函数是对 C 提供的位随机数函数的封装。 对其统计属性不作担保。]=],
			pos = 1
		},
		{	name = "math.randomseed",
			title = "设置随机种子",
			description = [[math.randomseed (x)

把 x 设为伪随机数发生器的“种子”： 相同的种子产生相同的随机数列。]],
			pos = 1
		},
		{	name = "math.sin",
			title = "取正弦",
			description = [[math.sin (x)

返回 x 的正弦值（假定参数是弧度）。]],
			pos = 1
		},
		{	name = "math.sqrt",
			title = "取平方根",
			description = [[math.sqrt (x)

返回 x 的平方根。 （你也可以使用乘方 x^0.5 来计算这个值。）]],
			pos = 1
		},
		{	name = "math.tan",
			title = "取正切",
			description = [[math.tan (x)

返回 x 的正切值（假定参数是弧度）。]],
			pos = 1
		},
		{	name = "math.tointeger",
			title = "转换值为整数",
			description = [[math.tointeger (x)

如果 x 可以转换为一个整数， 返回该整数。 否则返回 nil。]],
			pos = 1
		},
		{	name = "math.type",
			title = "取数值类型",
			description = [[math.type (x)

如果 x 是整数，返回 "integer"， 如果它是浮点数，返回 "float"， 如果 x 不是数字，返回 nil。]],
			pos = 1
		},
		{	name = "math.ult",
			title = "无符号小于比较",
			description = [[math.ult (m, n)

如果整数 m 和 n 以无符号整数形式比较， m 在 n 之下，返回布尔真否则返回假。]],
			pos = 1
		},
	},
	{	name = "输入输出库",
		{	name = "io.close",
			title = "关闭输出句柄",
			description = [[io.close ([file])

等价于 file:close()。 不给出 file 时将关闭默认输出文件。]],
			pos = 1
		},
		{	name = "io.flush",
			title = "清空输出缓冲",
			description = [[io.flush ()

等价于 io.output():flush()。]],
			pos = 1
		},
		{	name = "io.input",
			title = "输入重定向",
			description = [[io.input ([file])

用文件名调用它时，（以文本模式）来打开该名字的文件， 并将文件句柄设为默认输入文件。 如果用文件句柄去调用它， 就简单的将该句柄设为默认输入文件。 如果调用时不传参数，它返回当前的默认输入文件。

在出错的情况下，函数抛出错误而不是返回错误码。]],
			pos = 1
		},
		{	name = "io.lines",
			title = "逐行输入",
			description = [[io.lines ([filename ···])

以读模式打开指定的文件名并返回一个迭代函数。 此迭代函数的工作方式和用一个已打开的文件去调用 file:lines(···) 得到的迭代器相同。 当迭代函数检测到文件结束， 它不返回值（让循环结束）并自动关闭文件。

调用 io.lines() （不传文件名） 等价于 io.input():lines("*l")； 即，它将按行迭代标准输入文件。 在此情况下，循环结束后它不会关闭文件。

在出错的情况下，函数抛出错误而不是返回错误码。]],
			pos = 1
		},
		{	name = "io.open",
			title = "打开文件",
			description = [[io.open (filename [, mode])

这个函数用字符串 mode 指定的模式打开一个文件。 返回新的文件句柄。 当出错时，返回 nil 加错误消息。

mode 字符串可以是下列任意值：

"r": 读模式（默认）；
"w": 写模式；
"a": 追加模式；
"r+": 更新模式，所有之前的数据都保留；
"w+": 更新模式，所有之前的数据都删除；
"a+": 追加更新模式，所有之前的数据都保留，只允许在文件尾部做写入。
mode 字符串可以在最后加一个 'b' ， 这会在某些系统上以二进制方式打开文件。]],
			pos = 1
		},
		{	name = "io.output",
			title = "输出重定向",
			description = [[io.output ([file])

类似于 io.input。 不过都针对默认输出文件操作。]],
			pos = 1
		},
		{	name = "io.popen",
			title = "管道执行命令行",
			description = [[io.popen (prog [, mode])

这个函数和系统有关，不是所有的平台都提供。

用一个分离进程开启程序 prog， 返回的文件句柄可用于从这个程序中读取数据 （如果 mode 为 "r"，这是默认值） 或是向这个程序写入输入（当 mode 为 "w" 时）。]],
			pos = 1
		},
		{	name = "io.read",
			title = "读出内容",
			description = [[io.read (···)

等价于 io.input():read(···)。]],
			pos = 1
		},
		{	name = "io.tmpfile",
			title = "获取一个临时文件句柄",
			description = [[io.tmpfile ()

返回一个临时文件的句柄。 这个文件以更新模式打开，在程序结束时会自动删除。]],
			pos = 1
		},
		{	name = "io.type",
			title = "取句柄类型",
			description = [[io.type (obj)

检查 obj 是否是合法的文件句柄。 如果 obj 它是一个打开的文件句柄，返回字符串 "file"。 如果 obj 是一个关闭的文件句柄，返回字符串 "closed file"。 如果 obj 不是文件句柄，返回 nil 。]],
			pos = 1
		},
		{	name = "io.write",
			title = "写入内容",
			description = [[io.write (···)

等价于 io.output():write(···)。]],
			pos = 1
		},
		{	name = "file:close",
			title = "关闭文件",
			description = [[file:close ()

关闭 file。 注意，文件在句柄被垃圾回收时会自动关闭， 但是多久以后发生，时间不可预期的。

当关闭用 io.popen 创建出来的文件句柄时， file:close 返回 os.execute 会返回的一样的值。]],
		},
		{	name = "file:flush",
			title = "清空文件缓冲",
			description = [[file:flush ()

将缓冲区数据立即保存到 file 中。]],
		},
		{	name = "file:lines",
			title = "从文件逐行输入",
			description = [[file:lines (···)

返回一个迭代器函数， 每次调用迭代器时，都从文件中按指定格式读数据。 如果没有指定格式，使用默认值 "l" 。 看一个例子

	 for c in file:lines(1) do body end
会从文件当前位置开始，中不断读出字符。 和 io.lines 不同， 这个函数在循环结束后不会关闭文件。

在出错的情况下，函数抛出错误而不是返回错误码。]],
			pos = 1
		},
		{	name = "file:read",
			title = "从文件读出内容",
			description = [[file:read (···)

读文件 file， 指定的格式决定了要读什么。 对于每种格式，函数返回读出的字符对应的字符串或数字。 若不能以该格式对应读出数据则返回 nil。 （对于最后这种情况， 函数不会读出后续的格式。） 当调用时不传格式，它会使用默认格式读下一行（见下面描述）。

提供的格式有

"n": 读取一个数字，根据 Lua 的转换文法，可能返回浮点数或整数。 （数字可以有前置或后置的空格，以及符号。） 只要能构成合法的数字，这个格式总是去读尽量长的串； 如果读出来的前缀无法构成合法的数字 （比如空串，"0x" 或 "3.4e-"）， 就中止函数运行，返回 nil。
"i": 读取一个整数，返回整数值。
"a": 从当前位置开始读取整个文件。 如果已在文件末尾，返回空串。
"l": 读取一行并忽略行结束标记。 当在文件末尾时，返回 nil 这是默认格式。
"L": 读取一行并保留行结束标记（如果有的话）， 当在文件末尾时，返回 nil。
number: 读取一个不超过这个数量字节数的字符串。 当在文件末尾时，返回 nil。 如果 number 为零， 它什么也不读，返回一个空串。 当在文件末尾时，返回 nil。
格式 "l" 和 "L" 只能用于文本文件。]],
			pos = 1
		},
		{	name = "file:seek",
			title = "设置文件读写位置",
			description = [==[file:seek ([whence [, offset]])

设置及获取基于文件开头处计算出的位置。 设置的位置由 offset 和 whence 字符串 whence 指定的基点决定。基点可以是：

"set": 基点为 0 （文件开头）；
"cur": 基点为当前位置了；
"end": 基点为文件尾；
当 seek 成功时，返回最终从文件开头计算起的文件的位置。 当 seek 失败时，返回 nil 加上一个错误描述字符串。

whence 的默认值是 "cur"， offset 默认为 0 。 因此，调用 file:seek() 可以返回文件当前位置，并不改变它； 调用 file:seek("set") 将位置设为文件开头（并返回 0）； 调用 file:seek("end") 将位置设到文件末尾，并返回文件大小。]==],
			pos = 1
		},
		{	name = "file:setvbuf",
			title = "设置文件缓冲模式",
			description = [[file:setvbuf (mode [, size])

设置输出文件的缓冲模式。 有三种模式：

"no": 不缓冲；输出操作立刻生效。
"full": 完全缓冲；只有在缓存满或当你显式的对文件调用 flush（参见 io.flush） 时才真正做输出操作。
"line": 行缓冲； 输出将到每次换行前， 对于某些特殊文件（例如终端设备）缓冲到任何输入前。
对于后两种情况，size 以字节数为单位 指定缓冲区大小。 默认会有一个恰当的大小。]],
			pos = 1
		},
		{	name = "file:write",
			title = "往文件写入内容",
			description = [[file:write (···)

将参数的值逐个写入 file。 参数必须是字符串或数字。

成功时，函数返回 file。 否则返回 nil 加错误描述字符串。]],
			pos = 1
		},
	},
	{	name = "操作系统库",
		{	name = "os.clock",
			title = "取时钟周期",
			description = [[os.clock ()

返回程序使用的按秒计 CPU 时间的近似值。]],
		},
		{	name = "os.date",
			title = "取日期",
			description = [==[os.date ([format [, time]])

返回一个包含日期及时刻的字符串或表。 格式化方法取决于所给字符串 format。

如果提供了 time 参数， 格式化这个时间 （这个值的含义参见 os.time 函数）。 否则，date 格式化当前时间。

如果 format 以 '!' 打头， 日期以协调世界时格式化。 在这个可选字符项之后， 如果 format 为字符串 "*t"， date 返回有后续域的表： year （四位数字），month （1–12），day （1–31）， hour （0–23），min （0–59），sec （0–61）， wday （星期几，星期天为 1 ）， yday （当年的第几天）， 以及 isdst （夏令时标记，一个布尔量）。 对于最后一个域，如果该信息不提供的话就不存在。

如果 format 并非 "*t"， date 以字符串形式返回， 格式化方法遵循 ISO C 函数 strftime 的规则。

如果不传参数调用， date 返回一个合理的日期时间串， 格式取决于宿主程序以及当前的区域设置 （即，os.date() 等价于 os.date("%c")）。

在非 POSIX 系统上， 由于这个函数依赖 C 函数 gmtime 和 localtime， 它可能并非线程安全的。


%Y-%m-%d %H:%M:%S	os.date("%Y-%m-%d %H:%M:%S", 1487356783)	一种常用日期时间格式	2017-02-18 02:39:43
%Y-%m-%d	os.date("%Y-%m-%d", 1487356783)	一种常用日期格式	2017-02-18
%a	os.date("%a", 1487356783)	短星期名	Sat
%A	os.date("%A", 1487356783)	全星期名	Saturday
%b	os.date("%b", 1487356783)	简写的月份名	Feb
%B	os.date("%B", 1487356783)	月份的全称	February
%c	os.date("%c", 1487356783)	标准的日期的时间串	Sat Feb 18 02:39:43 2017
%d	os.date("%d", 1487356783)	月的天[01-31]	18
%H	os.date("%H", 1487356783)	24小时制的时[00-23]	02
%I	os.date("%I", 1487356783)	12小时制的时[01-12]	02
%j	os.date("%j", 1487356783)	年的天[001-366]	049
%M	os.date("%M", 1487356783)	分钟[00-59]	39
%m	os.date("%m", 1487356783)	月份[01-12]	02
%p	os.date("%p", 1487356783)	上午AM 下午PM	AM
%S	os.date("%S", 1487356783)	秒钟[00-61]	43
%w	os.date("%w", 1487356783)	星期几（星期日为0）[0-6]	6
%x	os.date("%x", 1487356783)	标准的日期串	02/18/17
%X	os.date("%X", 1487356783)	标准的时间串	02:39:43
%y	os.date("%y", 1487356783)	不带世纪的年份	17
%Y	os.date("%Y", 1487356783)	带世纪部分的年份	2017
%%	os.date("%%", 1487356783)	百分号	%

]==],
			pos = 1
		},
		{	name = "os.difftime",
			title = "取俩时间差",
			description = [[os.difftime (t2, t1)

返回以秒计算的时刻 t1 到 t2 的差值。 （这里的时刻是由 os.time 返回的值）。 在 POSIX，Windows，和其它一些系统中，这个值就等于 t2-t1。]],
			pos = 1
		},
		{	name = "os.execute",
			title = "执行命令行",
			description = [[os.execute ([command])

这个函数等价于 ISO C 函数 system。 它调用系统解释器执行 command。 如果命令成功运行完毕，第一个返回值就是 true， 否则是 nil otherwise。 在第一个返回值之后，函数返回一个字符串加一个数字。如下：

"exit": 命令正常结束； 接下来的数字是命令的退出状态码。
"signal": 命令被信号打断； 接下来的数字是打断该命令的信号。
如果不带参数调用， os.execute 在系统解释器存在的时候返回真。]],
			pos = 1
		},
		{	name = "os.getenv",
			title = "取环境变量",
			description = [[os.getenv (varname)

返回进程环境变量 varname 的值， 如果该变量未定义，返回 nil 。]],
			pos = 1
		},
		{	name = "os.remove",
			title = "删除文件",
			description = [[os.remove (filename)

删除指定名字的文件（在 POSIX 系统上可以是一个空目录） 如果函数失败，返回 nil 加一个错误描述串及出错码。]],
			pos = 1
		},
		{	name = "os.rename",
			title = "移动或更改文件名",
			description = [[os.rename (oldname, newname)

将名字为 oldname 的文件或目录更名为 newname。 如果函数失败，返回 nil 加一个错误描述串及出错码。]],
			pos = 1
		},
		{	name = "os.setlocale",
			title = "设置程序区域信息",
			description = [[os.setlocale (locale [, category])

设置程序的当前区域。 locale 是一个区域设置的系统相关字符串； category 是一个描述有改变哪个分类的可选字符串： "all"，"collate"， "ctype"， "monetary"， "numeric"， 或 "time"； 默认的分类为 "all"。 此函数返回新区域的名字。 如果请求未被获准，返回 nil 。

当 locale 是一个空串， 当前区域被设置为一个在实现中定义好的本地区域。 当 locale 为字符串 "C"， 当前区域被设置为标准 C 区域。

当第一个参数为 nil 时， 此函数仅返回当前区域指定分类的名字。

由于这个函数依赖 C 函数 setlocale， 它可能并非线程安全的。]],
			pos = 1
		},
		{	name = "os.time",
			title = "取 UNIX 秒级时间戳",
			description = [[os.time ([table])

当不传参数时，返回当前时刻。 如果传入一张表，就返回由这张表表示的时刻。 这张表必须包含域 year，month，及 day； 可以包含有　hour （默认为 12 ）， min （默认为 0）， sec （默认为 0），以及 isdst （默认为 nil）。 关于这些域的详细描述，参见 os.date 函数。

返回值是一个含义由你的系统决定的数字。 在 POSIX，Windows，和其它一些系统中， 这个数字统计了从指定时间（"epoch"）开始经历的秒数。 对于另外的系统，其含义未定义， 你只能把 time 的返回数字用于 os.date 和 os.difftime 的参数。]],
			pos = 1
		},
		{	name = "os.tmpname",
			title = "获取一个临时文件名",
			description = [[os.tmpname ()

返回一个可用于临时文件的文件名字符串。 这个文件在使用前必须显式打开，不再使用时需要显式删除。

在 POSIX 系统上， 这个函数会以此文件名创建一个文件以回避安全风险。 （别人可能未经允许在获取到这个文件名到创建该文件之间的时刻创建此文件。） 你依旧需要在使用它的时候先打开，并最后删除（即使你没使用到）。

只有有可能，你更应该使用 io.tmpfile， 因为该文件可以在程序结束时自动删除。]],
		},
	},
	{	name = "调试库",
		description = [[这个库提供了 Lua 程序调试接口（§4.9）的功能。 其中一些函数违反了 Lua 代码的基本假定 （例如，不会从函数之外访问函数的局部变量； 用户数据的元表不会被 Lua 代码修改； Lua 程序不会崩溃）， 因此它们有可能危害到其它代码的安全性。 此外，库里的一些函数可能运行的很慢。

这个库里的所有函数都提供在表 debug 内。 所有操作线程的函数，可选的第一个参数都是针对的线程。 默认值永远是当前线程。]],
		{	name = "debug.debug",
			title = "用户交互模式调试",
			description = [[debug.debug ()

进入一个用户交互模式，运行用户输入的每个字符串。 使用简单的命令以及其它调试设置，用户可以检阅全局变量和局部变量， 改变变量的值，计算一些表达式，等等。 输入一行仅包含 cont 的字符串将结束这个函数， 这样调用者就可以继续向下运行。

注意，debug.debug 输入的命令在文法上并没有内嵌到任何函数中， 因此不能直接去访问局部变量。]],
		},
		{	name = "debug.gethook",
			title = "取调试钩子",
			description = [[debug.gethook ([thread])

返回三个表示线程钩子设置的值： 当前钩子函数，当前钩子掩码，当前钩子计数 （debug.sethook 设置的那些）。]],
			pos = 1
		},
		{	name = "debug.getinfo",
			title = "调试取当前函数信息",
			description = [[debug.getinfo ([thread,] f [, what])

返回关于一个函数信息的表。 你可以直接提供该函数， 也可以用一个数字 f 表示该函数。 数字 f 表示运行在指定线程的调用栈对应层次上的函数： 0 层表示当前函数（getinfo 自身）； 1 层表示调用 getinfo 的函数 （除非是尾调用，这种情况不计入栈）；等等。 如果 f 是一个比活动函数数量还大的数字， getinfo 返回 nil。

只有字符串 what 中有描述要填充哪些项， 返回的表可以包含 lua_getinfo 能返回的所有项。 what 默认是返回提供的除合法行号表外的所有信息。 对于选项 'f' ，会在可能的情况下，增加 func 域保存函数自身。 对于选项 'L' ，会在可能的情况下，增加 activelines 域保存合法行号表。

例如,表达式 debug.getinfo(1,"n") 返回带有当前函数名字信息的表（如果找的到名字的话）， 表达式 debug.getinfo(print) 返回关于 print 函数的 包含有所有能提供信息的表。]],
			pos = 1
		},
		{	name = "debug.getlocal",
			title = "调试取局部变量信息",
			description = [[debug.getlocal ([thread,] f, local)

此函数返回在栈的 f 层处函数的索引为 local 的局部变量 的名字和值。 这个函数不仅用于访问显式定义的局部变量，也包括形参、临时变量等。

第一个形参或是定义的第一个局部变量的索引为 1 ， 然后遵循在代码中定义次序，以次类推。 其中只计算函数当前作用域的活动变量。 负索引指可变参数； -1 指第一个可变参数。 如果该索引处没有变量，函数返回 nil。 若指定的层次越界，抛出错误。 （你可以调用 debug.getinfo 来检查层次是否合法。）

以 '(' （开括号）打头的变量名表示没有名字的变量 （比如是循环控制用到的控制变量， 或是去除了调试信息的代码块）。

参数 f 也可以是一个函数。 这种情况下，getlocal 仅返回函数形参的名字。]],
			pos = 1
		},
		{	name = "debug.getmetatable",
			title = "调试取元表",
			description = [[debug.getmetatable (value)

返回给定 value 的元表。 若其没有元表则返回 nil 。]],
			pos = 1
		},
		{	name = "debug.getregistry",
			title = "调试取注册表",
			description = [[debug.getregistry ()

返回注册表（参见 §4.5）。]],
		},
		{	name = "debug.getupvalue",
			title = "调试取上值",
			description = [[debug.getupvalue (f, up)

此函数返回函数 f 的第 up 个上值的名字和值。 如果该函数没有那个上值，返回 nil 。

以 '(' （开括号）打头的变量名表示没有名字的变量 （去除了调试信息的代码块）。]],
			pos = 1
		},
		{	name = "debug.getuservalue",
			title = "调试取用户关联值",
			description = [[debug.getuservalue (u)

返回关联在 u 上的 Lua 值。 如果 u 并非用户数据，返回 nil。]],
			pos = 1
		},
		{	name = "debug.sethook",
			title = "调试设置钩子",
			description = [[debug.sethook ([thread,] hook, mask [, count])

将一个函数作为钩子函数设入。 字符串 mask 以及数字 count 决定了钩子将在何时调用。 掩码是由下列字符组合成的字符串，每个字符有其含义：

	'c': 每当 Lua 调用一个函数时，调用钩子；
	'r': 每当 Lua 从一个函数内返回时，调用钩子；
	'l': 每当 Lua 进入新的一行时，调用钩子。
此外， 传入一个不为零的 count ， 钩子将在每运行 count 条指令时调用。

如果不传入参数， debug.sethook 关闭钩子。

当钩子被调用时， 第一个参数是触发这次调用的事件： "call" （或 "tail call"）， "return"， "line"， "count"。 对于行事件， 钩子的第二个参数是新的行号。 在钩子内，你可以调用 getinfo ，指定第 2 层， 来获得正在运行的函数的详细信息 （0 层指 getinfo 函数， 1 层指钩子函数）。]],
			pos = 1
		},
		{	name = "debug.setlocal",
			title = "调试设置局部变量值",
			description = [[debug.setlocal ([thread,] level, local, value)

这个函数将 value 赋给 栈上第 level 层函数的第 local 个局部变量。 如果没有那个变量，函数返回 nil 。 如果 level 越界，抛出一个错误。 （你可以调用 debug.getinfo 来检查层次是否合法。） 否则，它返回局部变量的名字。

关于变量索引和名字，参见 debug.getlocal。]],
			pos = 1
		},
		{	name = "debug.setmetatable",
			title = "调试设置元表",
			description = [[debug.setmetatable (value, table)

将 value 的元表设为 table （可以是 nil）。 返回 value。]],
			pos = 1
		},
		{	name = "debug.setupvalue",
			title = "调试设置上值",
			description = [[debug.setupvalue (f, up, value)

这个函数将 value 设为函数 f 的第 up 个上值。 如果函数没有那个上值，返回 nil 否则，返回该上值的名字。]],
			pos = 1
		},
		{	name = "debug.setuservalue",
			title = "调试设置用户关联值",
			description = [[debug.setuservalue (udata, value)

将 value 设为 udata 的关联值。 udata 必须是一个完全用户数据。

返回 udata。]],
			pos = 1
		},
		{	name = "debug.traceback",
			title = "调试取调用栈信息",
			description = [==[debug.traceback ([thread,] [message [, level]])

如果 message 有，且不是字符串或 nil， 函数不做任何处理直接返回 message。 否则，它返回调用栈的栈回溯信息。 字符串可选项 message 被添加在栈回溯信息的开头。 数字可选项 level 指明从栈的哪一层开始回溯 （默认为 1 ，即调用 traceback 的那里）。]==],
			pos = 1
		},
		{	name = "debug.upvalueid",
			title = "调试取上值标识符",
			description = [[debug.upvalueid (f, n)

返回指定函数第 n 个上值的唯一标识符（一个轻量用户数据）。

这个唯一标识符可以让程序检查两个不同的闭包是否共享了上值。 若 Lua 闭包之间共享的是同一个上值 （即指向一个外部局部变量），会返回相同的标识符。]],
			pos = 1
		},
		{	name = "debug.upvaluejoin",
			title = "调试上值关联",
			description = [[debug.upvaluejoin (f1, n1, f2, n2)

让 Lua 闭包 f1 的第 n1 个上值 引用 Lua 闭包 f2 的第 n2 个上值。]],
			pos = 1
		},
	},
}