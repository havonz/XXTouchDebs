--[[--
  Use this file to specify **System** preferences.
  Review [examples](+F:\IDE\ZeroBrane-1.30-win32+XXTouch\cfg\user-sample.lua) or check [online documentation](http://studio.zerobrane.com/documentation.html) for details.
--]]--

local G = ...

stylesoutshell = styles -- apply the same scheme to Output/Console windows
styles.auxwindow = styles.text -- apply text colors to auxiliary windows
styles.calltip = styles.text -- apply text colors to tooltips

language = "zh-cn"						-- 软件语言 可选项在安装目录\cfg\i18n 中可以看到 如 en fr it chs 
editor.tabwidth = 4     				-- tab制表符的大小
editor.usetabs = true   				-- 缩进是用 tab 占位 还是 空格 占位 
editor.usewrap = false  				-- 自动换行
editor.foldcompact = false
editor.whitespace = false				-- 显示空格字符绘制点 和 制表符绘制箭头
editor.smartindent = true				-- 使用智能缩进。
editor.specmap.xui = 'lua'				-- xui 格式将会以 lua 的语法高亮显示

interpreter = "XXT"						-- 设置用于新项目的默认的翻译,值名称的字符串来设置使用解释器解释器的名字.
projecthistorylength = 10				-- 设置项目的历史长度
savebak = false							-- 创建备份文件保存
showhiddenfiles = false					-- 显示隐藏的文件
singleinstance = false					-- 使检查防止启动IDE的多个实例
showmemoryusage = false					-- 在状态栏（V1.11+）中显示内存使用状态；设置为true以显示统计信息。

-- Project/Filetree
filetree.fontname = nil					-- 设置字体名称；项目/ filetree窗口没有默认字体是系统依赖性。
filetree.fontsize = 10					-- 设置字体大小（默认大小为11在OSX）。
filetree.mousemove = true				-- 使用拖放filetree移动文件和目录（0.80）； 集假禁用。
filetree.showchanges = true				-- 文件系统中的跟踪和显示文件系统更改

-- Outline
outline.jumptocurrentfunction = true	-- 概述：滚动窗口的电流作用下光标（1.11）； 这个设置outline.showcurrentfunction要启用。
outline.showanonymous = '~'				-- 设置名称用于匿名函数（0.81）；设置假隐藏的匿名函数。
outline.showcompact = false				-- 设置轮廓显示只有一个级别的功能在默认情况下，这使得它对于大文件更紧凑（1.21）。
outline.showcurrentfunction = true		-- 突出显示当前函数在大纲窗口光标下（1.11）。
outline.showflat = false				-- 显示所有功能作为一个列表（没有层次）（0.91）。
outline.showmethodindicator = false		-- 方法：显示不同的图标为指标（0.81）。
outline.showonefile = false				-- 只显示从大纲中的当前活动文件的功能（0.81）； 集假显示与当前的概述几种文件扩展。
outline.sort = false					-- 按名称排序功能（0.91）； 集假按出现的顺序显示功能。

-- Search
search.autohide = false					-- 隐藏搜索面板后查找/替换操作（1.01）。
search.autocomplete = true				-- 使自我完整的政策建议：find / replace（1.01）领域。
search.contextlinesafter = 2			-- 背景：设置行数显示之后在搜索结果中匹配的行(1.01+).。
search.contextlinesbefore = 2			-- 背景：设置行数显示之前在搜索结果中匹配的行(1.01+).。
search.showaseditor = false				-- 显示在搜索结果旁边输出表（1.01）； 集真正的显示搜索结果作为一个编辑标签。
search.zoom = 0							-- 搜索结果：设置缩放级别（1.01）； 值设置为一个负值（从1到7）使结果较小或阳数（从1到7）使结果大于默认。

-- Static analyzer / 静态分析器
staticanalyzer.infervalue = true		-- 使静态分析推断值（0.96）。 这允许报告未知的附加字段，但需要更多的。

-- Auto-complete and tooltip / 自动完成和工具提示
acandtip.droprest = true
acandtip.fillups = nil
acandtip.ignorecase = false
acandtip.nodynwords = false
acandtip.shorttip = false
acandtip.startat = 2
autocomplete = true

-- File exclusion lists / 文件排除列表
--[[
excludelist = {							-- 设置IDE（V1.10+）的任何处理中要排除的文件列表。这些文件和目录不会显示在项目树中，不会被搜索。在使用文件打开和类似操作直接打开时，它们仍然可以在IDE中打开。
	[".svn/"] = true,
	[".git/"] = true,
	[".hg/"] = true,
	["CVS/"] = true,
	["*.pyc"] = true,
	["*.pyo"] = true,
	["*.exe"] = true,
	["*.dll"] = true,
	["*.obj"] = true,
	["*.o"] = true,
	["*.a"] = true,
	["*.lib"] = true,
	["*.so"] = true,
	["*.dylib"] = true,
	["*.ncb"] = true,
	["*.sdf"] = true,
	["*.suo"] = true,
	["*.pdb"] = true,
	["*.idb"] = true,
	[".DS_Store"] = true,
	["*.class"] = true,
	["*.psd"] = true,
	["*.db"] = true
}
--]]

binarylist = {							-- 设置要被识别为二进制文件（V1.10+）的文件列表。这些文件显示在Project树中，但将跳过Fuzzy搜索和查找和替换文件操作。
	["*.jpg"] = true,
	["*.jpeg"] = true,
	["*.png"] = true,
	["*.gif"] = true,
	["*.ttf"] = true,
	["*.tga"] = true,
	["*.dds"] = true,
	["*.ico"] = true,
	["*.eot"] = true,
	["*.pdf"] = true,
	["*.swf"] = true,
	["*.jar"] = true,
	["*.zip"] = true,
	["*.gz"] = true,
	["*.rar"] = true,
	["*.xxt"] = true,
	["*.xuic"] = true
}
