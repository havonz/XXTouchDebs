--[[
	Windows 版 XXTStudio 放到 XXTStudio 程序根目录的 packages/snippets/ 目录下
	macOS 上放到 /Applications/XXTStudio.app/Contents/ZeroBraneStudio/packages/snippets/ 目录下
--]]

return {	name = "Lua 常用语法块",
	description = [[
这里有一些常用的语法块片段
]],

	{	name = "local",
		title = "声明局部变量",
		description = [[
local 光标位置

声明一个名为 [光标位置] 的局部变量
]],
		code = [[
local ${name}]]
	},

	{	name = "if then end",
		title = "插入 if 块",
		description = [[
if (光标位置) then
选中内容
end

当 [光标位置] 的条件成立时，将会执行 [选中内容] 的代码
]],
		code = [[
if (${true}) then
${body}
end]]
	},

	{	name = "elseif then",
		title = "插入 elseif 块",
		description = [[
elseif (光标位置) then
选中内容

否则当 [光标位置] 的条件成立时，将会执行 [选中内容] 的代码
]],
		code = [[
elseif (${true}) then
${body}
]]
	},

	{	name = "else",
		title = "插入 else 块",
		description = [[
else
选中内容

否则将会执行 [选中内容] 的代码
]],
		code = [[
else
${body}
]]
	},

	{	name = "for i=1,n do",
		title = "插入 for 循环块",
		description = [[
for i=1, 光标位置 do
选中内容
end

使 [选中内容] 循环执行 [光标位置] 次
i 为当前执行索引
]],
		code = [[
for i=1, ${5} do
${body}
end]]
	},

	{	name = "for in ipairs",
		title = "插入顺序遍历",
		description = [[
for i,v in ipairs(光标位置) do
选中内容
end

顺序遍历 [光标位置] 的表，并对于表中的每一个元素执行 [选中内容]
i 为元素在表中的位置
v 为元素本体
此方法只会遍历连续的顺序表，也就是表中元素的索引为从 1 开始的数字
]],
		code = [[
for i,v in ipairs(${tab}) do
${body}
end]]
	},

	{	name = "for in pairs",
		title = "插入哈希遍历",
		description = [[
for k,v in pairs(光标位置) do
选中内容
end

哈希遍历 [光标位置] 的表，并对于表中的每一个元素执行 [选中内容]
k 为元素在表中的索引
v 为元素本体
此方法是乱序遍历
]],
		code = [[
for k,v in pairs(${tab}) do
${body}
end]]
	},

	{	name = "while do end",
		title = "插入 while 块",
		description = [[
while (光标位置) do
选中内容
end

如果 [光标位置] 条件成立，则执行一次 [选中内容]
然后再判断 [光标位置] 如果再次成立，则再次执行
直至 [光标位置] 条件不成立结束
]],
		code = [[
while (${true}) do
${body}
end]]
	},

	{	name = "repeat until",
		title = "插入 repeat until 块",
		description = [[
repeat
选中内容
until (光标位置)

执行一次 [选中内容]
然后再判断 [光标位置] 若不成立，则再次执行 [选中内容]
直至 [光标位置] 条件成立结束
]],
		code = [[
repeat
${body}
until (${false})]]
	},

	{	name = "do end",
		title = "插入 do 块",
		description = [[
do
选中内容
end

在一个子代码块中执行 [选中内容]
自代码块中的 local 局部变量对该代码块以外的位置不可见
]],
		code = [[
do
${body}
end]]
	},

	{	name = "function end",
		title = "插入 function 块",
		description = [[
function 光标位置(...)
选中内容
end

定义一个函数名为 [光标位置] 的全局函数
]],
		code = [[
function ${name}(...)
${body}
end]]
	},

	{	name = "local function end",
		title = "插入 local function 块",
		description = [[
local function 光标位置(...)
选中内容
end

定义一个函数名为 [光标位置] 的局部函数
]],
		code = [[
local function ${name}(...)
${body}
end]]
	},
}