return {	name = "_Do 模块",
	description = [[框架描述：
基于Lua与XXTouch，制作便于开发“游戏”、“app”等批操作的简单框架。
_Do拟人判断方式以“多点满足条件则”方法尽心构架，处理操作流程使用keep方式超快速进行遍历所有条件。
此框架并不一定适用于所有操作。

以人工处理逻辑进行操作（看到什么操作什么）
逻辑 与 参数分离（_Do成型模块 只需要传递入 table参数）
超时、重复 等问题加入判断逻辑便于操作
单纯单线程实现整个逻辑处理

]],
	{	name = "_Do",
		title = "运行库加载",
		description = [[插入 _Do 运行库
此处必须提前声明否则 _Do 操作可能不存在此函数
]],
		code = [[local _Do = function(_tab, b_debug)
	-- 判断是否传入的是正确内容
	local check_table
	check_table = function(t)
		if type(t) ~= 'table' then error('传入非table内容',3) end
		if #t == 0 then error('传入table无数据',3) end
		if not (type(t.csim) == 'number' or type(t.csim) == 'nil') then error('相似度数值不正确',3) end
		if not (
			(
				type(t.Repeat) == 'table' and
				type(t.Repeat.n) == 'number' and
				type(t.Repeat.Run) == 'function'
			) or
			type(t.Repeat) == 'nil'
			) then
			error('Repeat 参数不正确',3)
		end
		if not (
			(
				type(t.timeout) == 'table' and
				type(t.timeout.n) == 'number' and
				type(t.timeout.Run) == 'function'
			) or
			type(t.timeout) == 'nil'
			) then
			error('timeout 参数不正确',3)
		end
		for n, v in ipairs(t) do
			if not (
				type(v.Name) == 'string' and 
				type(v.Color) == 'table' and 
				type(v.Run) == 'function' and
				(type(v.csim) == 'number' or type(v.csim) == 'nil') and
				(type(v.layer) == 'table' or type(v.layer) == 'nil')
				) then
				error(string.format("传入table第%d项不正确",n),3)
			else
				for _n, _v in ipairs(v.Color) do
					if not (
						type(_v[1]) == 'number' and
						type(_v[2]) == 'number' and
						type(_v[3]) == 'number'
						) then
						error(string.format("传入table第%d项内点色第%d项不正确",n,_n),3)
					end
				end
				if type(v.layer) == 'table' then
					check_table(v.layer)
				end
			end
		end
	end
	check_table(_tab)
	local _log = function() end
	if type(b_debug) == "function" then
		_log = b_debug
	elseif b_debug then
		_log = function(...) nLog(...) end
	else
	end
	-- 对全局 DoName 进行赋值 当前处理的 框架
	if type(_G.DoName) == "table" then
		table.insert(DoName,_tab.Name)
	else
		_G.DoName = {_tab.Name}
	end
	if type(_tab.Begin) == "function" then
		_tab.Begin()
	end
	local _now = os.time()
	local _break = false
	local _Repeat = false
	-- 初始化 重复 计时值
	for _key,_value in ipairs(_tab) do
		_value.RepeatTime = os.time()
	end
	while true do
		--满足状态的 key 会缓存至这里
		local _States = {}
		--寻找满足状态的项
		screen.keep()
		for _key,_value in ipairs(_tab) do
			if screen.is_colors(_value.Color, _value.csim or _tab.csim) then
				_log(_value.Name, "发现")
				table.insert(_States,_key)
				--检测重复
				if _tab.Repeat then
					if os.time() - _value.RepeatTime >= _tab.Repeat.n then
						_value.RepeatTime = os.time()
						if not _value.NoRepeat then
							_log(_value.Name, "重复")
							_Repeat = true
						end
					end
				end
			else
				_value.RepeatTime = os.time()
			end
		end
		screen.unkeep()
		--超时判断
		if #_States == 0 then
			if _tab.timeout then
				if os.time() - _now >= _tab.timeout.n then
					_log(_tab.Name, "超时")
					if _tab.timeout.Run(_tab.timeout) then
						break
					end
					if _tab.timeout.layer then
						_Do(_tab.timeout.layer)
					end
					_now = os.time()
				end
			end
		else
			--执行满足状态的项
			for _key,_value in ipairs(_States) do
				local _Handle = _tab[_value]
				_log(_Handle.Name, "执行")
				if _Handle.Run then
					if _Handle.Run(_Handle) then
						_break = true
					end
				end
				if _Handle.layer then
					_Do(_Handle.layer)
				end
				_now = os.time()
			end
			if _break then break end
			if _Repeat then
				if _tab.Repeat.Run(_tab.Repeat) then
					break
				end
				_Repeat=false
			end
		end
		sys.msleep(_tab.sleep or 500)
	end
	if type(_tab.End) == "function" then
		_tab.End()
	end
	-- 对全局 DoName 进行剔除 已处理的 框架
	if type(_G.DoName) == 'table' then
		if #(_G.DoName) > 0 then
			table.remove(_G.DoName,#DoName)
		end
	end
end
]]
	},
	{	name = "构建表",
		{	name = "_Do",
			title = "母表",
			code = [==[local _tab = {
	Name = '主流程',
	{	
		Name = '子表名称',
		Color = {
			--[[此处为检测判断]]

		},
		Run = (function(et)
			--[[此处为执行内容]]

		end)
	},
	Repeat = {
		n = 30,
		Run = (function(et)
			--[[重复30秒内检测到相同内容]]
			
		end),
	},
	timeout = {
		n = 60,
		Run = (function(et)
			--[[60秒内未检测到任何内容]]

		end),
	},
	Begin = (function()
		--[[进入框架前运行]]

	end),
	End = (function()
		--[[退出框架前运行]]

	end),
	sleep = 800,	--[[检测速度间隔800毫秒]]
	csim = 90		--[[相似度统一为90]]
}
]==]
		},
		{	name = "_Do",
			title = "子表",
			code = [==[
	{	
		Name = '子表名称',
		Color = {
			--[[此处为检测判断]]

		},
		Run = (function(et)
			--[[此处为执行内容]]

		end)
	},]==]
		},
	},
	{	name = "_Do",
		title = "加载框架",
		code = "_Do(_tab)"
	},
}