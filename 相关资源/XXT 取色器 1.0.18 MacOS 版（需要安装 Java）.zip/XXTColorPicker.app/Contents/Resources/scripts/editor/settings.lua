return {
    font = "Monospaced",
    fontSize = 14,
    tabSize = 4,
    autoIndent = true,
    codeFolding = true,
    bracketMatching = true,
}