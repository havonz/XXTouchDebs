
require("scripts.colorpicker.keymap_tools")
local VK = require("scripts.virtual_keycodes")

-- On Key Pressed
local SK_PRESS_ = {
    [ VK["{A}"		] ] = posToRegA, -- On A Pressed
    [ VK["{S}"		] ] = posToRegS,
    [ VK["{X}"		] ] = posToRegX,
    [ VK["{C}"		] ] = posToRegC,
    [ VK["{D}"		] ] = copyRectAS,
    [ VK["{Z}"		] ] = clearAllColorRegisters,
    [ VK["{F}"		] ] = makeScripts,
    [ VK["{W}"		] ] = reloadPasteboard,
    [ VK["{J}"		] ] = viewRotateLeft,
    [ VK["{K}"		] ] = viewRotateRight,
    [ VK["{UP}"		] ] = moveMouseUp,
    [ VK["{DOWN}"	] ] = moveMouseDown,
    [ VK["{LEFT}"	] ] = moveMouseLeft,
    [ VK["{RIGHT}"	] ] = moveMouseRight,
    [ VK["{NEWLINE}"] ] = pickToNextColorRegister,
    [ VK["{RETURN}"	] ] = pickToNextColorRegister,
    [ VK["{E}"		] ] = x_AS_XC,
    [ VK["{R}"		] ] = repickColor,
    [ VK["{M}"		] ] = movePosList,
}

for i=0,9 do
    SK_PRESS_[ VK["{"..(i).."}"] ] = function()
        pickToColorRegister(i)
    end
end

-- On Shift + Key Pressed
local SK_SHIFT_ = {
    [ VK["{A}"		] ] = moveMouseToPosOfRegA, -- Shift + A
    [ VK["{S}"		] ] = moveMouseToPosOfRegS,
    [ VK["{X}"		] ] = moveMouseToPosOfRegX,
    [ VK["{C}"		] ] = moveMouseToPosOfRegC,
    [ VK["{D}"		] ] = copyRectXC,
    [ VK["{UP}"		] ] = moveMouseUp,
    [ VK["{DOWN}"	] ] = moveMouseDown,
    [ VK["{LEFT}"	] ] = moveMouseLeft,
    [ VK["{RIGHT}"	] ] = moveMouseRight,
    [ VK["{E}"		] ] = eraseRectAS,
    [ VK["{R}"		] ] = loadPosColorsText,
}

for i=0,9 do
    SK_SHIFT_[ VK["{"..(i).."}"] ] = function()
        clearColorRegisterByIndex(i)
    end
end

-- On Ctrl + Key Pressed
local SK_CTRL_ = {
    [ VK["{UP}"		] ] = function(isMac)
        if not isMac then
            moveMouseUp10()
        end
    end,
    [ VK["{DOWN}"	] ] = function(isMac)
        if not isMac then
            moveMouseDown10()
        end
    end,
    [ VK["{LEFT}"	] ] = function(isMac)
        if not isMac then
            moveMouseLeft10()
        end
    end,
    [ VK["{RIGHT}"	] ] = function(isMac)
        if not isMac then
            moveMouseRight10()
        end
    end,
    [ VK["{W}"      ] ] = function(isMac)
        if not isMac then
            closeCurrentImageTab()
        end
    end,
    [ VK["{C}"		] ] = function(isMac)
        if not isMac then
            copyASRectOrCopyWholeImage()
        end
    end,
    [ VK["{V}"		] ] = function(isMac)
        if not isMac then
            openPasteboardImageInNewTab()
        end
    end,
}

-- On Meta + Key Pressed
local SK_META_ = {
    [ VK["{UP}"		] ] = function(isMac)
        if isMac then
            moveMouseUp10()
        end
    end,
    [ VK["{DOWN}"	] ] = function(isMac)
        if isMac then
            moveMouseDown10()
        end
    end,
    [ VK["{LEFT}"	] ] = function(isMac)
        if isMac then
            moveMouseLeft10()
        end
    end,
    [ VK["{RIGHT}"	] ] = function(isMac)
        if isMac then
            moveMouseRight10()
        end
    end,
    [ VK["{W}"      ] ] = function(isMac)
        if isMac then
            closeCurrentImageTab()
        end
    end,
    [ VK["{C}"		] ] = function(isMac)
        if isMac then
            copyASRectOrCopyWholeImage()
        end
    end,
    [ VK["{V}"		] ] = function(isMac)
        if isMac then
            openPasteboardImageInNewTab()
        end
    end,
}

-- On Alt + Key Pressed
local SK_ALT_ = {

}

-- On Ctrl + Shift + Key Pressed
local SK_CTRL_SHIFT_ = {

}

-- On Ctrl + Alt + Key Pressed
local SK_CTRL_ALT_ = {

}

-- On Alt + Shift + Key Pressed
local SK_ALT_SHIFT_ = {

}

-- On Ctrl + Alt + Shift + Key Pressed
local SK_CTRL_ALT_SHIFT_ = {

}

-- On Shift + Meta + Key Pressed
local SK_SHIFT_META_ = {

}

-- On Ctrl + Meta + Key Pressed
local SK_CTRL_META_ = {

}

-- On Alt + Meta + Key Pressed
local SK_ALT_META_ = {

}

-- On Ctrl + Shift + Meta + Key Pressed
local SK_CTRL_SHIFT_META_ = {

}

-- On Ctrl + Alt + Meta + Key Pressed
local SK_CTRL_ALT_META_ = {

}

-- On Alt + Shift + Meta + Key Pressed
local SK_ALT_SHIFT_META_ = {

}

-- On Ctrl + Alt + Shift + Meta + Key Pressed
local SK_CTRL_ALT_SHIFT_META_ = {

}

-- On PosColor Register Key Pressed
local PCREG_PRESSED_ = {
    [ VK["{SPACE}"      ] ] = function(pc, idx, event)
        local x, y = pc:getX(), pc:getY()
        if x >= 0 and y >= 0 then
            moveMouseToXY(x, y)
        end
    end,
}

return {
    SK_PRESS_,
    SHIFT = SK_SHIFT_,
    CTRL = SK_CTRL_,
    ALT = SK_ALT_,
    CTRL_SHIFT = SK_CTRL_SHIFT_,
    CTRL_ALT = SK_CTRL_ALT_,
    ALT_SHIFT = SK_ALT_SHIFT_,
    CTRL_ALT_SHIFT = SK_CTRL_ALT_SHIFT_,
    META = SK_META_,
    SHIFT_META = SK_SHIFT_META_,
    CTRL_META = SK_CTRL_META_,
    ALT_META = SK_ALT_META_,
    CTRL_SHIFT_META = SK_CTRL_SHIFT_META_,
    CTRL_ALT_META = SK_CTRL_ALT_META_,
    ALT_SHIFT_META = SK_ALT_SHIFT_META_,
    CTRL_ALT_SHIFT_META = SK_CTRL_ALT_SHIFT_META_,
    PCREG_PRESSED = PCREG_PRESSED_,
}