-- Please do not modify this file.
-- This file will restore to its initial state when the software starts.

-- 请不要修改本文件
-- 本文件会在软件启动时恢复初始状态

return {
    ["Language"] = "语言",
    ["XY: (%4d, %4d)\r\nColor: 0x%06x\r\nRGB: (%3d, %3d, %3d)\r\n"] = "座標: (%4d, %4d)\r\n顏色值: 0x%06x\r\nRGB值: (%3d, %3d, %3d)\r\n",
    ["Content '%s' has been copied to the clipboard"] = "內容 '%s' 已經複製到剪貼板",
    ["Color '0x%06x' has been copied to the clipboard"] = "顏色 '0x%06x' 已經複製到剪貼板",
    ["XY '%d, %d' have been copied to the clipboard"] = "座標 '%d, %d' 已經複製到剪貼板",
    ["The contents in the clipboard has been loaded into the PosColor list"] = "已將剪貼板中的點色信息載入點色列表",
    ["X, Y, Color"] = "X, Y, Color",
    ["Parameter settings for the custom format [X, Y, Color]"] = "自定義格式 [X, Y, Color] 的參數設置",
    ["Default Color Similarity"] = "預設相似度",
    ["Aligning Using Spaces"] = "空格補齊",
    ["Using Line Break"] = "換行格式",
    ["Color Offset Mode"] = "色偏模式",
    ["Default Color Offset"] = "預設色偏",
    ["XXTDo Action"] = "XXTDo 動作",
    ["Tap the first point in the PosColor list"] = "點取色列表第一個點",
    ["Tap the last point in the PosColor list"] = "點取色列表最後一個點",
    ["Tap point A"] = "點擊 A 點",
    ["Tap point S"] = "點擊 S 點",
    ["Tap point X"] = "點擊 X 點",
    ["Tap point C"] = "點擊 C 點",
    ["Execute Custom Code"] = "自定義動作代碼",
    ["XXTDo Action Custom Code"] = "XXTDo 動作自定義代碼",
    ["Orientation During Testing"] = "代碼測試時旋轉方向",
    ["Home On Bottom"] = "Home在下",
    ["Home On Right"] = "Home在右",
    ["Home On Left"] = "Home在左",
    ["Home On Top"] = "Home在上",
    ["Default OCR Language"] = "預設 OCR 語言",
    ["Need to take at least 1 PosColor"] = "需要至少取 1 個點顏色",
    ["Format Readme"] = "格式說明",
    ["Please generate custom code as required"] = "請按要求生成自定義代碼",
    ["Test On Device"] = "於設備測試",
    ["Cannot Test"] = "無法測試",
    ["Please use [Shift + left mouse button] to select an rect on the image"] = "請使用 [Shift + 鼠標左鍵] 在圖片上框選區域",
    ["Please use [Ctrl + left mouse button] to select an rect on the image"] = "請使用 [Ctrl + 鼠標左鍵] 在圖片上框選區域",
    ["Code generation failed"] = "代碼生成失敗",
    ["A general point color table, used in various script frameworks, which requires developers to parse and use it themselves"] = "一種通用點色框架表，用於各種腳本框架，需要開發者自行解析使用",
    ["Generate an interface trigger for use by the XXTDo\nUse with the XXTDo"] = "抓取一個用於 XXTDo 框架使用的界面觸發器\n配合 XXTDo 框架使用",
    ["This format is dedicated to the function screen.is_colors defined by XXTouch"] = "這個格式專用於 XXTouch 定義的函數 screen.is_colors 多點匹配色",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nAll coordinates captured are absolute coordinates"] = "這個格式專用於 XXTouch 定義的函數 screen.find_color 多點找色\n抓取的所有座標都是絕對座標，但不影響找色，所有座標都以第一點爲相對位置",
    ["This format is specially used for the function screen.find_color defined by XXTouch\nOnly relative coordinates are captured"] = "這個格式專用於 XXTouch 定義的函數 screen.find_color 多點找色\n僅抓取相對座標，不保留絕對座標信息",
    ["This format is specially used for the screen.ocr_text screen text recognition function defined by XXTouch\nUse [Shift + left mouse button] to select the text area that needs to be recognized"] = "這個格式專用於 XXTouch 定義的函數 screen.ocr_text 屏幕文字識別函數\n使用 [Shift + 鼠標左鍵] 框選需要識別的文字區域",
    ["This format is specially used for the function screen.find_image defined by XXTouch to find images in area or full screen\nUse [Shift + left mouse button] to select the image block to be found\nUse [Ctrl + left mouse button] to select the image search area"] = "這個格式專用於 XXTouch 定義的函數 screen.find_image 區域或全屏找圖\n使用 [Shift + 鼠標左鍵] 框選需要查找的圖像塊\n使用 [Ctrl + 鼠標左鍵] 框選圖像搜索區域",
    ["Testing code changes requires XXTDo.lua"] = "測試該代碼需要 XXTDo 框架",
    ["Automatically importing XXTDo.lua to device path '%s'"] = "正在自動導入 XXTDo.lua 到設備路徑 '%s'",
    ["Automatic import of XXTDo.lua failed\nPlease manually import XXTDo.lua to the device path '%s'"] = "自動導入 XXTDo.lua 失敗\n請手動導入 XXTDo.lua 到設備路徑 '%s'",
    ["The timeout is set to 5 seconds. If no match is found within the timeout, the matching loop will be exited"] = "超時時間設爲 5 秒，超時未匹配則跳出",
    ["Preview Image"] = "預覽圖片",
    ["Copy `image.load_data([data])`"] = "複製 `image.load_data([data])`",
    ["Use [Shift + left mouse button] to select the area"] = "使用 [Shift + 鼠標左鍵] 框選區域",
    ["Use [Ctrl + left mouse button] to select the area"] = "使用 [Ctrl + 鼠標左鍵] 框選區域",
    ["Double-click to crop the small image"] = "雙擊此处抓取小圖片",
    ["Open small images folder"] = "開啟小圖片資料夾",
    ["Path for saving small images"] = "儲存小圖片的路徑",
    ["Please enter the name of the saved small image"] = "請輸入儲存的小圖片名稱",
    ["After saving the small image, gen code to the clipboard"] = "儲存小圖片後，生成程式碼到剪貼簿",
    ["The small image has been saved as: "] = "小圖片已儲存為: ",
    ["Unable to save small image"] = "無法儲存小圖片",
    ["This format is used to extract small images and save them as files. \nThe option `Path for saving small images` can be configured to specify the path for saving the small images. \nThe option `After saving the small image, generate code to the clipboard` can be configured to specify the format for generating the code after saving the small image."] = "這個格式用於提取小圖像並將其儲存為檔案。\n選項「儲存小圖片的路徑」可用來設定小圖像的儲存路徑。\n選項「儲存小圖片後，生成程式碼到剪貼簿」可用來設定儲存小圖像後所產生程式碼的格式。",
    ["#NAME# is used to represent the name of the small image"] = "#NAME# 用來表示小圖片的名稱",
    ["#FILENAME# is used to represent the file name of the small image"] = "#FILENAME# 用來表示小圖片的檔名",
    ["#IMAGEDATAHEX# is used to represent the hex-data of the small image"] = "#IMAGEDATAHEX# 用來表示小圖片的十六進制數據",
    ["#BINOPT# is used to represent the binaryzation option of the small image"] = "#BINOPT# 用來表示小圖片的二值化選項",
    ['Set the arguments and then'] = "設定參數並",
    ["Double-click to perform binaryzation"] = "雙擊進行二值化",
    ["Binaryization Preview Arguments"] = "二值化預覽參數",
    ["White Background"] = "白色背景",
    ["Color Similarity Algorithm"] = "顏色相似度算法",
    ["XXT Default"] = "XXT 預設",
    ["Manhattan Algorithm"] = "曼哈頓算法",
    ["Euclidean Algorithm"] = "歐式距離算法",
    ["Parameter settings for the custom format [XXT-Bin-Dict]"] = "自定義格式 [XXT-Bin-Dict] 的參數設定",
    ["XXT Binaryzation Dictionary"] = "XXT 二值化字典",
    ["Color offset mode binaryization arguments"] = "色偏模式二值化參數",
    ["Color similarity binaryzation arguments"] = "顏色相似度二值化參數",
    ["Used to set the arguments for performing binaryzation"] = "用來設定進行二值化的參數",
    ["Binaryization Error"] = "二值化錯誤",
    ["Bad format, Please set valid Binaryzation Preview Arguments"] = "錯誤的格式，請設定有效的二值化預覽參數",
    ["Small Images Scale"] = "小圖片縮放",
    ["Performing binaryzation..."] = "進行二值化...",
    ["Binaryzation completed"] = "二值化完成",
    ["Supports the following styles: blablabla..."] = [[
支持如下幾種樣式：

大漠色偏樣式
例如：fab1c2-102030,bcbcbc-202020

表色偏樣式
例如：{{0xfab1c2, 0x102030}, {0xbcbcbc, 0x202020}}

相似度樣式
例如：{csim_mode = true, {0xfab1c2, 90}, {0xbcbcbc, 90}}

閾值，閾值範圍 0 ~ 255
例如：150

自動閾值
例如：auto

]],

}